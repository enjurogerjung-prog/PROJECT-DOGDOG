extends Control

func _ready() -> void:
	var bg = ColorRect.new(); bg.color = Color(0.05, 0.04, 0.06); bg.set_anchors_preset(PRESET_FULL_RECT); add_child(bg)
	var v = VBoxContainer.new(); v.set_anchors_preset(PRESET_CENTER); v.custom_minimum_size = Vector2(600, 380)
	v.position = Vector2(-300, -190); v.alignment = BoxContainer.ALIGNMENT_CENTER; add_child(v)
	_l(v, "♠ ♥ ♦ ♣", 28, Color(0.6, 0.3, 0.4))
	_s(v, 10)
	_l(v, "WONDERLAND CARDS", 52, Color(0.9, 0.75, 0.8))
	_l(v, "A most curious card game", 16, Color(0.5, 0.4, 0.45))
	_s(v, 8)
	_l(v, "\"We're all mad here.\"", 14, Color(0.4, 0.35, 0.4))
	_s(v, 20)
	var hb = HBoxContainer.new(); hb.alignment = BoxContainer.ALIGNMENT_CENTER; hb.add_theme_constant_override("separation", 15); v.add_child(hb)
	for d in [["Red Queen", GM.ARCH_COLORS["red_queen"]], ["Mad Hatter", GM.ARCH_COLORS["mad_hatter"]], ["March Hare", GM.ARCH_COLORS["march_hare"]]]:
		var dot = ColorRect.new(); dot.color = d[1]; dot.custom_minimum_size = Vector2(10, 10); hb.add_child(dot)
		var lb = Label.new(); lb.text = d[0]; lb.add_theme_font_size_override("font_size", 12); lb.add_theme_color_override("font_color", d[1].lightened(0.3)); hb.add_child(lb)
	_s(v, 25)
	var bc = CenterContainer.new(); v.add_child(bc)
	var btn = Button.new(); btn.text = "  Fall Down the Rabbit Hole  "; btn.custom_minimum_size = Vector2(300, 50)
	btn.add_theme_font_size_override("font_size", 20); btn.pressed.connect(func(): GM.start_new_run()); bc.add_child(btn)
	_s(v, 15)
	_l(v, "♠ ♥ ♦ ♣", 28, Color(0.6, 0.3, 0.4))

func _l(p: Node, t: String, sz: int, c: Color) -> void:
	var l = Label.new(); l.text = t; l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", sz); l.add_theme_color_override("font_color", c); p.add_child(l)

func _s(p: Node, h: float) -> void:
	var s = Control.new(); s.custom_minimum_size = Vector2(0, h); p.add_child(s)
