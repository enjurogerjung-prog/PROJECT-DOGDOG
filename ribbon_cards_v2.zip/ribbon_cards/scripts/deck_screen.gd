extends Control

var return_to: String = "map"
var selected_deck_idx: int = -1
var selected_sb_idx: int = -1

func _ready() -> void:
	return_to = get_meta("return_to") if has_meta("return_to") else "map"
	_build_ui()

func _build_ui() -> void:
	for c in get_children(): c.queue_free()
	selected_deck_idx = -1
	selected_sb_idx = -1
	
	var bg = ColorRect.new()
	bg.color = Color(0.06, 0.05, 0.08)
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	
	# Top bar
	var top = HBoxContainer.new()
	top.position = Vector2(15, 8)
	top.add_theme_constant_override("separation", 20)
	add_child(top)
	_lbl(top, "DECK MANAGER", 22, Color(0.8, 0.7, 0.6))
	_lbl(top, "Gold: %dg" % GameManager.gold, 18, Color(0.9, 0.8, 0.3))
	_lbl(top, "Deck: %d/%d (min %d)" % [GameManager.deck.size(), GameManager.max_deck_size, GameManager.min_deck_size], 14, Color(0.5, 0.6, 0.7))
	_lbl(top, "Sideboard: %d/%d" % [GameManager.sideboard.size(), GameManager.max_sideboard_size], 14, Color(0.5, 0.5, 0.6))
	
	# === DECK ===
	var deck_label = Label.new()
	deck_label.text = "─── DECK (%d cards) ───  Click a card to select it" % GameManager.deck.size()
	deck_label.position = Vector2(15, 40)
	deck_label.add_theme_font_size_override("font_size", 14)
	deck_label.add_theme_color_override("font_color", Color(0.6, 0.55, 0.5))
	add_child(deck_label)
	
	var deck_scroll = ScrollContainer.new()
	deck_scroll.position = Vector2(15, 62)
	deck_scroll.size = Vector2(840, 280)
	deck_scroll.custom_minimum_size = Vector2(840, 280)
	add_child(deck_scroll)
	
	var deck_grid = GridContainer.new()
	deck_grid.columns = 5
	deck_grid.add_theme_constant_override("h_separation", 6)
	deck_grid.add_theme_constant_override("v_separation", 6)
	deck_scroll.add_child(deck_grid)
	
	for i in range(GameManager.deck.size()):
		var entry = GameManager.deck[i]
		var card_panel = _make_mini_card(entry, i, "deck")
		deck_grid.add_child(card_panel)
	
	# === SIDEBOARD ===
	var sb_label = Label.new()
	sb_label.text = "─── SIDEBOARD (%d cards) ───" % GameManager.sideboard.size()
	sb_label.position = Vector2(15, 350)
	sb_label.add_theme_font_size_override("font_size", 14)
	sb_label.add_theme_color_override("font_color", Color(0.55, 0.5, 0.6))
	add_child(sb_label)
	
	var sb_scroll = ScrollContainer.new()
	sb_scroll.position = Vector2(15, 372)
	sb_scroll.size = Vector2(840, 120)
	sb_scroll.custom_minimum_size = Vector2(840, 120)
	add_child(sb_scroll)
	
	var sb_grid = GridContainer.new()
	sb_grid.columns = 5
	sb_grid.add_theme_constant_override("h_separation", 6)
	sb_grid.add_theme_constant_override("v_separation", 6)
	sb_scroll.add_child(sb_grid)
	
	for i in range(GameManager.sideboard.size()):
		var entry = GameManager.sideboard[i]
		var card_panel = _make_mini_card(entry, i, "sideboard")
		sb_grid.add_child(card_panel)
	
	# === ACTION PANEL (right side) ===
	var action_panel = ColorRect.new()
	action_panel.color = Color(0.09, 0.08, 0.11)
	action_panel.position = Vector2(870, 40)
	action_panel.custom_minimum_size = Vector2(390, 450)
	action_panel.size = Vector2(390, 450)
	add_child(action_panel)
	
	var action_vbox = VBoxContainer.new()
	action_vbox.position = Vector2(15, 10)
	action_vbox.custom_minimum_size = Vector2(360, 430)
	action_vbox.add_theme_constant_override("separation", 6)
	action_panel.add_child(action_vbox)
	
	_lbl(action_vbox, "─── Actions ───", 16, Color(0.6, 0.55, 0.5))
	
	# Move to sideboard
	var move_sb_btn = Button.new()
	move_sb_btn.text = "Move Selected → Sideboard"
	move_sb_btn.custom_minimum_size = Vector2(300, 30)
	move_sb_btn.add_theme_font_size_override("font_size", 13)
	move_sb_btn.pressed.connect(_on_move_to_sideboard)
	action_vbox.add_child(move_sb_btn)
	
	# Move to deck
	var move_dk_btn = Button.new()
	move_dk_btn.text = "Move Selected → Deck"
	move_dk_btn.custom_minimum_size = Vector2(300, 30)
	move_dk_btn.add_theme_font_size_override("font_size", 13)
	move_dk_btn.pressed.connect(_on_move_to_deck)
	action_vbox.add_child(move_dk_btn)
	
	# Sell
	var sell_btn = Button.new()
	sell_btn.text = "Sell Selected Card"
	sell_btn.custom_minimum_size = Vector2(300, 30)
	sell_btn.add_theme_font_size_override("font_size", 13)
	sell_btn.pressed.connect(_on_sell)
	action_vbox.add_child(sell_btn)
	
	# Sell value preview
	var sell_preview = Label.new()
	sell_preview.name = "SellPreview"
	sell_preview.text = ""
	sell_preview.add_theme_font_size_override("font_size", 12)
	sell_preview.add_theme_color_override("font_color", Color(0.6, 0.55, 0.3))
	action_vbox.add_child(sell_preview)
	
	# === COMBINE SECTION ===
	var spacer = Control.new()
	spacer.custom_minimum_size = Vector2(0, 10)
	action_vbox.add_child(spacer)
	
	_lbl(action_vbox, "─── Combine (3 → upgrade) ───", 14, Color(0.55, 0.5, 0.45))
	
	# Show combinable cards
	var combinable = _get_combinable()
	if combinable.size() == 0:
		_lbl(action_vbox, "No cards can be combined yet.", 12, Color(0.4, 0.4, 0.4))
		_lbl(action_vbox, "Need 3 copies of same card + tier.", 11, Color(0.35, 0.35, 0.35))
	else:
		for combo in combinable:
			var combo_row = HBoxContainer.new()
			combo_row.add_theme_constant_override("separation", 8)
			action_vbox.add_child(combo_row)
			
			var card_data = GameManager.CARDS[combo["id"]]
			var tier_prefix = GameManager.get_tier_prefix(combo["tier"])
			var next_tier = GameManager._next_tier(combo["tier"])
			var next_prefix = GameManager.get_tier_prefix(next_tier)
			
			var info = Label.new()
			info.text = "%s%s (%dx) → %s" % [tier_prefix, card_data["name"], combo["count"], next_prefix + card_data["name"]]
			info.add_theme_font_size_override("font_size", 12)
			info.add_theme_color_override("font_color", GameManager.get_tier_color(next_tier))
			combo_row.add_child(info)
			
			var comb_btn = Button.new()
			comb_btn.text = "Combine"
			comb_btn.custom_minimum_size = Vector2(75, 25)
			comb_btn.add_theme_font_size_override("font_size", 11)
			comb_btn.pressed.connect(_on_combine.bind(combo["id"], combo["tier"]))
			combo_row.add_child(comb_btn)
	
	# === Bottom buttons ===
	var back_btn = Button.new()
	back_btn.text = "← Back"
	back_btn.position = Vector2(15, 670)
	back_btn.custom_minimum_size = Vector2(100, 35)
	back_btn.add_theme_font_size_override("font_size", 14)
	back_btn.pressed.connect(func(): GameManager.screen_change_requested.emit(return_to, {}))
	add_child(back_btn)

func _make_mini_card(entry: Dictionary, idx: int, source: String) -> PanelContainer:
	var card_data = GameManager.CARDS[entry["id"]]
	var arch_color = GameManager.get_card_color(entry["id"])
	var tier_color = GameManager.get_tier_color(entry["tier"])
	
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(160, 55)
	
	var bg = ColorRect.new()
	bg.color = arch_color.darkened(0.4)
	bg.custom_minimum_size = Vector2(160, 55)
	panel.add_child(bg)
	
	if entry["tier"] != GameManager.TIER_BASE:
		var stripe = ColorRect.new()
		stripe.color = tier_color
		stripe.custom_minimum_size = Vector2(160, 2)
		bg.add_child(stripe)
	
	var vbox = VBoxContainer.new()
	vbox.position = Vector2(5, 3)
	panel.add_child(vbox)
	
	var name_lbl = Label.new()
	var prefix = GameManager.get_tier_prefix(entry["tier"])
	name_lbl.text = "%s%s [%d]" % [prefix, card_data["name"], card_data["cost"]]
	name_lbl.add_theme_font_size_override("font_size", 12)
	if entry["tier"] != GameManager.TIER_BASE:
		name_lbl.add_theme_color_override("font_color", tier_color)
	vbox.add_child(name_lbl)
	
	var desc_lbl = Label.new()
	desc_lbl.text = card_data["desc"]
	desc_lbl.add_theme_font_size_override("font_size", 10)
	desc_lbl.add_theme_color_override("font_color", Color(0.75, 0.75, 0.72))
	vbox.add_child(desc_lbl)
	
	var sell_val = GameManager.get_sell_price(entry)
	var arch_name = card_data.get("archetype", "neutral").substr(0, 1).to_upper()
	var info_lbl = Label.new()
	info_lbl.text = "%s • Sell: %dg" % [arch_name, sell_val]
	info_lbl.add_theme_font_size_override("font_size", 9)
	info_lbl.add_theme_color_override("font_color", Color(0.5, 0.5, 0.45))
	vbox.add_child(info_lbl)
	
	# Click
	var btn = Button.new()
	btn.flat = true
	btn.set_anchors_preset(PRESET_FULL_RECT)
	btn.custom_minimum_size = Vector2(160, 55)
	btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	btn.pressed.connect(_on_select.bind(idx, source))
	panel.add_child(btn)
	
	# Highlight if selected
	var is_selected = (source == "deck" and idx == selected_deck_idx) or (source == "sideboard" and idx == selected_sb_idx)
	if is_selected:
		bg.color = arch_color.lightened(0.2)
	
	return panel

func _on_select(idx: int, source: String) -> void:
	if source == "deck":
		selected_deck_idx = idx if selected_deck_idx != idx else -1
		selected_sb_idx = -1
	else:
		selected_sb_idx = idx if selected_sb_idx != idx else -1
		selected_deck_idx = -1
	_build_ui()

func _on_move_to_sideboard() -> void:
	if selected_deck_idx >= 0:
		GameManager.move_to_sideboard(selected_deck_idx)
	_build_ui()

func _on_move_to_deck() -> void:
	if selected_sb_idx >= 0:
		GameManager.move_to_deck(selected_sb_idx)
	_build_ui()

func _on_sell() -> void:
	if selected_deck_idx >= 0:
		GameManager.sell_card_from_deck(selected_deck_idx)
	elif selected_sb_idx >= 0:
		GameManager.sell_card_from_sideboard(selected_sb_idx)
	_build_ui()

func _on_combine(card_id: String, tier: String) -> void:
	GameManager.combine_cards(card_id, tier)
	_build_ui()

func _get_combinable() -> Array:
	# Count all cards by id+tier across deck and sideboard
	var counts: Dictionary = {}
	for entry in GameManager.deck:
		var key = entry["id"] + ":" + entry["tier"]
		counts[key] = counts.get(key, 0) + 1
	for entry in GameManager.sideboard:
		var key = entry["id"] + ":" + entry["tier"]
		counts[key] = counts.get(key, 0) + 1
	
	var result: Array = []
	for key in counts:
		if counts[key] >= 3:
			var parts = key.split(":")
			var tier = parts[1]
			if GameManager._next_tier(tier) != "":
				result.append({"id": parts[0], "tier": tier, "count": counts[key]})
	return result

func _lbl(parent: Node, text: String, size: int, color: Color) -> void:
	var l = Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	parent.add_child(l)
