extends Node

signal screen_change(scr: String, data: Dictionary)

# === CONSTANTS ===
const START_GOLD := 10
const START_HP := 70
const MAX_ENERGY := 3
const HAND_SIZE := 6
const MAX_DECK := 40
const MIN_DECK := 20
const MAX_SB := 10
const INTEREST_CAP := 5
const SYNERGY_THRESHOLD := 3
const BOOSTER_BASE := 4
const BOOSTER_ESC := 2
const REROLL_BASE_COST := 1

const TIER_BRONZE := "bronze"
const TIER_SILVER := "silver"
const TIER_GOLD := "gold"
const TIER_MULT := {"bronze": 1.0, "silver": 1.5, "gold": 2.0}
const TIER_NAMES := {"bronze": "Bronze", "silver": "Silver", "gold": "Gold"}
const TIER_PREFIX := {"bronze": "", "silver": "◇ ", "gold": "★ "}
const TIER_COLORS := {"bronze": Color(0.72, 0.45, 0.2), "silver": Color(0.75, 0.75, 0.8), "gold": Color(1.0, 0.85, 0.3)}

const ARCH_QUEEN := "red_queen"
const ARCH_HATTER := "mad_hatter"
const ARCH_HARE := "march_hare"
const ARCH_NEUTRAL := "neutral"

const ARCH_COLORS := {
	"red_queen": Color(0.75, 0.15, 0.2),
	"mad_hatter": Color(0.6, 0.3, 0.7),
	"march_hare": Color(0.2, 0.55, 0.4),
	"neutral": Color(0.5, 0.5, 0.5),
}
const ARCH_NAMES := {"red_queen": "Red Queen", "mad_hatter": "Mad Hatter", "march_hare": "March Hare", "neutral": "Wonderland"}

const SYNERGY_DESC := {
	"red_queen": "+6 Block",
	"mad_hatter": "3 dmg to ALL + random debuff",
	"march_hare": "Draw 2",
	"neutral": "+1 Energy",
}

# === CARD DATABASE ===
var CARDS: Dictionary = {
	# --- NEUTRAL ---
	"strike": {"name": "Strike", "cost": 1, "type": "attack", "arch": "neutral", "target": "single", "rarity": "common", "price": 3, "desc": "Deal 6 damage.", "effects": [{"t": "damage", "v": 6}]},
	"guard": {"name": "Guard", "cost": 1, "type": "defend", "arch": "neutral", "target": "self", "rarity": "common", "price": 3, "desc": "Gain 5 Block.", "effects": [{"t": "block", "v": 5}]},
	"curiosity": {"name": "Curiosity", "cost": 0, "type": "skill", "arch": "neutral", "target": "self", "rarity": "common", "price": 3, "desc": "Draw 1.", "effects": [{"t": "draw", "v": 1}]},
	"wonder": {"name": "Wonder", "cost": 1, "type": "skill", "arch": "neutral", "target": "self", "rarity": "uncommon", "price": 6, "desc": "Draw 3.", "effects": [{"t": "draw", "v": 3}]},
	"looking_glass": {"name": "Looking Glass", "cost": 0, "type": "skill", "arch": "neutral", "target": "self", "rarity": "uncommon", "price": 6, "desc": "+1 Energy.", "effects": [{"t": "energy", "v": 1}]},
	"down_the_hole": {"name": "Down the Hole", "cost": 2, "type": "skill", "arch": "neutral", "target": "self", "rarity": "rare", "price": 10, "desc": "Draw 3. +1 Energy. +5 Block.", "effects": [{"t": "draw", "v": 3}, {"t": "energy", "v": 1}, {"t": "block", "v": 5}]},

	# --- RED QUEEN (Control / Shields / Negate) ---
	"royal_decree": {"name": "Royal Decree", "cost": 1, "type": "skill", "arch": "red_queen", "target": "single", "rarity": "common", "price": 4, "desc": "Apply 2 Weak.", "effects": [{"t": "weak", "v": 2}]},
	"queens_guard": {"name": "Queen's Guard", "cost": 1, "type": "defend", "arch": "red_queen", "target": "self", "rarity": "common", "price": 4, "desc": "Gain 7 Block.", "effects": [{"t": "block", "v": 7}]},
	"off_with_heads": {"name": "Off With Heads!", "cost": 1, "type": "attack", "arch": "red_queen", "target": "single", "rarity": "common", "price": 4, "desc": "Deal 4 dmg. 1 Vuln.", "effects": [{"t": "damage", "v": 4}, {"t": "vulnerable", "v": 1}]},
	"crimson_court": {"name": "Crimson Court", "cost": 2, "type": "defend", "arch": "red_queen", "target": "self", "rarity": "uncommon", "price": 7, "desc": "Gain 12 Block.", "effects": [{"t": "block", "v": 12}]},
	"paint_roses_red": {"name": "Paint Roses Red", "cost": 1, "type": "skill", "arch": "red_queen", "target": "single", "rarity": "uncommon", "price": 7, "desc": "3 Weak + 2 Vuln.", "effects": [{"t": "weak", "v": 3}, {"t": "vulnerable", "v": 2}]},
	"royal_shield": {"name": "Royal Shield", "cost": 1, "type": "defend", "arch": "red_queen", "target": "self", "rarity": "uncommon", "price": 7, "desc": "+8 Block. 1 Weak ALL.", "effects": [{"t": "block", "v": 8}, {"t": "weak_all", "v": 1}]},
	"absolute_rule": {"name": "Absolute Rule", "cost": 3, "type": "skill", "arch": "red_queen", "target": "single", "rarity": "rare", "price": 10, "desc": "3 Weak + 3 Vuln + 6 Psn.", "effects": [{"t": "weak", "v": 3}, {"t": "vulnerable", "v": 3}, {"t": "poison", "v": 6}]},
	"croquet_smash": {"name": "Croquet Smash", "cost": 2, "type": "attack", "arch": "red_queen", "target": "single", "rarity": "rare", "price": 10, "desc": "Deal 18 dmg. Cleanse.", "effects": [{"t": "damage", "v": 18}, {"t": "cleanse", "v": 0}]},
	# POWER
	"queens_command": {"name": "Queen's Command", "cost": 2, "type": "power", "arch": "red_queen", "target": "self", "rarity": "rare", "price": 12, "desc": "POWER: +1 draw per turn.", "effects": [{"t": "power_draw", "v": 1}]},

	# --- MAD HATTER (Chaos / Mini-games / Thousand Cuts) ---
	"tea_toss": {"name": "Tea Toss", "cost": 1, "type": "attack", "arch": "mad_hatter", "target": "single", "rarity": "common", "price": 4, "desc": "Deal 3 dmg x2.", "effects": [{"t": "damage", "v": 3}, {"t": "damage", "v": 3}]},
	"mad_giggle": {"name": "Mad Giggle", "cost": 0, "type": "attack", "arch": "mad_hatter", "target": "single", "rarity": "common", "price": 4, "desc": "Deal 3. Draw 1.", "effects": [{"t": "damage", "v": 3}, {"t": "draw", "v": 1}]},
	"hat_trick": {"name": "Hat Trick", "cost": 1, "type": "attack", "arch": "mad_hatter", "target": "single", "rarity": "common", "price": 4, "desc": "Deal 4. Random debuff.", "effects": [{"t": "damage", "v": 4}, {"t": "random_debuff", "v": 1}]},
	"tea_party": {"name": "Tea Party", "cost": 1, "type": "attack", "arch": "mad_hatter", "target": "single", "rarity": "uncommon", "price": 7, "desc": "ROULETTE: Spin for effect!", "effects": [{"t": "minigame", "v": 0, "game": "roulette"}]},
	"vanishing_act": {"name": "Vanishing Act", "cost": 1, "type": "attack", "arch": "mad_hatter", "target": "single", "rarity": "uncommon", "price": 7, "desc": "QTE: Click in time! Deal 5-15.", "effects": [{"t": "minigame", "v": 0, "game": "reflex"}]},
	"mercury_poison": {"name": "Mercury Poison", "cost": 1, "type": "skill", "arch": "mad_hatter", "target": "all", "rarity": "uncommon", "price": 7, "desc": "4 Poison ALL.", "effects": [{"t": "poison", "v": 4}]},
	"impossible_tea": {"name": "Impossible Tea", "cost": 2, "type": "attack", "arch": "mad_hatter", "target": "single", "rarity": "rare", "price": 10, "desc": "Deal 2 dmg x7.", "effects": [{"t": "damage", "v": 2}, {"t": "damage", "v": 2}, {"t": "damage", "v": 2}, {"t": "damage", "v": 2}, {"t": "damage", "v": 2}, {"t": "damage", "v": 2}, {"t": "damage", "v": 2}]},
	"unbirthday": {"name": "Un-Birthday", "cost": 2, "type": "attack", "arch": "mad_hatter", "target": "single", "rarity": "rare", "price": 10, "desc": "WATCH QTE: Deal 8-24 dmg.", "effects": [{"t": "minigame", "v": 0, "game": "watch"}]},
	# POWER
	"eternal_tea_time": {"name": "Eternal Tea Time", "cost": 3, "type": "power", "arch": "mad_hatter", "target": "self", "rarity": "rare", "price": 12, "desc": "POWER: -1 synergy threshold.", "effects": [{"t": "power_synergy", "v": -1}]},

	# --- MARCH HARE (Shield / Card Draw / Speed) ---
	"hurry_up": {"name": "Hurry Up!", "cost": 1, "type": "skill", "arch": "march_hare", "target": "self", "rarity": "common", "price": 4, "desc": "Draw 2. +3 Block.", "effects": [{"t": "draw", "v": 2}, {"t": "block", "v": 3}]},
	"late_late": {"name": "Late! Late!", "cost": 0, "type": "attack", "arch": "march_hare", "target": "single", "rarity": "common", "price": 4, "desc": "Deal 4. Draw 1.", "effects": [{"t": "damage", "v": 4}, {"t": "draw", "v": 1}]},
	"pocket_watch_block": {"name": "Pocket Watch", "cost": 1, "type": "defend", "arch": "march_hare", "target": "self", "rarity": "common", "price": 4, "desc": "+6 Block. Draw 1.", "effects": [{"t": "block", "v": 6}, {"t": "draw", "v": 1}]},
	"tea_break": {"name": "Tea Break", "cost": 1, "type": "defend", "arch": "march_hare", "target": "self", "rarity": "uncommon", "price": 7, "desc": "+8 Block. Heal 3.", "effects": [{"t": "block", "v": 8}, {"t": "heal", "v": 3}]},
	"mad_dash": {"name": "Mad Dash", "cost": 1, "type": "attack", "arch": "march_hare", "target": "single", "rarity": "uncommon", "price": 7, "desc": "Deal 8. Draw 2.", "effects": [{"t": "damage", "v": 8}, {"t": "draw", "v": 2}]},
	"time_warp": {"name": "Time Warp", "cost": 2, "type": "skill", "arch": "march_hare", "target": "self", "rarity": "uncommon", "price": 7, "desc": "+1 Energy. Draw 3.", "effects": [{"t": "energy", "v": 1}, {"t": "draw", "v": 3}]},
	"burrow_deep": {"name": "Burrow Deep", "cost": 2, "type": "defend", "arch": "march_hare", "target": "self", "rarity": "rare", "price": 10, "desc": "+18 Block. Draw 2.", "effects": [{"t": "block", "v": 18}, {"t": "draw", "v": 2}]},
	"white_rabbit_sprint": {"name": "White Rabbit Sprint", "cost": 3, "type": "attack", "arch": "march_hare", "target": "single", "rarity": "rare", "price": 10, "desc": "Deal 20. Draw 3.", "effects": [{"t": "damage", "v": 20}, {"t": "draw", "v": 3}]},
	# POWER
	"hares_fury": {"name": "Hare's Fury", "cost": 3, "type": "power", "arch": "march_hare", "target": "self", "rarity": "rare", "price": 12, "desc": "POWER: +1 Str each turn.", "effects": [{"t": "power_strength", "v": 1}]},
}

# === ENEMIES ===
var ENEMIES: Dictionary = {
	# Regular
	"card_soldier": {"name": "Card Soldier", "arch": "red_queen", "min_hp": 18, "max_hp": 24, "intents": [{"type": "attack", "value": 6}, {"type": "defend", "value": 7}, {"type": "attack", "value": 9}]},
	"painted_rose": {"name": "Painted Rose", "arch": "red_queen", "min_hp": 14, "max_hp": 20, "intents": [{"type": "debuff_weak", "value": 2}, {"type": "attack", "value": 5}, {"type": "attack", "value": 8}]},
	"dormouse": {"name": "Dormouse", "arch": "mad_hatter", "min_hp": 12, "max_hp": 18, "intents": [{"type": "attack", "value": 4}, {"type": "attack", "value": 4}, {"type": "attack", "value": 7}]},
	"mad_teapot": {"name": "Mad Teapot", "arch": "mad_hatter", "min_hp": 20, "max_hp": 26, "intents": [{"type": "debuff_poison", "value": 3}, {"type": "attack", "value": 5}, {"type": "attack", "value": 5}]},
	"white_rabbit": {"name": "White Rabbit", "arch": "march_hare", "min_hp": 16, "max_hp": 22, "intents": [{"type": "attack", "value": 5}, {"type": "defend", "value": 6}, {"type": "buff_strength", "value": 1}]},
	"bread_butterfly": {"name": "Bread-and-Butterfly", "arch": "march_hare", "min_hp": 14, "max_hp": 18, "intents": [{"type": "attack", "value": 4}, {"type": "attack", "value": 6}, {"type": "defend", "value": 5}]},
	# Elites
	"tweedle_duo": {"name": "Tweedle Dee & Dum", "arch": "neutral", "min_hp": 40, "max_hp": 50, "intents": [{"type": "attack", "value": 7}, {"type": "attack", "value": 7}, {"type": "buff_strength", "value": 2}, {"type": "attack", "value": 12}]},
	"caterpillar": {"name": "The Caterpillar", "arch": "neutral", "min_hp": 35, "max_hp": 45, "intents": [{"type": "debuff_poison", "value": 5}, {"type": "defend", "value": 10}, {"type": "debuff_weak", "value": 2}, {"type": "attack", "value": 10}]},
	"cheshire_cat": {"name": "Cheshire Cat", "arch": "mad_hatter", "min_hp": 30, "max_hp": 40, "intents": [{"type": "attack", "value": 5}, {"type": "debuff_vulnerable", "value": 2}, {"type": "attack", "value": 8}, {"type": "attack", "value": 12}]},
	# Act Bosses
	"queen_of_hearts": {"name": "Queen of Hearts", "arch": "red_queen", "min_hp": 80, "max_hp": 95, "intents": [{"type": "defend", "value": 12}, {"type": "debuff_weak", "value": 2}, {"type": "attack", "value": 12}, {"type": "buff_strength", "value": 2}, {"type": "attack", "value": 18}, {"type": "defend", "value": 10}]},
	"jabberwock": {"name": "The Jabberwock", "arch": "mad_hatter", "min_hp": 90, "max_hp": 110, "intents": [{"type": "attack", "value": 6}, {"type": "attack", "value": 6}, {"type": "attack", "value": 6}, {"type": "buff_strength", "value": 3}, {"type": "attack", "value": 14}, {"type": "debuff_poison", "value": 6}]},
	"time_himself": {"name": "Time Himself", "arch": "march_hare", "min_hp": 85, "max_hp": 100, "intents": [{"type": "defend", "value": 14}, {"type": "buff_strength", "value": 2}, {"type": "attack", "value": 10}, {"type": "debuff_vulnerable", "value": 3}, {"type": "attack", "value": 20}, {"type": "defend", "value": 12}]},
}

var BOSS_POOL := ["queen_of_hearts", "jabberwock", "time_himself"]
var ELITE_POOL := ["tweedle_duo", "caterpillar", "cheshire_cat"]
var REGULAR_POOL := ["card_soldier", "painted_rose", "dormouse", "mad_teapot", "white_rabbit", "bread_butterfly"]

# === RELICS ===
var RELICS: Dictionary = {
	"eat_me_cake": {"name": "Eat Me Cake", "desc": "+1 hand size.", "price": 15, "effect": "hand_size", "value": 1},
	"drink_me_potion": {"name": "Drink Me Potion", "desc": "+1 energy/turn.", "price": 20, "effect": "max_energy", "value": 1},
	"white_roses": {"name": "White Roses", "desc": "Heal 3 after fights.", "price": 10, "effect": "post_heal", "value": 3},
	"golden_key": {"name": "Golden Key", "desc": "Interest cap +2.", "price": 12, "effect": "interest_cap", "value": 2},
	"vorpal_blade": {"name": "Vorpal Blade", "desc": "+1 Str at fight start.", "price": 15, "effect": "start_str", "value": 1},
	"glass_shield": {"name": "Glass Shield", "desc": "+4 Block at fight start.", "price": 12, "effect": "start_block", "value": 4},
	"rabbit_hole": {"name": "Rabbit Hole", "desc": "+2 sideboard size.", "price": 10, "effect": "sb_size", "value": 2},
	"tiny_door": {"name": "Tiny Door", "desc": "-3 min deck size.", "price": 15, "effect": "min_deck", "value": -3, "confirm": true},
	"mad_monocle": {"name": "Mad Monocle", "desc": "Shop cards -1g.", "price": 10, "effect": "shop_disc", "value": 1},
	"dormouse_pillow": {"name": "Dormouse Pillow", "desc": "Synergy at 2 cards.", "price": 18, "effect": "synergy", "value": -1},
}

# === EVENTS ===
var EVENTS: Array = [
	{"title": "The Caterpillar's Smoke", "desc": "A hookah-smoking caterpillar offers cryptic advice.", "choices": [
		{"text": "Inhale deeply (Minigame: Mushroom)", "type": "minigame", "game": "mushroom", "success": {"heal": 10}, "fail": {"damage": 5}},
		{"text": "Ask 'Who are you?' (+5 gold)", "type": "gold", "value": 5},
		{"text": "Walk away", "type": "nothing"},
	]},
	{"title": "The Cheshire Grin", "desc": "A floating grin appears among the trees.", "choices": [
		{"text": "Catch the grin (Minigame: Reflex)", "type": "minigame", "game": "reflex", "success": {"relic_discount": 5}, "fail": {"damage": 3}},
		{"text": "Ask for directions (Random card)", "type": "random_card"},
		{"text": "Ignore it", "type": "nothing"},
	]},
	{"title": "The Duchess's Kitchen", "desc": "Pepper fills the air. The cook is throwing pots.", "choices": [
		{"text": "Dodge the pots! (Minigame: Watch QTE)", "type": "minigame", "game": "watch", "success": {"gold": 8}, "fail": {"damage": 8}},
		{"text": "Grab the pepper (+3 Poison card)", "type": "add_card", "card": "mercury_poison"},
		{"text": "Leave quickly", "type": "nothing"},
	]},
	{"title": "The Pool of Tears", "desc": "Alice's tears have flooded the hall.", "choices": [
		{"text": "Swim through (Lose 5 HP, gain random relic)", "type": "relic_trade", "hp_cost": 5},
		{"text": "Wait for it to drain (Heal 8)", "type": "heal", "value": 8},
		{"text": "Drink it... (Minigame: Roulette)", "type": "minigame", "game": "roulette", "success": {"heal": 15}, "fail": {"damage": 10}},
	]},
	{"title": "A Very Merry Un-Birthday", "desc": "The Hatter insists it's your un-birthday.", "choices": [
		{"text": "Accept the gift (Random card)", "type": "random_card"},
		{"text": "Swap seats! (Minigame: Shuffle)", "type": "minigame", "game": "shuffle", "success": {"gold": 10}, "fail": {"gold": -3}},
		{"text": "Politely decline (+3 gold)", "type": "gold", "value": 3},
	]},
]

# ============================================================
# RUN STATE
# ============================================================
var hp: int = START_HP
var max_hp: int = START_HP
var gold: int = START_GOLD
var deck: Array = []       # [{id, tier}]
var sideboard: Array = []
var relics: Array = []     # relic IDs

var max_deck: int = MAX_DECK
var min_deck: int = MIN_DECK
var max_sb: int = MAX_SB
var interest_cap: int = INTEREST_CAP
var hand_bonus: int = 0
var energy_bonus: int = 0
var synergy_mod: int = 0
var shop_disc: int = 0
var relic_disc: int = 0
var booster_buys: Dictionary = {"red_queen": 0, "mad_hatter": 0, "march_hare": 0}
var row2_buys: int = 0

var current_act: int = 0
var infinite_cycle: int = 0
var run_active := false
var last_fight_turns: int = 0

# Map state
var map_nodes: Array = []  # [{row, col, type, data, connections}]
var current_node_idx: int = -1
var visited: Array = []

# Active powers in combat
var active_powers: Dictionary = {"power_draw": 0, "power_strength": 0, "power_synergy": 0}

# ============================================================
# RUN MANAGEMENT
# ============================================================

func start_new_run() -> void:
	hp = START_HP; max_hp = START_HP; gold = START_GOLD
	deck.clear(); sideboard.clear(); relics.clear()
	max_deck = MAX_DECK; min_deck = MIN_DECK; max_sb = MAX_SB
	interest_cap = INTEREST_CAP; hand_bonus = 0; energy_bonus = 0
	synergy_mod = 0; shop_disc = 0; relic_disc = 0
	booster_buys = {"red_queen": 0, "mad_hatter": 0, "march_hare": 0}
	row2_buys = 0; current_act = 0; infinite_cycle = 0
	run_active = true
	screen_change.emit("draft", {})

func setup_starter_deck(drafted_cards: Array) -> void:
	deck.clear()
	for _i in range(4): deck.append({"id": "strike", "tier": TIER_BRONZE})
	for _i in range(4): deck.append({"id": "guard", "tier": TIER_BRONZE})
	for cid in drafted_cards:
		deck.append({"id": cid, "tier": TIER_BRONZE})
	generate_map()
	screen_change.emit("map", {})

func generate_map() -> void:
	map_nodes.clear(); visited.clear(); current_node_idx = -1
	var rows = randi_range(5, 7)
	var rng = RandomNumberGenerator.new()
	rng.randomize()
	for r in range(rows + 1): # +1 for boss row
		var cols = 3 if r == 0 else (1 if r == rows else randi_range(2, 3))
		for c in range(cols):
			var ntype: String
			if r == 0:
				ntype = "combat"
			elif r == rows:
				ntype = "boss"
			else:
				var roll = rng.randf()
				if roll < 0.35: ntype = "combat"
				elif roll < 0.5: ntype = "elite"
				elif roll < 0.65: ntype = "event"
				elif roll < 0.75: ntype = "rest"
				elif roll < 0.88: ntype = "shop"
				else: ntype = "treasure"
			var node_data := {}
			if ntype == "combat":
				var pool = REGULAR_POOL.duplicate()
				pool.shuffle()
				var count = randi_range(1, 3)
				node_data["enemies"] = pool.slice(0, count)
			elif ntype == "elite":
				node_data["enemies"] = [ELITE_POOL[randi() % ELITE_POOL.size()]]
			elif ntype == "boss":
				var bi = mini(current_act, BOSS_POOL.size() - 1)
				node_data["enemies"] = [BOSS_POOL[bi]]
			elif ntype == "event":
				node_data["event_idx"] = randi() % EVENTS.size()
			map_nodes.append({"row": r, "col": c, "type": ntype, "data": node_data, "connections": []})
	# Generate connections (each node connects to 1-2 nodes in next row)
	for i in range(map_nodes.size()):
		var node = map_nodes[i]
		var next_row_nodes: Array = []
		for j in range(map_nodes.size()):
			if map_nodes[j]["row"] == node["row"] + 1:
				next_row_nodes.append(j)
		if next_row_nodes.size() > 0:
			next_row_nodes.shuffle()
			var conn_count = mini(randi_range(1, 2), next_row_nodes.size())
			node["connections"] = next_row_nodes.slice(0, conn_count)
	# Ensure all non-first-row nodes have at least one incoming connection
	for i in range(map_nodes.size()):
		if map_nodes[i]["row"] == 0: continue
		var has_incoming := false
		for j in range(map_nodes.size()):
			if i in map_nodes[j]["connections"]:
				has_incoming = true; break
		if not has_incoming:
			# Find a node in previous row and connect it
			for j in range(map_nodes.size()):
				if map_nodes[j]["row"] == map_nodes[i]["row"] - 1:
					map_nodes[j]["connections"].append(i); break

func get_available_nodes() -> Array:
	if current_node_idx < 0:
		# Start: return all row 0 nodes
		var result: Array = []
		for i in range(map_nodes.size()):
			if map_nodes[i]["row"] == 0: result.append(i)
		return result
	return map_nodes[current_node_idx]["connections"]

func visit_node(idx: int) -> void:
	current_node_idx = idx
	visited.append(idx)

func advance_act() -> void:
	current_act += 1
	if current_act >= 3:
		infinite_cycle += 1; current_act = 0
	generate_map()

func scaling() -> float: return 1.0 + 0.3 * float(infinite_cycle)
func act_name() -> String:
	var cycle = "" if infinite_cycle == 0 else " (Cycle %d)" % (infinite_cycle + 1)
	match current_act:
		0: return "Chapter I — Down the Rabbit Hole" + cycle
		1: return "Chapter II — The Tea Party" + cycle
		2: return "Chapter III — The Queen's Garden" + cycle
	return "Chapter ???" + cycle

# ============================================================
# ECONOMY
# ============================================================
func calc_interest() -> int: return mini(gold / 5, interest_cap)
func fight_gold(turns: int) -> int: return maxi(6 - clampi(turns, 1, 6), 0)

func post_fight_rewards(turns: int) -> Dictionary:
	last_fight_turns = turns
	var fg = fight_gold(turns); var intr = calc_interest()
	var hl = 0
	for rid in relics:
		if RELICS[rid]["effect"] == "post_heal": hl += RELICS[rid]["value"]
	if hl > 0: heal(hl)
	gold += fg + intr
	return {"fight_gold": fg, "interest": intr, "heal": hl, "turns": turns, "total": gold}

func sell_price(entry: Dictionary) -> int:
	var p = CARDS.get(entry["id"], {}).get("price", 3)
	return maxi(int(p * TIER_MULT.get(entry["tier"], 1.0) * 0.25), 1)

func booster_cost(arch: String) -> int:
	return BOOSTER_BASE + booster_buys.get(arch, 0) * BOOSTER_ESC

# ============================================================
# CARD HELPERS
# ============================================================
func card_at_tier(cid: String, tier: String) -> Dictionary:
	var base = CARDS[cid].duplicate(true)
	var m = TIER_MULT.get(tier, 1.0)
	var new_fx: Array = []
	for e in base["effects"]:
		var ec = e.duplicate()
		if ec.has("v") and (ec["v"] is int or ec["v"] is float) and ec["t"] != "minigame":
			ec["v"] = int(ec["v"] * m)
			if ec["v"] < 1 and e["v"] > 0: ec["v"] = 1
		new_fx.append(ec)
	base["effects"] = new_fx
	if tier == TIER_GOLD: base["cost"] = maxi(base["cost"] - 1, 0)
	base["tier"] = tier
	return base

func cards_by_arch(arch: String) -> Array:
	var r: Array = []
	for cid in CARDS:
		if CARDS[cid]["arch"] == arch: r.append(cid)
	return r

func rand_shop_cards(n: int) -> Array:
	var all = CARDS.keys(); all.shuffle(); return all.slice(0, n)

func rand_relics(n: int) -> Array:
	var av: Array = []
	for rid in RELICS:
		if rid not in relics: av.append(rid)
	av.shuffle(); return av.slice(0, mini(n, av.size()))

func get_arch_color(cid: String) -> Color: return ARCH_COLORS.get(CARDS[cid]["arch"], Color.GRAY)

# ============================================================
# DECK MANAGEMENT
# ============================================================
func add_to_deck(cid: String, tier: String = TIER_BRONZE) -> bool:
	if deck.size() < max_deck: deck.append({"id": cid, "tier": tier}); return true
	return false

func add_to_sb(cid: String, tier: String = TIER_BRONZE) -> bool:
	if sideboard.size() < max_sb: sideboard.append({"id": cid, "tier": tier}); return true
	return false

func move_to_sb(idx: int) -> bool:
	if idx < 0 or idx >= deck.size() or sideboard.size() >= max_sb or deck.size() <= min_deck: return false
	sideboard.append(deck[idx]); deck.remove_at(idx); return true

func move_to_deck(idx: int) -> bool:
	if idx < 0 or idx >= sideboard.size() or deck.size() >= max_deck: return false
	deck.append(sideboard[idx]); sideboard.remove_at(idx); return true

func sell_from_deck(idx: int) -> int:
	if idx < 0 or idx >= deck.size() or deck.size() <= min_deck: return 0
	var p = sell_price(deck[idx]); deck.remove_at(idx); gold += p; return p

func sell_from_sb(idx: int) -> int:
	if idx < 0 or idx >= sideboard.size(): return 0
	var p = sell_price(sideboard[idx]); sideboard.remove_at(idx); gold += p; return p

func next_tier(tier: String) -> String:
	match tier:
		"bronze": return "silver"
		"silver": return "gold"
	return ""

func get_combinable() -> Array:
	var counts: Dictionary = {}
	for e in deck:
		var k = e["id"] + ":" + e["tier"]; counts[k] = counts.get(k, 0) + 1
	for e in sideboard:
		var k = e["id"] + ":" + e["tier"]; counts[k] = counts.get(k, 0) + 1
	var r: Array = []
	for k in counts:
		if counts[k] >= 3:
			var p = k.split(":"); if next_tier(p[1]) != "": r.append({"id": p[0], "tier": p[1], "count": counts[k]})
	return r

func combine_cards(cid: String, tier: String) -> bool:
	var nt = next_tier(tier)
	if nt == "": return false
	var idxs_d: Array = []; var idxs_s: Array = []
	for i in range(deck.size()):
		if deck[i]["id"] == cid and deck[i]["tier"] == tier: idxs_d.append(i)
	for i in range(sideboard.size()):
		if sideboard[i]["id"] == cid and sideboard[i]["tier"] == tier: idxs_s.append(i)
	if idxs_d.size() + idxs_s.size() < 3: return false
	var rem := 3; var rd: Array = []; var rs: Array = []
	for idx in idxs_d:
		if rem <= 0: break; rd.append(idx); rem -= 1
	for idx in idxs_s:
		if rem <= 0: break; rs.append(idx); rem -= 1
	rd.sort(); rd.reverse(); for idx in rd: deck.remove_at(idx)
	rs.sort(); rs.reverse(); for idx in rs: sideboard.remove_at(idx)
	deck.append({"id": cid, "tier": nt}); return true

# ============================================================
# RELIC MANAGEMENT
# ============================================================
func add_relic(rid: String) -> void:
	relics.append(rid); var r = RELICS[rid]
	match r["effect"]:
		"hand_size": hand_bonus += r["value"]
		"max_energy": energy_bonus += r["value"]
		"interest_cap": interest_cap += r["value"]
		"sb_size": max_sb += r["value"]
		"min_deck": min_deck = maxi(min_deck + r["value"], 5)
		"shop_disc": shop_disc += r["value"]
		"synergy": synergy_mod += r["value"]

func heal(amt: int) -> void: hp = mini(hp + amt, max_hp)
func damage(amt: int) -> void: hp = maxi(hp - amt, 0)

func get_intent_text(intent: Dictionary) -> String:
	match intent["type"]:
		"attack": return "ATK %d" % intent["value"]
		"defend": return "DEF %d" % intent["value"]
		"buff_strength": return "STR +%d" % intent["value"]
		"debuff_poison": return "PSN %d" % intent["value"]
		"debuff_weak": return "WK %d" % intent["value"]
		"debuff_vulnerable": return "VL %d" % intent["value"]
		"lifesteal_attack": return "DRAIN %d" % intent["value"]
	return "???"

func get_intent_color(intent: Dictionary) -> Color:
	match intent["type"]:
		"attack", "lifesteal_attack": return Color(1, 0.3, 0.3)
		"defend": return Color(0.3, 0.5, 1)
		"buff_strength": return Color(1, 0.8, 0.2)
		"debuff_poison": return Color(0.3, 0.8, 0.3)
		"debuff_weak", "debuff_vulnerable": return Color(0.8, 0.4, 0.8)
	return Color.WHITE

func reset_powers() -> void:
	active_powers = {"power_draw": 0, "power_strength": 0, "power_synergy": 0}
