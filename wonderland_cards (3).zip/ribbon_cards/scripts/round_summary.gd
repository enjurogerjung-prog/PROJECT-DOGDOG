extends Control

func _ready() -> void:
	var rewards = get_meta("rewards") if has_meta("rewards") else {}
	var was_boss = get_meta("was_boss") if has_meta("was_boss") else false
	var bg = ColorRect.new(); bg.color = Color(0.06, 0.05, 0.08); bg.set_anchors_preset(PRESET_FULL_RECT); add_child(bg)
	var v = VBoxContainer.new(); v.set_anchors_preset(PRESET_CENTER); v.custom_minimum_size = Vector2(480, 400)
	v.position = Vector2(-240, -200); v.alignment = BoxContainer.ALIGNMENT_CENTER; v.add_theme_constant_override("separation", 6); add_child(v)
	_l(v, "─── ROUND COMPLETE ───", 24, Color(0.85, 0.75, 0.5))
	_s(v, 10)
	var turns = rewards.get("turns", 0); var fg = rewards.get("fight_gold", 0)
	var intr = rewards.get("interest", 0); var hl = rewards.get("heal", 0)
	_l(v, "Cleared in %d turn%s" % [turns, "s" if turns != 1 else ""], 18, Color(0.8, 0.7, 0.4))
	var sc = Color(0.3, 0.8, 0.3) if fg >= 4 else Color(0.7, 0.7, 0.5) if fg >= 2 else Color(0.5, 0.4, 0.4)
	_l(v, "Speed Bonus: +%dg" % fg, 16, sc)
	_l(v, "( T1:+5g  T2:+4g  T3:+3g  T4:+2g  T5:+1g )", 10, Color(0.4, 0.4, 0.4))
	_l(v, "Interest: +%dg" % intr, 16, Color(0.9, 0.8, 0.3))
	_l(v, "( 1g per 5g banked, cap %d )" % GM.interest_cap, 10, Color(0.45, 0.4, 0.3))
	if hl > 0: _l(v, "Relic Heal: +%d HP" % hl, 14, Color(0.4, 0.7, 0.4))
	_l(v, "───────", 12, Color(0.3, 0.3, 0.3))
	_l(v, "Total Gold: %dg" % rewards.get("total", GM.gold), 22, Color(1, 0.9, 0.4))
	_l(v, "HP: %d/%d" % [GM.hp, GM.max_hp], 14, Color(0.7, 0.4, 0.4))
	_s(v, 10)
	var tip = ColorRect.new(); tip.color = Color(0.1, 0.09, 0.12); tip.custom_minimum_size = Vector2(440, 40); v.add_child(tip)
	var tl = Label.new(); tl.text = "💡 Save 25g+ for max +5g interest each round."; tl.add_theme_font_size_override("font_size", 10)
	tl.add_theme_color_override("font_color", Color(0.5, 0.5, 0.45)); tl.position = Vector2(8, 10); tip.add_child(tl)
	_s(v, 12)
	var bc = CenterContainer.new(); v.add_child(bc)
	var btn = Button.new(); btn.text = "  Continue  "; btn.custom_minimum_size = Vector2(200, 42); btn.add_theme_font_size_override("font_size", 16)
	btn.pressed.connect(func(): GM.screen_change.emit("map", {})); bc.add_child(btn)

func _l(p: Node, t: String, sz: int, c: Color) -> void:
	var l = Label.new(); l.text = t; l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", sz); l.add_theme_color_override("font_color", c); p.add_child(l)
func _s(p: Node, h: float) -> void:
	var s = Control.new(); s.custom_minimum_size = Vector2(0, h); p.add_child(s)
