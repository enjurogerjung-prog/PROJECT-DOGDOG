extends Node

# ============================================================
# RIBBON CARDS — Game Manager (Autoload)
# Card data, enemy data, relics, economy, run state
# ============================================================

signal screen_change_requested(screen_name: String, data: Dictionary)

# === CONSTANTS ===
const STARTING_GOLD: int = 10
const STARTING_HP: int = 70
const MAX_ENERGY: int = 3
const HAND_SIZE: int = 6
const DEFAULT_MAX_DECK: int = 40
const DEFAULT_MIN_DECK: int = 20
const DEFAULT_MAX_SIDEBOARD: int = 10
const DEFAULT_INTEREST_CAP: int = 5
const REROLL_BASE_COST: int = 1
const BOOSTER_BASE_COST: int = 4
const BOOSTER_ESCALATION: int = 2
const ROW2_ESCALATION: int = 5
const TYPE_ADVANTAGE_BONUS: float = 0.25
const TYPE_DISADVANTAGE_PENALTY: float = 0.1

# Archetype constants
const ARCH_ROCK: String = "rock"
const ARCH_SCISSORS: String = "scissors"
const ARCH_PAPER: String = "paper"
const ARCH_NEUTRAL: String = "neutral"

# Tier constants
const TIER_BASE: String = "base"
const TIER_BRONZE: String = "bronze"
const TIER_SILVER: String = "silver"
const TIER_GOLD: String = "gold"

const TIER_MULTIPLIERS: Dictionary = {
	"base": 1.0, "bronze": 1.4, "silver": 1.8, "gold": 2.5
}

const ARCHETYPE_COLORS: Dictionary = {
	"rock": Color(0.25, 0.4, 0.8),
	"scissors": Color(0.8, 0.2, 0.2),
	"paper": Color(0.85, 0.85, 0.8),
	"neutral": Color(0.5, 0.5, 0.5),
}

const ARCHETYPE_NAMES: Dictionary = {
	"rock": "Rock", "scissors": "Scissors", "paper": "Paper", "neutral": "Neutral"
}

# Type advantage triangle: key beats value
const TYPE_BEATS: Dictionary = {
	"rock": "scissors", "scissors": "paper", "paper": "rock"
}

# === CARD DATABASE ===
var CARDS: Dictionary = {
	# ─── NEUTRAL (Colorless) ───
	"strike": {"name": "Strike", "cost": 1, "type": "attack", "archetype": "neutral",
		"target": "single", "rarity": "common", "buy_price": 4,
		"desc": "Deal 6 damage.", "effects": [{"type": "damage", "value": 6}]},
	"guard": {"name": "Guard", "cost": 1, "type": "defend", "archetype": "neutral",
		"target": "self", "rarity": "common", "buy_price": 4,
		"desc": "Gain 5 Block.", "effects": [{"type": "block", "value": 5}]},
	"thread_sense": {"name": "Thread Sense", "cost": 0, "type": "skill", "archetype": "neutral",
		"target": "self", "rarity": "common", "buy_price": 4,
		"desc": "Draw 1 card.", "effects": [{"type": "draw", "value": 1}]},
	"gather_threads": {"name": "Gather Threads", "cost": 1, "type": "skill", "archetype": "neutral",
		"target": "self", "rarity": "uncommon", "buy_price": 8,
		"desc": "Draw 3 cards.", "effects": [{"type": "draw", "value": 3}]},
	"meditation": {"name": "Meditation", "cost": 0, "type": "skill", "archetype": "neutral",
		"target": "self", "rarity": "uncommon", "buy_price": 8,
		"desc": "Gain 1 Energy.", "effects": [{"type": "energy", "value": 1}]},
	"transcend": {"name": "Transcend", "cost": 2, "type": "skill", "archetype": "neutral",
		"target": "self", "rarity": "rare", "buy_price": 12,
		"desc": "Draw 3. +1 Energy. +5 Block.", "effects": [{"type": "draw", "value": 3}, {"type": "energy", "value": 1}, {"type": "block", "value": 5}]},

	# ─── ROCK (Blue) — Defensive + Big Damage ───
	"binding_strike": {"name": "Binding Strike", "cost": 1, "type": "attack", "archetype": "rock",
		"target": "single", "rarity": "common", "buy_price": 4,
		"desc": "Deal 7 damage.", "effects": [{"type": "damage", "value": 7}]},
	"stone_guard": {"name": "Stone Guard", "cost": 1, "type": "defend", "archetype": "rock",
		"target": "self", "rarity": "common", "buy_price": 4,
		"desc": "Gain 7 Block.", "effects": [{"type": "block", "value": 7}]},
	"woven_armor": {"name": "Woven Armor", "cost": 1, "type": "attack", "archetype": "rock",
		"target": "single", "rarity": "common", "buy_price": 4,
		"desc": "Deal 3 dmg. Gain 5 Block.", "effects": [{"type": "damage", "value": 3}, {"type": "block", "value": 5}]},
	"bedrock_slam": {"name": "Bedrock Slam", "cost": 2, "type": "attack", "archetype": "rock",
		"target": "single", "rarity": "uncommon", "buy_price": 8,
		"desc": "Deal 15 damage.", "effects": [{"type": "damage", "value": 15}]},
	"iron_weave": {"name": "Iron Weave", "cost": 2, "type": "defend", "archetype": "rock",
		"target": "self", "rarity": "uncommon", "buy_price": 8,
		"desc": "Gain 12 Block.", "effects": [{"type": "block", "value": 12}]},
	"fortify_thread": {"name": "Fortify Thread", "cost": 1, "type": "skill", "archetype": "rock",
		"target": "self", "rarity": "uncommon", "buy_price": 8,
		"desc": "Gain 4 Block. +2 Str.", "effects": [{"type": "block", "value": 4}, {"type": "strength", "value": 2}]},
	"avalanche": {"name": "Avalanche", "cost": 3, "type": "attack", "archetype": "rock",
		"target": "single", "rarity": "rare", "buy_price": 12,
		"desc": "Deal 28 damage.", "effects": [{"type": "damage", "value": 28}]},
	"unbreakable": {"name": "Unbreakable", "cost": 2, "type": "defend", "archetype": "rock",
		"target": "self", "rarity": "rare", "buy_price": 12,
		"desc": "Gain 20 Block. Cleanse debuffs.", "effects": [{"type": "block", "value": 20}, {"type": "cleanse", "value": 0}]},

	# ─── SCISSORS (Red) — Sustained + Lifesteal ───
	"quick_cut": {"name": "Quick Cut", "cost": 1, "type": "attack", "archetype": "scissors",
		"target": "single", "rarity": "common", "buy_price": 4,
		"desc": "Deal 4 dmg. Heal 2.", "effects": [{"type": "damage", "value": 4}, {"type": "heal", "value": 2}]},
	"shred": {"name": "Shred", "cost": 1, "type": "attack", "archetype": "scissors",
		"target": "single", "rarity": "common", "buy_price": 4,
		"desc": "Deal 3 dmg x2.", "effects": [{"type": "damage", "value": 3}, {"type": "damage", "value": 3}]},
	"blood_draw": {"name": "Blood Draw", "cost": 0, "type": "attack", "archetype": "scissors",
		"target": "single", "rarity": "common", "buy_price": 4,
		"desc": "Deal 3 dmg. Draw 1.", "effects": [{"type": "damage", "value": 3}, {"type": "draw", "value": 1}]},
	"thousand_threads": {"name": "Thousand Threads", "cost": 2, "type": "attack", "archetype": "scissors",
		"target": "single", "rarity": "uncommon", "buy_price": 8,
		"desc": "Deal 2 dmg x5.", "effects": [{"type": "damage", "value": 2}, {"type": "damage", "value": 2}, {"type": "damage", "value": 2}, {"type": "damage", "value": 2}, {"type": "damage", "value": 2}]},
	"drain_life": {"name": "Drain Life", "cost": 1, "type": "attack", "archetype": "scissors",
		"target": "single", "rarity": "uncommon", "buy_price": 8,
		"desc": "Deal 6 dmg. Heal equal.", "effects": [{"type": "damage", "value": 6}, {"type": "lifesteal", "value": 6}]},
	"razor_ribbon": {"name": "Razor Ribbon", "cost": 1, "type": "attack", "archetype": "scissors",
		"target": "all", "rarity": "uncommon", "buy_price": 8,
		"desc": "Deal 4 dmg ALL. 2 Psn ALL.", "effects": [{"type": "damage", "value": 4}, {"type": "poison", "value": 2}]},
	"death_of_cuts": {"name": "Death of Cuts", "cost": 3, "type": "attack", "archetype": "scissors",
		"target": "single", "rarity": "rare", "buy_price": 12,
		"desc": "Deal 3 dmg x8.", "effects": [{"type": "damage", "value": 3}, {"type": "damage", "value": 3}, {"type": "damage", "value": 3}, {"type": "damage", "value": 3}, {"type": "damage", "value": 3}, {"type": "damage", "value": 3}, {"type": "damage", "value": 3}, {"type": "damage", "value": 3}]},
	"blood_feast": {"name": "Blood Feast", "cost": 2, "type": "attack", "archetype": "scissors",
		"target": "single", "rarity": "rare", "buy_price": 12,
		"desc": "Deal 10 dmg. Heal 10.", "effects": [{"type": "damage", "value": 10}, {"type": "heal", "value": 10}]},

	# ─── PAPER (White) — Control + Shields ───
	"seal_thread": {"name": "Seal Thread", "cost": 1, "type": "skill", "archetype": "paper",
		"target": "single", "rarity": "common", "buy_price": 4,
		"desc": "Apply 2 Weak.", "effects": [{"type": "weak", "value": 2}]},
	"nullify": {"name": "Nullify", "cost": 1, "type": "defend", "archetype": "paper",
		"target": "single", "rarity": "common", "buy_price": 4,
		"desc": "Gain 6 Block. 1 Vuln.", "effects": [{"type": "block", "value": 6}, {"type": "vulnerable", "value": 1}]},
	"thread_trap": {"name": "Thread Trap", "cost": 1, "type": "attack", "archetype": "paper",
		"target": "single", "rarity": "common", "buy_price": 4,
		"desc": "Deal 4 dmg. 3 Poison.", "effects": [{"type": "damage", "value": 4}, {"type": "poison", "value": 3}]},
	"unravel_mind": {"name": "Unravel Mind", "cost": 2, "type": "skill", "archetype": "paper",
		"target": "single", "rarity": "uncommon", "buy_price": 8,
		"desc": "Apply 3 Weak + 2 Vuln.", "effects": [{"type": "weak", "value": 3}, {"type": "vulnerable", "value": 2}]},
	"silken_shield": {"name": "Silken Shield", "cost": 1, "type": "defend", "archetype": "paper",
		"target": "self", "rarity": "uncommon", "buy_price": 8,
		"desc": "Gain 8 Block. 1 Weak ALL.", "effects": [{"type": "block", "value": 8}, {"type": "weak_all", "value": 1}]},
	"venom_cloud": {"name": "Venom Cloud", "cost": 2, "type": "skill", "archetype": "paper",
		"target": "all", "rarity": "uncommon", "buy_price": 8,
		"desc": "Apply 5 Poison ALL.", "effects": [{"type": "poison", "value": 5}]},
	"grand_seal": {"name": "Grand Seal", "cost": 3, "type": "skill", "archetype": "paper",
		"target": "single", "rarity": "rare", "buy_price": 12,
		"desc": "3 Weak + 3 Vuln + 6 Psn.", "effects": [{"type": "weak", "value": 3}, {"type": "vulnerable", "value": 3}, {"type": "poison", "value": 6}]},
	"mirror_weave": {"name": "Mirror Weave", "cost": 2, "type": "defend", "archetype": "paper",
		"target": "self", "rarity": "rare", "buy_price": 12,
		"desc": "Gain 16 Block. +2 Str.", "effects": [{"type": "block", "value": 16}, {"type": "strength", "value": 2}]},
}

# === ENEMY DATABASE ===
var ENEMIES: Dictionary = {
	# ─── ROCK enemies ───
	"stone_sentinel": {"name": "Stone Sentinel", "archetype": "rock", "min_hp": 28, "max_hp": 35,
		"intents": [{"type": "defend", "value": 8}, {"type": "attack", "value": 10}, {"type": "attack", "value": 14}]},
	"granite_hound": {"name": "Granite Hound", "archetype": "rock", "min_hp": 18, "max_hp": 24,
		"intents": [{"type": "attack", "value": 8}, {"type": "attack", "value": 12}]},
	"iron_golem": {"name": "Iron Golem", "archetype": "rock", "min_hp": 35, "max_hp": 45,
		"intents": [{"type": "defend", "value": 10}, {"type": "defend", "value": 6}, {"type": "attack", "value": 20}]},
	# ─── SCISSORS enemies ───
	"frayed_hound": {"name": "Frayed Hound", "archetype": "scissors", "min_hp": 14, "max_hp": 20,
		"intents": [{"type": "attack", "value": 5}, {"type": "attack", "value": 5}, {"type": "attack", "value": 8}]},
	"thread_ripper": {"name": "Thread Ripper", "archetype": "scissors", "min_hp": 20, "max_hp": 28,
		"intents": [{"type": "attack", "value": 4}, {"type": "attack", "value": 4}, {"type": "lifesteal_attack", "value": 6}]},
	"blood_weaver": {"name": "Blood Weaver", "archetype": "scissors", "min_hp": 24, "max_hp": 32,
		"intents": [{"type": "debuff_poison", "value": 3}, {"type": "attack", "value": 6}, {"type": "attack", "value": 6}, {"type": "lifesteal_attack", "value": 8}]},
	# ─── PAPER enemies ───
	"hollow_acolyte": {"name": "Hollow Acolyte", "archetype": "paper", "min_hp": 22, "max_hp": 28,
		"intents": [{"type": "debuff_weak", "value": 2}, {"type": "attack", "value": 7}, {"type": "defend", "value": 8}]},
	"threadbare_shade": {"name": "Threadbare Shade", "archetype": "paper", "min_hp": 16, "max_hp": 22,
		"intents": [{"type": "debuff_poison", "value": 4}, {"type": "attack", "value": 5}, {"type": "debuff_vulnerable", "value": 2}]},
	"void_singer": {"name": "Void Singer", "archetype": "paper", "min_hp": 26, "max_hp": 34,
		"intents": [{"type": "debuff_weak", "value": 2}, {"type": "debuff_vulnerable", "value": 2}, {"type": "attack", "value": 10}]},

	# ─── BOSSES ───
	# Act 1 Bosses
	"iron_warden": {"name": "The Iron Warden", "archetype": "rock", "min_hp": 60, "max_hp": 70,
		"intents": [{"type": "defend", "value": 12}, {"type": "attack", "value": 10}, {"type": "buff_strength", "value": 2}, {"type": "attack", "value": 16}, {"type": "defend", "value": 8}]},
	"crimson_loom": {"name": "The Crimson Loom", "archetype": "scissors", "min_hp": 50, "max_hp": 60,
		"intents": [{"type": "attack", "value": 5}, {"type": "attack", "value": 5}, {"type": "lifesteal_attack", "value": 8}, {"type": "attack", "value": 7}, {"type": "lifesteal_attack", "value": 10}]},
	"pale_weaver": {"name": "The Pale Weaver", "archetype": "paper", "min_hp": 55, "max_hp": 65,
		"intents": [{"type": "debuff_weak", "value": 2}, {"type": "debuff_poison", "value": 4}, {"type": "attack", "value": 8}, {"type": "debuff_vulnerable", "value": 2}, {"type": "defend", "value": 10}]},
	# Act 2 Bosses (some dual-type)
	"stone_mother": {"name": "The Stone Mother", "archetype": "rock", "archetype2": "paper", "min_hp": 85, "max_hp": 95,
		"intents": [{"type": "defend", "value": 14}, {"type": "debuff_weak", "value": 2}, {"type": "attack", "value": 14}, {"type": "defend", "value": 10}, {"type": "buff_strength", "value": 3}, {"type": "attack", "value": 20}]},
	"scarlet_twins": {"name": "The Scarlet Twins", "archetype": "scissors", "archetype2": "rock", "min_hp": 75, "max_hp": 88,
		"intents": [{"type": "attack", "value": 6}, {"type": "attack", "value": 6}, {"type": "attack", "value": 12}, {"type": "defend", "value": 8}, {"type": "lifesteal_attack", "value": 10}, {"type": "attack", "value": 16}]},
	"null_prophet": {"name": "The Null Prophet", "archetype": "paper", "archetype2": "scissors", "min_hp": 70, "max_hp": 82,
		"intents": [{"type": "debuff_weak", "value": 2}, {"type": "debuff_vulnerable", "value": 2}, {"type": "attack", "value": 8}, {"type": "debuff_poison", "value": 6}, {"type": "lifesteal_attack", "value": 12}]},
	# Act 3 Bosses
	"the_adamantine": {"name": "The Adamantine", "archetype": "rock", "min_hp": 110, "max_hp": 130,
		"intents": [{"type": "defend", "value": 16}, {"type": "buff_strength", "value": 3}, {"type": "attack", "value": 18}, {"type": "defend", "value": 12}, {"type": "attack", "value": 24}, {"type": "attack", "value": 30}]},
	"the_exsanguinator": {"name": "The Exsanguinator", "archetype": "scissors", "min_hp": 100, "max_hp": 120,
		"intents": [{"type": "attack", "value": 6}, {"type": "attack", "value": 6}, {"type": "attack", "value": 6}, {"type": "lifesteal_attack", "value": 14}, {"type": "buff_strength", "value": 2}, {"type": "attack", "value": 10}, {"type": "lifesteal_attack", "value": 18}]},
	"the_grand_weaver": {"name": "The Grand Weaver", "archetype": "paper", "archetype2": "rock", "min_hp": 105, "max_hp": 125,
		"intents": [{"type": "debuff_weak", "value": 3}, {"type": "debuff_vulnerable", "value": 3}, {"type": "defend", "value": 14}, {"type": "attack", "value": 16}, {"type": "debuff_poison", "value": 8}, {"type": "buff_strength", "value": 3}, {"type": "attack", "value": 22}]},
}

# Boss pools per act
var BOSS_POOLS: Array = [
	["iron_warden", "crimson_loom", "pale_weaver"],
	["stone_mother", "scarlet_twins", "null_prophet"],
	["the_adamantine", "the_exsanguinator", "the_grand_weaver"],
]

# Enemy pools per archetype (non-boss)
var ENEMY_POOLS: Dictionary = {
	"rock": ["stone_sentinel", "granite_hound", "iron_golem"],
	"scissors": ["frayed_hound", "thread_ripper", "blood_weaver"],
	"paper": ["hollow_acolyte", "threadbare_shade", "void_singer"],
}

# === RELIC DATABASE ===
var RELICS: Dictionary = {
	"thread_spool": {"name": "Thread Spool", "desc": "+1 hand size.", "buy_price": 15,
		"effect": "hand_size", "value": 1},
	"council_seal": {"name": "Council Seal", "desc": "+1 energy per turn.", "buy_price": 20,
		"effect": "max_energy", "value": 1},
	"blood_ribbon": {"name": "Blood Ribbon", "desc": "Heal 3 after each fight.", "buy_price": 10,
		"effect": "post_fight_heal", "value": 3},
	"gold_thread": {"name": "Gold Thread", "desc": "Interest cap +2.", "buy_price": 12,
		"effect": "interest_cap", "value": 2},
	"sharpening_stone": {"name": "Sharpening Stone", "desc": "+1 Str at fight start (resets).", "buy_price": 15,
		"effect": "start_strength", "value": 1},
	"shield_charm": {"name": "Shield Charm", "desc": "+4 Block at fight start (resets).", "buy_price": 12,
		"effect": "start_block", "value": 4},
	"void_lens": {"name": "Void Lens", "desc": "+2 sideboard size.", "buy_price": 10,
		"effect": "sideboard_size", "value": 2},
	"compact_loom": {"name": "Compact Loom", "desc": "-3 min deck size.", "buy_price": 15,
		"effect": "min_deck_size", "value": -3, "needs_confirm": true},
	"merchants_eye": {"name": "Merchant's Eye", "desc": "Shop cards cost 1g less.", "buy_price": 10,
		"effect": "shop_discount", "value": 1},
	"war_drum": {"name": "War Drum", "desc": "Synergy triggers at 2 cards.", "buy_price": 18,
		"effect": "synergy_threshold", "value": -1},
}

# Starter deck
var STARTER_DECK: Array = [
	"strike", "strike", "strike", "strike", "strike", "strike",
	"guard", "guard", "guard", "guard", "guard",
	"thread_sense", "thread_sense",
	"binding_strike", "stone_guard",
	"quick_cut", "shred",
	"seal_thread", "nullify",
	"blood_draw",
]

# Skip rewards pool
var SKIP_REWARDS: Array = [
	{"type": "gold", "value": 4, "label": "+4 Gold"},
	{"type": "gold", "value": 6, "label": "+6 Gold"},
	{"type": "heal", "value": 8, "label": "Heal 8 HP"},
	{"type": "heal", "value": 12, "label": "Heal 12 HP"},
	{"type": "random_card", "value": 0, "label": "Random Card"},
	{"type": "random_relic_discount", "value": 5, "label": "Next Relic -5g"},
]

# ============================================================
# RUN STATE
# ============================================================
var player_hp: int = STARTING_HP
var player_max_hp: int = STARTING_HP
var gold: int = STARTING_GOLD
var deck: Array = []  # Array of {id: String, tier: String}
var sideboard: Array = []
var owned_relics: Array = []  # Array of relic IDs

var max_deck_size: int = DEFAULT_MAX_DECK
var min_deck_size: int = DEFAULT_MIN_DECK
var max_sideboard_size: int = DEFAULT_MAX_SIDEBOARD
var interest_cap: int = DEFAULT_INTEREST_CAP
var hand_size_bonus: int = 0
var energy_bonus: int = 0
var synergy_threshold: int = 3
var shop_discount: int = 0
var relic_discount: int = 0

var current_act: int = 0
var current_level: int = 0
var current_phase: int = 0  # 0, 1, 2 (phase 3 = index 2)
var act_levels: Array = []  # Generated level data for current act
var infinite_cycle: int = 0  # 0 = first run, 1+ = infinite scaling
var run_active: bool = false

var reroll_cost: int = REROLL_BASE_COST
var booster_purchases: Dictionary = {"rock": 0, "scissors": 0, "paper": 0}
var row2_purchases: int = 0
var last_fight_turns: int = 0

# ============================================================
# RUN MANAGEMENT
# ============================================================

func start_new_run() -> void:
	player_hp = STARTING_HP
	player_max_hp = STARTING_HP
	gold = STARTING_GOLD
	deck.clear()
	sideboard.clear()
	owned_relics.clear()
	
	max_deck_size = DEFAULT_MAX_DECK
	min_deck_size = DEFAULT_MIN_DECK
	max_sideboard_size = DEFAULT_MAX_SIDEBOARD
	interest_cap = DEFAULT_INTEREST_CAP
	hand_size_bonus = 0
	energy_bonus = 0
	synergy_threshold = 3
	shop_discount = 0
	relic_discount = 0
	reroll_cost = REROLL_BASE_COST
	booster_purchases = {"rock": 0, "scissors": 0, "paper": 0}
	row2_purchases = 0
	infinite_cycle = 0
	
	# Build starter deck
	for card_id in STARTER_DECK:
		deck.append({"id": card_id, "tier": TIER_BASE})
	
	current_act = 0
	current_level = 0
	current_phase = 0
	_generate_act()
	run_active = true
	screen_change_requested.emit("map", {})

func _generate_act() -> void:
	act_levels.clear()
	var num_levels: int
	if current_act == 0:
		num_levels = 4
	else:
		num_levels = randi_range(3, 6)
	
	var archetypes = [ARCH_ROCK, ARCH_SCISSORS, ARCH_PAPER]
	
	for i in range(num_levels):
		var level_arch = archetypes[randi() % archetypes.size()]
		# Pick boss from pool
		var boss_pool = BOSS_POOLS[mini(current_act, BOSS_POOLS.size() - 1)]
		# Try to match archetype
		var boss_id = boss_pool[randi() % boss_pool.size()]
		for bid in boss_pool:
			if ENEMIES[bid]["archetype"] == level_arch:
				boss_id = bid
				break
		
		# Generate 3 phases
		var phases: Array = []
		# Phase 1 & 2: regular encounters
		for p in range(2):
			var enemy_pool = ENEMY_POOLS[level_arch]
			var enemy_count = randi_range(1, 3)
			var enemies_list: Array = []
			for e in range(enemy_count):
				enemies_list.append(enemy_pool[randi() % enemy_pool.size()])
			phases.append({
				"enemies": enemies_list,
				"is_boss": false,
				"skippable": true,
			})
		# Phase 3: boss
		phases.append({
			"enemies": [boss_id],
			"is_boss": true,
			"skippable": false,
		})
		
		act_levels.append({
			"archetype": level_arch,
			"boss_id": boss_id,
			"phases": phases,
		})

func get_current_phase_data() -> Dictionary:
	if current_level < act_levels.size():
		var level = act_levels[current_level]
		if current_phase < level["phases"].size():
			return level["phases"][current_phase]
	return {}

func get_current_level_data() -> Dictionary:
	if current_level < act_levels.size():
		return act_levels[current_level]
	return {}

func advance_phase() -> void:
	current_phase += 1
	if current_phase >= 3:
		current_phase = 0
		current_level += 1
		if current_level >= act_levels.size():
			current_level = 0
			current_act += 1
			if current_act >= 3:
				# Infinite scaling — loop back
				infinite_cycle += 1
				current_act = 0
			_generate_act()

func get_act_name() -> String:
	var cycle_str = "" if infinite_cycle == 0 else " (Cycle %d)" % (infinite_cycle + 1)
	match current_act:
		0: return "Act I — The Fraying" + cycle_str
		1: return "Act II — The Weaving" + cycle_str
		2: return "Act III — The Binding" + cycle_str
	return "Act ???" + cycle_str

func get_scaling_multiplier() -> float:
	return 1.0 + 0.3 * float(infinite_cycle)

# ============================================================
# ECONOMY
# ============================================================

func calculate_interest() -> int:
	var raw = gold / 5
	return mini(raw, interest_cap)

func calculate_fight_gold(turns: int) -> int:
	last_fight_turns = turns
	if turns <= 0:
		return 5
	return maxi(6 - turns, 0)  # Turn 1=5, Turn 2=4, ... Turn 5=1, Turn 6+=0

func apply_post_fight_rewards(turns: int) -> Dictionary:
	var fight_gold = calculate_fight_gold(turns)
	var interest = calculate_interest()
	
	# Relic: post fight heal
	var heal_amount = 0
	for relic_id in owned_relics:
		var r = RELICS[relic_id]
		if r["effect"] == "post_fight_heal":
			heal_amount += r["value"]
	if heal_amount > 0:
		heal_player(heal_amount)
	
	gold += fight_gold + interest
	return {"fight_gold": fight_gold, "interest": interest, "heal": heal_amount, "turns": turns, "total_gold": gold}

func get_sell_price(card_entry: Dictionary) -> int:
	var card_data = CARDS.get(card_entry["id"], {})
	var base_price = card_data.get("buy_price", 4)
	var tier_mult = {"base": 1.0, "bronze": 1.4, "silver": 1.8, "gold": 2.5}
	var value = int(base_price * tier_mult.get(card_entry["tier"], 1.0) * 0.25)
	return maxi(value, 1)

func get_booster_cost(archetype: String) -> int:
	return BOOSTER_BASE_COST + booster_purchases.get(archetype, 0) * BOOSTER_ESCALATION

func get_row2_item_cost(base_price: int) -> int:
	return base_price + row2_purchases * ROW2_ESCALATION

# ============================================================
# DECK MANAGEMENT
# ============================================================

func add_card_to_deck(card_id: String, tier: String = TIER_BASE) -> bool:
	if deck.size() < max_deck_size:
		deck.append({"id": card_id, "tier": tier})
		return true
	return false

func add_card_to_sideboard(card_id: String, tier: String = TIER_BASE) -> bool:
	if sideboard.size() < max_sideboard_size:
		sideboard.append({"id": card_id, "tier": tier})
		return true
	return false

func move_to_sideboard(deck_idx: int) -> bool:
	if deck_idx < 0 or deck_idx >= deck.size():
		return false
	if sideboard.size() >= max_sideboard_size:
		return false
	if deck.size() <= min_deck_size:
		return false
	sideboard.append(deck[deck_idx])
	deck.remove_at(deck_idx)
	return true

func move_to_deck(sb_idx: int) -> bool:
	if sb_idx < 0 or sb_idx >= sideboard.size():
		return false
	if deck.size() >= max_deck_size:
		return false
	deck.append(sideboard[sb_idx])
	sideboard.remove_at(sb_idx)
	return true

func sell_card_from_deck(deck_idx: int) -> int:
	if deck_idx < 0 or deck_idx >= deck.size():
		return 0
	if deck.size() <= min_deck_size:
		return 0
	var price = get_sell_price(deck[deck_idx])
	deck.remove_at(deck_idx)
	gold += price
	return price

func sell_card_from_sideboard(sb_idx: int) -> int:
	if sb_idx < 0 or sb_idx >= sideboard.size():
		return 0
	var price = get_sell_price(sideboard[sb_idx])
	sideboard.remove_at(sb_idx)
	gold += price
	return price

func can_combine(card_id: String, tier: String, source: String) -> int:
	# Returns count of matching cards in deck + sideboard
	var count = 0
	var list = deck if source == "deck" else sideboard
	for entry in list:
		if entry["id"] == card_id and entry["tier"] == tier:
			count += 1
	return count

func combine_cards(card_id: String, tier: String) -> bool:
	# Find 3 matching cards across deck, remove them, add 1 upgraded card to deck
	var next_tier = _next_tier(tier)
	if next_tier == "":
		return false
	
	var indices_deck: Array = []
	var indices_sb: Array = []
	for i in range(deck.size()):
		if deck[i]["id"] == card_id and deck[i]["tier"] == tier:
			indices_deck.append(i)
	for i in range(sideboard.size()):
		if sideboard[i]["id"] == card_id and sideboard[i]["tier"] == tier:
			indices_sb.append(i)
	
	if indices_deck.size() + indices_sb.size() < 3:
		return false
	
	# Remove 3 cards, prioritize deck first
	var to_remove_deck: Array = []
	var to_remove_sb: Array = []
	var remaining = 3
	for idx in indices_deck:
		if remaining <= 0: break
		to_remove_deck.append(idx)
		remaining -= 1
	for idx in indices_sb:
		if remaining <= 0: break
		to_remove_sb.append(idx)
		remaining -= 1
	
	# Remove in reverse order to preserve indices
	to_remove_deck.sort()
	to_remove_deck.reverse()
	for idx in to_remove_deck:
		deck.remove_at(idx)
	to_remove_sb.sort()
	to_remove_sb.reverse()
	for idx in to_remove_sb:
		sideboard.remove_at(idx)
	
	# Add upgraded card
	deck.append({"id": card_id, "tier": next_tier})
	return true

func _next_tier(tier: String) -> String:
	match tier:
		TIER_BASE: return TIER_BRONZE
		TIER_BRONZE: return TIER_SILVER
		TIER_SILVER: return TIER_GOLD
	return ""

# ============================================================
# RELIC MANAGEMENT
# ============================================================

func add_relic(relic_id: String) -> void:
	owned_relics.append(relic_id)
	var r = RELICS[relic_id]
	match r["effect"]:
		"hand_size": hand_size_bonus += r["value"]
		"max_energy": energy_bonus += r["value"]
		"interest_cap": interest_cap += r["value"]
		"sideboard_size": max_sideboard_size += r["value"]
		"min_deck_size": min_deck_size = maxi(min_deck_size + r["value"], 5)
		"shop_discount": shop_discount += r["value"]
		"synergy_threshold": synergy_threshold = maxi(synergy_threshold + r["value"], 1)

func has_relic(relic_id: String) -> bool:
	return relic_id in owned_relics

# ============================================================
# CARD UTILITY
# ============================================================

func get_card_at_tier(card_id: String, tier: String) -> Dictionary:
	var base = CARDS[card_id].duplicate(true)
	var mult = TIER_MULTIPLIERS.get(tier, 1.0)
	var new_effects: Array = []
	for effect in base["effects"]:
		var e = effect.duplicate()
		if e.has("value") and (e["value"] is int or e["value"] is float):
			e["value"] = int(e["value"] * mult)
			if e["value"] < 1 and effect["value"] > 0:
				e["value"] = 1
		new_effects.append(e)
	base["effects"] = new_effects
	if tier == TIER_GOLD:
		base["cost"] = maxi(base["cost"] - 1, 0)
	base["tier"] = tier
	# Update desc with scaled values
	base["desc"] = _generate_desc(base)
	return base

func _generate_desc(card: Dictionary) -> String:
	var parts: Array = []
	for e in card["effects"]:
		match e["type"]:
			"damage": parts.append("Deal %d dmg." % e["value"])
			"block": parts.append("+%d Block." % e["value"])
			"heal": parts.append("Heal %d." % e["value"])
			"draw": parts.append("Draw %d." % e["value"])
			"energy": parts.append("+%d Energy." % e["value"])
			"poison": parts.append("%d Psn." % e["value"])
			"weak": parts.append("%d Weak." % e["value"])
			"vulnerable": parts.append("%d Vuln." % e["value"])
			"strength": parts.append("+%d Str." % e["value"])
			"self_damage": parts.append("Lose %d HP." % e["value"])
			"lifesteal": parts.append("Heal %d." % e["value"])
			"cleanse": parts.append("Cleanse.")
			"weak_all": parts.append("%d Weak ALL." % e["value"])
	return " ".join(parts)

func get_card_color(card_id: String) -> Color:
	var arch = CARDS[card_id].get("archetype", "neutral")
	return ARCHETYPE_COLORS.get(arch, Color(0.5, 0.5, 0.5))

func get_tier_prefix(tier: String) -> String:
	match tier:
		TIER_BRONZE: return "◆ "
		TIER_SILVER: return "◇ "
		TIER_GOLD: return "★ "
	return ""

func get_tier_color(tier: String) -> Color:
	match tier:
		TIER_BRONZE: return Color(0.72, 0.45, 0.2)
		TIER_SILVER: return Color(0.75, 0.75, 0.8)
		TIER_GOLD: return Color(1.0, 0.85, 0.3)
	return Color(0.6, 0.6, 0.6)

func get_type_advantage(attacker_arch: String, defender_arch: String) -> float:
	if attacker_arch == "neutral" or defender_arch == "neutral":
		return 0.0
	if TYPE_BEATS.get(attacker_arch, "") == defender_arch:
		return TYPE_ADVANTAGE_BONUS
	if TYPE_BEATS.get(defender_arch, "") == attacker_arch:
		return -TYPE_DISADVANTAGE_PENALTY
	return 0.0

func get_synergy_bonus_desc(archetype: String) -> String:
	match archetype:
		"rock": return "+5 Block"
		"scissors": return "3 dmg to ALL"
		"paper": return "1 Weak to ALL"
		"neutral": return "Draw 1"
	return ""

func get_cards_by_archetype(archetype: String) -> Array:
	var result: Array = []
	for card_id in CARDS:
		if CARDS[card_id]["archetype"] == archetype:
			result.append(card_id)
	return result

func get_random_shop_cards(count: int) -> Array:
	var all_cards = CARDS.keys()
	all_cards.shuffle()
	return all_cards.slice(0, count)

func get_random_shop_relics(count: int) -> Array:
	var available: Array = []
	for relic_id in RELICS:
		if relic_id not in owned_relics:
			available.append(relic_id)
	available.shuffle()
	return available.slice(0, mini(count, available.size()))

# ============================================================
# INTENT DISPLAY
# ============================================================

func get_intent_text(intent: Dictionary) -> String:
	match intent["type"]:
		"attack": return "ATK %d" % intent["value"]
		"defend": return "DEF %d" % intent["value"]
		"buff_strength": return "STR +%d" % intent["value"]
		"debuff_poison": return "PSN %d" % intent["value"]
		"debuff_weak": return "WEAK %d" % intent["value"]
		"debuff_vulnerable": return "VULN %d" % intent["value"]
		"lifesteal_attack": return "DRAIN %d" % intent["value"]
	return "???"

func get_intent_color(intent: Dictionary) -> Color:
	match intent["type"]:
		"attack", "lifesteal_attack": return Color(1.0, 0.3, 0.3)
		"defend": return Color(0.3, 0.5, 1.0)
		"buff_strength": return Color(1.0, 0.8, 0.2)
		"debuff_poison": return Color(0.3, 0.8, 0.3)
		"debuff_weak", "debuff_vulnerable": return Color(0.8, 0.4, 0.8)
	return Color.WHITE

func heal_player(amount: int) -> void:
	player_hp = mini(player_hp + amount, player_max_hp)

func damage_player(amount: int) -> void:
	player_hp = maxi(player_hp - amount, 0)
