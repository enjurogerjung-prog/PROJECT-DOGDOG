extends Control

# ============================================================
# Main Scene Controller — switches between game screens
# ============================================================

var current_screen: Control = null

func _ready() -> void:
	GameManager.screen_change_requested.connect(_on_screen_change)
	_show_screen("menu", {})

func _show_screen(screen_name: String, data: Dictionary) -> void:
	# Remove current screen
	if current_screen:
		current_screen.queue_free()
		current_screen = null
	
	# Wait a frame for cleanup
	await get_tree().process_frame
	
	# Create new screen
	var screen: Control = null
	match screen_name:
		"menu":
			var script = preload("res://scripts/main_menu.gd")
			screen = Control.new()
			screen.set_script(script)
		"map":
			var script = preload("res://scripts/map_screen.gd")
			screen = Control.new()
			screen.set_script(script)
		"combat":
			var script = preload("res://scripts/combat_screen.gd")
			screen = Control.new()
			screen.set_script(script)
			screen.set_meta("encounter_data", data.get("encounter", {}))
		"reward":
			var script = preload("res://scripts/card_reward.gd")
			screen = Control.new()
			screen.set_script(script)
		"game_over":
			var script = preload("res://scripts/game_over_screen.gd")
			screen = Control.new()
			screen.set_script(script)
			screen.set_meta("victory", data.get("victory", false))
	
	if screen:
		screen.set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(screen)
		current_screen = screen

func _on_screen_change(screen_name: String, data: Dictionary) -> void:
	_show_screen(screen_name, data)
