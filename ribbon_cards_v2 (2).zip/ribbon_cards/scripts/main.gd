extends Control

var current_screen: Control = null

func _ready() -> void:
	GameManager.screen_change_requested.connect(_on_screen_change)
	_show_screen("menu", {})

func _show_screen(screen_name: String, data: Dictionary) -> void:
	if current_screen:
		current_screen.queue_free()
		current_screen = null
	await get_tree().process_frame
	
	var screen: Control = null
	var scripts = {
		"menu": preload("res://scripts/main_menu.gd"),
		"map": preload("res://scripts/map_screen.gd"),
		"combat": preload("res://scripts/combat_screen.gd"),
		"shop": preload("res://scripts/shop_screen.gd"),
		"round_summary": preload("res://scripts/round_summary.gd"),
		"deck_manager": preload("res://scripts/deck_screen.gd"),
		"booster_open": preload("res://scripts/booster_screen.gd"),
		"game_over": preload("res://scripts/game_over_screen.gd"),
	}
	
	if scripts.has(screen_name):
		screen = Control.new()
		screen.set_script(scripts[screen_name])
		for key in data:
			screen.set_meta(key, data[key])
	
	if screen:
		screen.set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(screen)
		current_screen = screen

func _on_screen_change(screen_name: String, data: Dictionary) -> void:
	_show_screen(screen_name, data)
