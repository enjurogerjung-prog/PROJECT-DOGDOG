extends Control

var event_data: Dictionary = {}

func _ready() -> void:
	event_data = get_meta("event") if has_meta("event") else GM.EVENTS[0]
	_build()

func _build() -> void:
	for c in get_children(): c.queue_free()
	var bg = ColorRect.new(); bg.color = Color(0.06, 0.05, 0.09); bg.set_anchors_preset(PRESET_FULL_RECT); add_child(bg)
	var v = VBoxContainer.new(); v.set_anchors_preset(PRESET_CENTER); v.custom_minimum_size = Vector2(600, 420)
	v.position = Vector2(-300, -210); v.alignment = BoxContainer.ALIGNMENT_CENTER; v.add_theme_constant_override("separation", 10); add_child(v)
	_l(v, "❓ EVENT", 14, Color(0.5, 0.5, 0.6))
	_l(v, event_data.get("title", "???"), 26, Color(0.85, 0.75, 0.6))
	var sp = Control.new(); sp.custom_minimum_size = Vector2(0, 5); v.add_child(sp)
	var dl = Label.new(); dl.text = event_data.get("desc", ""); dl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	dl.add_theme_font_size_override("font_size", 15); dl.add_theme_color_override("font_color", Color(0.7, 0.65, 0.6))
	dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; dl.custom_minimum_size = Vector2(560, 40); v.add_child(dl)
	var sp2 = Control.new(); sp2.custom_minimum_size = Vector2(0, 10); v.add_child(sp2)
	_l(v, "HP: %d/%d  |  Gold: %dg" % [GM.hp, GM.max_hp, GM.gold], 13, Color(0.5, 0.5, 0.5))
	var sp3 = Control.new(); sp3.custom_minimum_size = Vector2(0, 10); v.add_child(sp3)
	for choice in event_data.get("choices", []):
		var bc = CenterContainer.new(); v.add_child(bc)
		var btn = Button.new(); btn.text = "  " + choice.get("text", "???") + "  "; btn.custom_minimum_size = Vector2(500, 40)
		btn.add_theme_font_size_override("font_size", 14)
		btn.pressed.connect(_on_choice.bind(choice))
		bc.add_child(btn)

func _on_choice(choice: Dictionary) -> void:
	match choice.get("type", "nothing"):
		"gold":
			GM.gold += choice.get("value", 0)
			_show_result("+%d Gold" % choice.get("value", 0))
		"heal":
			GM.heal(choice.get("value", 0))
			_show_result("Healed %d HP" % choice.get("value", 0))
		"random_card":
			var cards = GM.rand_shop_cards(1)
			if cards.size() > 0: GM.add_to_deck(cards[0])
			_show_result("Gained a random card!")
		"add_card":
			GM.add_to_deck(choice.get("card", "strike"))
			var cd = GM.CARDS.get(choice.get("card", "strike"), {})
			_show_result("Gained %s!" % cd.get("name", "a card"))
		"relic_trade":
			GM.damage(choice.get("hp_cost", 5))
			var rels = GM.rand_relics(1)
			if rels.size() > 0: GM.add_relic(rels[0]); _show_result("Lost %d HP, gained %s!" % [choice.get("hp_cost", 5), GM.RELICS[rels[0]]["name"]])
			else: _show_result("Lost %d HP, but no relics available..." % choice.get("hp_cost", 5))
		"minigame":
			var game_type = choice.get("game", "roulette")
			var mg = MiniGame.create(self, game_type)
			var result = await mg.game_finished
			if result >= 0.5:
				var success = choice.get("success", {})
				if success.has("heal"): GM.heal(success["heal"])
				if success.has("gold"): GM.gold += success["gold"]
				if success.has("relic_discount"): GM.relic_disc += success["relic_discount"]
				_show_result("Success! " + _describe_reward(success))
			else:
				var fail = choice.get("fail", {})
				if fail.has("damage"): GM.damage(fail["damage"])
				if fail.has("gold") and fail["gold"] < 0: GM.gold = maxi(GM.gold + fail["gold"], 0)
				_show_result("Failed... " + _describe_penalty(fail))
		"nothing":
			_show_result("You move on...")
	if GM.hp <= 0:
		await get_tree().create_timer(0.5).timeout
		GM.screen_change.emit("game_over", {"victory": false})

func _describe_reward(data: Dictionary) -> String:
	var parts: Array = []
	if data.has("heal"): parts.append("+%d HP" % data["heal"])
	if data.has("gold"): parts.append("+%dg" % data["gold"])
	if data.has("relic_discount"): parts.append("Next relic -%dg" % data["relic_discount"])
	return ", ".join(parts) if parts.size() > 0 else "Safe passage."

func _describe_penalty(data: Dictionary) -> String:
	var parts: Array = []
	if data.has("damage"): parts.append("-%d HP" % data["damage"])
	if data.has("gold") and data["gold"] < 0: parts.append("%dg" % data["gold"])
	return ", ".join(parts) if parts.size() > 0 else "Nothing happened."

func _show_result(text: String) -> void:
	for c in get_children(): c.queue_free()
	var bg = ColorRect.new(); bg.color = Color(0.06, 0.05, 0.09); bg.set_anchors_preset(PRESET_FULL_RECT); add_child(bg)
	var v = VBoxContainer.new(); v.set_anchors_preset(PRESET_CENTER); v.custom_minimum_size = Vector2(500, 200)
	v.position = Vector2(-250, -100); v.alignment = BoxContainer.ALIGNMENT_CENTER; v.add_theme_constant_override("separation", 15); add_child(v)
	_l(v, text, 20, Color(0.85, 0.8, 0.6))
	_l(v, "HP: %d/%d  |  Gold: %dg" % [GM.hp, GM.max_hp, GM.gold], 14, Color(0.6, 0.5, 0.5))
	var sp = Control.new(); sp.custom_minimum_size = Vector2(0, 10); v.add_child(sp)
	var bc = CenterContainer.new(); v.add_child(bc)
	var btn = Button.new(); btn.text = "  Continue  "; btn.custom_minimum_size = Vector2(200, 40)
	btn.add_theme_font_size_override("font_size", 16)
	btn.pressed.connect(func(): GM.screen_change.emit("map", {})); bc.add_child(btn)

func _l(p: Node, t: String, sz: int, c: Color) -> void:
	var l = Label.new(); l.text = t; l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", sz); l.add_theme_color_override("font_color", c); p.add_child(l)
