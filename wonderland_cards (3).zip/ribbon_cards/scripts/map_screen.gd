extends Control

const NODE_ICONS := {"combat": "⚔", "elite": "💀", "event": "❓", "rest": "🏕", "shop": "🛒", "treasure": "🎁", "boss": "👑"}
const NODE_COLORS := {"combat": Color(0.7, 0.3, 0.3), "elite": Color(0.8, 0.5, 0.2), "event": Color(0.4, 0.5, 0.8), "rest": Color(0.3, 0.7, 0.4), "shop": Color(0.8, 0.8, 0.3), "treasure": Color(0.6, 0.5, 0.8), "boss": Color(0.9, 0.2, 0.2)}

func _ready() -> void: _build_ui()

func _build_ui() -> void:
	for c in get_children(): c.queue_free()
	var bg = ColorRect.new(); bg.color = Color(0.06, 0.05, 0.08); bg.set_anchors_preset(PRESET_FULL_RECT); add_child(bg)
	# Top bar
	var top = HBoxContainer.new(); top.position = Vector2(15, 8); top.add_theme_constant_override("separation", 20); add_child(top)
	_info(top, GM.act_name(), 22, Color(0.8, 0.65, 0.7))
	_info(top, "HP: %d/%d" % [GM.hp, GM.max_hp], 16, Color(0.8, 0.3, 0.3))
	_info(top, "Gold: %d" % GM.gold, 16, Color(0.9, 0.8, 0.3))
	_info(top, "Deck: %d SB: %d" % [GM.deck.size(), GM.sideboard.size()], 14, Color(0.5, 0.6, 0.7))
	# Map area
	var scroll = ScrollContainer.new(); scroll.position = Vector2(15, 45); scroll.size = Vector2(1250, 620)
	scroll.custom_minimum_size = Vector2(1250, 620); add_child(scroll)
	var map_panel = Control.new(); map_panel.custom_minimum_size = Vector2(1220, 800); scroll.add_child(map_panel)
	# Determine rows
	var max_row = 0
	for node in GM.map_nodes: max_row = maxi(max_row, node["row"])
	var row_height = 90.0
	# Draw connections first
	for i in range(GM.map_nodes.size()):
		var node = GM.map_nodes[i]
		var from_pos = _node_pos(node, max_row, row_height) + Vector2(25, 25)
		for conn_idx in node["connections"]:
			if conn_idx < GM.map_nodes.size():
				var to_node = GM.map_nodes[conn_idx]
				var to_pos = _node_pos(to_node, max_row, row_height) + Vector2(25, 25)
				var line = _draw_line(from_pos, to_pos, Color(0.25, 0.22, 0.3))
				map_panel.add_child(line)
	# Draw nodes
	var available = GM.get_available_nodes()
	for i in range(GM.map_nodes.size()):
		var node = GM.map_nodes[i]
		var pos = _node_pos(node, max_row, row_height)
		var is_visited = i in GM.visited
		var is_current = i == GM.current_node_idx
		var is_available = i in available
		var ntype = node["type"]
		var color = NODE_COLORS.get(ntype, Color.GRAY)
		if is_visited: color = color.darkened(0.5)
		elif not is_available: color = color.darkened(0.3)
		# Node button/display
		var node_bg = ColorRect.new(); node_bg.color = color.darkened(0.4) if not is_current else color
		node_bg.position = pos; node_bg.custom_minimum_size = Vector2(50, 50); node_bg.size = Vector2(50, 50); map_panel.add_child(node_bg)
		var icon = Label.new(); icon.text = NODE_ICONS.get(ntype, "?"); icon.add_theme_font_size_override("font_size", 24)
		icon.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; icon.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		icon.custom_minimum_size = Vector2(50, 50); node_bg.add_child(icon)
		if is_current:
			var arrow = Label.new(); arrow.text = "▶"; arrow.position = pos + Vector2(-18, 12)
			arrow.add_theme_font_size_override("font_size", 18); arrow.add_theme_color_override("font_color", Color(1, 0.9, 0.3)); map_panel.add_child(arrow)
		# Label below
		var name_lbl = Label.new(); name_lbl.text = ntype.to_upper(); name_lbl.position = pos + Vector2(-5, 52)
		name_lbl.add_theme_font_size_override("font_size", 9); name_lbl.add_theme_color_override("font_color", color.lightened(0.2)); map_panel.add_child(name_lbl)
		# Clickable if available
		if is_available and not is_visited:
			var btn = Button.new(); btn.flat = true; btn.position = pos; btn.custom_minimum_size = Vector2(50, 50)
			btn.size = Vector2(50, 50); btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
			btn.pressed.connect(_on_node_clicked.bind(i))
			map_panel.add_child(btn)
	# Legend
	var legend = HBoxContainer.new(); legend.position = Vector2(15, 670); legend.add_theme_constant_override("separation", 12); add_child(legend)
	for nt in NODE_ICONS:
		var h = HBoxContainer.new(); h.add_theme_constant_override("separation", 3); legend.add_child(h)
		var il = Label.new(); il.text = NODE_ICONS[nt]; il.add_theme_font_size_override("font_size", 14); h.add_child(il)
		var nl = Label.new(); nl.text = nt.to_upper(); nl.add_theme_font_size_override("font_size", 10); nl.add_theme_color_override("font_color", NODE_COLORS.get(nt, Color.GRAY)); h.add_child(nl)
	# Deck button
	var dk_btn = Button.new(); dk_btn.text = "Deck"; dk_btn.position = Vector2(1180, 670); dk_btn.custom_minimum_size = Vector2(70, 30)
	dk_btn.pressed.connect(func(): GM.screen_change.emit("deck_manager", {"return_to": "map"})); add_child(dk_btn)

func _node_pos(node: Dictionary, _max_row: int, rh: float) -> Vector2:
	var cols_in_row := 0; var col_idx := 0
	for n in GM.map_nodes:
		if n["row"] == node["row"]: cols_in_row += 1
	for n in GM.map_nodes:
		if n == node: break
		if n["row"] == node["row"]: col_idx += 1
	var x_spacing = 1200.0 / float(maxi(cols_in_row, 1) + 1)
	return Vector2(x_spacing * (col_idx + 1) - 25, node["row"] * rh + 10)

func _draw_line(from: Vector2, to: Vector2, color: Color) -> Line2D:
	var line = Line2D.new(); line.add_point(from); line.add_point(to)
	line.width = 2.0; line.default_color = color; return line

func _on_node_clicked(idx: int) -> void:
	GM.visit_node(idx)
	var node = GM.map_nodes[idx]
	match node["type"]:
		"combat", "elite":
			GM.screen_change.emit("combat", {"encounter": node["data"], "is_elite": node["type"] == "elite"})
		"boss":
			GM.screen_change.emit("combat", {"encounter": node["data"], "is_boss": true})
		"event":
			var eidx = node["data"].get("event_idx", 0) % GM.EVENTS.size()
			GM.screen_change.emit("event", {"event": GM.EVENTS[eidx]})
		"rest":
			GM.screen_change.emit("rest", {})
		"shop":
			GM.screen_change.emit("shop", {})
		"treasure":
			GM.screen_change.emit("treasure", {})

func _info(p: Node, t: String, sz: int, c: Color) -> void:
	var l = Label.new(); l.text = t; l.add_theme_font_size_override("font_size", sz); l.add_theme_color_override("font_color", c); p.add_child(l)
