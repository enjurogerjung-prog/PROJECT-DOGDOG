extends Control

var return_to := "map"
var sel_source := ""  # "deck" or "sb"
var sel_idx := -1

func _ready() -> void:
	return_to = get_meta("return_to") if has_meta("return_to") else "map"
	_build()

func _build() -> void:
	for c in get_children(): c.queue_free()
	var bg = ColorRect.new(); bg.color = Color(0.06, 0.05, 0.08); bg.set_anchors_preset(PRESET_FULL_RECT); add_child(bg)
	# Top
	var top = HBoxContainer.new(); top.position = Vector2(12, 6); top.add_theme_constant_override("separation", 18); add_child(top)
	_l(top, "DECK MANAGER", 20, Color(0.8, 0.7, 0.6))
	_l(top, "Gold: %dg" % GM.gold, 16, Color(0.9, 0.8, 0.3))
	_l(top, "Deck: %d/%d (min %d)" % [GM.deck.size(), GM.max_deck, GM.min_deck], 13, Color(0.5, 0.6, 0.7))
	_l(top, "SB: %d/%d" % [GM.sideboard.size(), GM.max_sb], 13, Color(0.5, 0.5, 0.6))
	# Selection info
	var sel_info = Label.new(); sel_info.name = "SelInfo"; sel_info.position = Vector2(12, 32)
	sel_info.add_theme_font_size_override("font_size", 13)
	if sel_idx >= 0:
		var entry: Dictionary
		if sel_source == "deck" and sel_idx < GM.deck.size(): entry = GM.deck[sel_idx]
		elif sel_source == "sb" and sel_idx < GM.sideboard.size(): entry = GM.sideboard[sel_idx]
		if entry.size() > 0:
			var cd = GM.CARDS.get(entry["id"], {}); var sp = GM.sell_price(entry)
			sel_info.text = "Selected: %s%s (%s) — Sell: %dg" % [GM.TIER_PREFIX.get(entry["tier"], ""), cd.get("name", "?"), sel_source.to_upper(), sp]
			sel_info.add_theme_color_override("font_color", Color(0.9, 0.8, 0.5))
		else:
			sel_idx = -1; sel_source = ""
			sel_info.text = "Click a card to select it"; sel_info.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
	else:
		sel_info.text = "Click a card to select it"; sel_info.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
	add_child(sel_info)
	# DECK
	_l(self, "─── DECK (%d) ───" % GM.deck.size(), 13, Color(0.55, 0.5, 0.45), Vector2(12, 52))
	var dscroll = ScrollContainer.new(); dscroll.position = Vector2(12, 72); dscroll.size = Vector2(850, 230)
	dscroll.custom_minimum_size = Vector2(850, 230); add_child(dscroll)
	var dgrid = GridContainer.new(); dgrid.columns = 5; dgrid.add_theme_constant_override("h_separation", 5)
	dgrid.add_theme_constant_override("v_separation", 5); dscroll.add_child(dgrid)
	for i in range(GM.deck.size()):
		dgrid.add_child(_mk_card(GM.deck[i], i, "deck"))
	# SIDEBOARD
	_l(self, "─── SIDEBOARD (%d) ───" % GM.sideboard.size(), 13, Color(0.5, 0.45, 0.55), Vector2(12, 310))
	var sscroll = ScrollContainer.new(); sscroll.position = Vector2(12, 330); sscroll.size = Vector2(850, 120)
	sscroll.custom_minimum_size = Vector2(850, 120); add_child(sscroll)
	var sgrid = GridContainer.new(); sgrid.columns = 5; sgrid.add_theme_constant_override("h_separation", 5)
	sgrid.add_theme_constant_override("v_separation", 5); sscroll.add_child(sgrid)
	for i in range(GM.sideboard.size()):
		sgrid.add_child(_mk_card(GM.sideboard[i], i, "sb"))
	# ACTION PANEL
	var ap = ColorRect.new(); ap.color = Color(0.09, 0.08, 0.11); ap.position = Vector2(870, 52); ap.size = Vector2(395, 400)
	ap.custom_minimum_size = Vector2(395, 400); add_child(ap)
	var av = VBoxContainer.new(); av.position = Vector2(12, 8); av.custom_minimum_size = Vector2(370, 380)
	av.add_theme_constant_override("separation", 6); ap.add_child(av)
	_l(av, "─── Actions ───", 15, Color(0.6, 0.55, 0.5))
	# Action buttons - all check selection validity
	var msb = Button.new(); msb.text = "→ Move to Sideboard"; msb.custom_minimum_size = Vector2(280, 28)
	msb.add_theme_font_size_override("font_size", 12); msb.disabled = sel_source != "deck" or sel_idx < 0
	msb.pressed.connect(func():
		if sel_source == "deck" and sel_idx >= 0:
			if GM.move_to_sb(sel_idx): sel_idx = -1; sel_source = ""; _build()
	); av.add_child(msb)
	var mdk = Button.new(); mdk.text = "→ Move to Deck"; mdk.custom_minimum_size = Vector2(280, 28)
	mdk.add_theme_font_size_override("font_size", 12); mdk.disabled = sel_source != "sb" or sel_idx < 0
	mdk.pressed.connect(func():
		if sel_source == "sb" and sel_idx >= 0:
			if GM.move_to_deck(sel_idx): sel_idx = -1; sel_source = ""; _build()
	); av.add_child(mdk)
	var sell = Button.new(); sell.text = "💰 Sell Selected Card"; sell.custom_minimum_size = Vector2(280, 28)
	sell.add_theme_font_size_override("font_size", 12); sell.disabled = sel_idx < 0
	sell.pressed.connect(func():
		if sel_source == "deck" and sel_idx >= 0: GM.sell_from_deck(sel_idx)
		elif sel_source == "sb" and sel_idx >= 0: GM.sell_from_sb(sel_idx)
		sel_idx = -1; sel_source = ""; _build()
	); av.add_child(sell)
	# COMBINE
	var sp = Control.new(); sp.custom_minimum_size = Vector2(0, 10); av.add_child(sp)
	_l(av, "─── Combine (3 → upgrade) ───", 13, Color(0.55, 0.5, 0.45))
	var combinable = GM.get_combinable()
	if combinable.size() == 0:
		_l(av, "No cards can be combined yet.", 11, Color(0.4, 0.4, 0.4))
		_l(av, "Need 3 copies of same card + tier.", 10, Color(0.35, 0.35, 0.35))
	else:
		for combo in combinable:
			var cr = HBoxContainer.new(); cr.add_theme_constant_override("separation", 6); av.add_child(cr)
			var cd = GM.CARDS[combo["id"]]; var nt = GM.next_tier(combo["tier"])
			var info = Label.new()
			info.text = "%s%s (%dx) → %s%s" % [GM.TIER_PREFIX.get(combo["tier"], ""), cd["name"], combo["count"], GM.TIER_PREFIX.get(nt, ""), cd["name"]]
			info.add_theme_font_size_override("font_size", 11); info.add_theme_color_override("font_color", GM.TIER_COLORS.get(nt, Color.WHITE)); cr.add_child(info)
			var cbtn = Button.new(); cbtn.text = "Combine"; cbtn.custom_minimum_size = Vector2(70, 22); cbtn.add_theme_font_size_override("font_size", 10)
			var cid = combo["id"]; var ctier = combo["tier"]
			cbtn.pressed.connect(func(): GM.combine_cards(cid, ctier); sel_idx = -1; sel_source = ""; _build())
			cr.add_child(cbtn)
	# Back
	var back = Button.new(); back.text = "← Back"; back.position = Vector2(12, 670); back.custom_minimum_size = Vector2(90, 32)
	back.add_theme_font_size_override("font_size", 13)
	back.pressed.connect(func(): GM.screen_change.emit(return_to, {})); add_child(back)

func _mk_card(entry: Dictionary, idx: int, source: String) -> PanelContainer:
	var cd = GM.CARDS.get(entry["id"], {}); var ac = GM.get_arch_color(entry["id"])
	var tc = GM.TIER_COLORS.get(entry["tier"], Color.GRAY)
	var is_sel = (source == sel_source and idx == sel_idx)
	var p = PanelContainer.new(); p.custom_minimum_size = Vector2(160, 52)
	var pbg = ColorRect.new(); pbg.color = ac.lightened(0.15) if is_sel else ac.darkened(0.4)
	pbg.custom_minimum_size = Vector2(160, 52); p.add_child(pbg)
	if entry["tier"] != GM.TIER_BRONZE:
		var ts = ColorRect.new(); ts.color = tc; ts.custom_minimum_size = Vector2(160, 2); pbg.add_child(ts)
	var vb = VBoxContainer.new(); vb.position = Vector2(4, 2); p.add_child(vb)
	var nl = Label.new(); nl.text = "%s%s [%d]" % [GM.TIER_PREFIX.get(entry["tier"], ""), cd.get("name", "?"), cd.get("cost", 0)]
	nl.add_theme_font_size_override("font_size", 11)
	if entry["tier"] != GM.TIER_BRONZE: nl.add_theme_color_override("font_color", tc)
	vb.add_child(nl)
	# Show SCALED desc for tier
	var scaled = GM.card_at_tier(entry["id"], entry["tier"])
	var dl = Label.new(); dl.text = scaled["desc"]; dl.add_theme_font_size_override("font_size", 9)
	dl.add_theme_color_override("font_color", Color(0.7, 0.7, 0.68)); vb.add_child(dl)
	var il = Label.new(); il.text = "%s • Sell: %dg" % [GM.ARCH_NAMES.get(cd.get("arch", "neutral"), "?").substr(0, 6), GM.sell_price(entry)]
	il.add_theme_font_size_override("font_size", 8); il.add_theme_color_override("font_color", Color(0.45, 0.45, 0.42)); vb.add_child(il)
	# Click
	var btn = Button.new(); btn.flat = true; btn.set_anchors_preset(PRESET_FULL_RECT); btn.custom_minimum_size = Vector2(160, 52)
	btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	btn.pressed.connect(func():
		if sel_source == source and sel_idx == idx: sel_idx = -1; sel_source = ""
		else: sel_idx = idx; sel_source = source
		_build()
	)
	p.add_child(btn)
	return p

func _l(p: Node, t: String, sz: int, c: Color, pos: Vector2 = Vector2.ZERO) -> void:
	var l = Label.new(); l.text = t; l.add_theme_font_size_override("font_size", sz); l.add_theme_color_override("font_color", c)
	if pos != Vector2.ZERO: l.position = pos; add_child(l)
	else: p.add_child(l)
