extends Control
class_name MiniGame

signal game_finished(result: float)  # 0.0 = fail, 1.0 = perfect

static func create(parent: Node, game_type: String) -> MiniGame:
	var mg = MiniGame.new()
	mg.set_anchors_preset(Control.PRESET_FULL_RECT)
	parent.add_child(mg)
	mg._start_game(game_type)
	return mg

var _type: String = ""
var _active := true

func _start_game(game_type: String) -> void:
	_type = game_type
	# Overlay background
	var overlay = ColorRect.new()
	overlay.name = "Overlay"
	overlay.color = Color(0, 0, 0, 0.75)
	overlay.set_anchors_preset(PRESET_FULL_RECT)
	add_child(overlay)
	# Game window
	var window = ColorRect.new()
	window.name = "Window"
	window.color = Color(0.12, 0.1, 0.14)
	window.custom_minimum_size = Vector2(500, 350)
	window.size = Vector2(500, 350)
	window.position = Vector2(390, 185)
	add_child(window)
	# Border
	var border = ColorRect.new()
	border.color = Color(0.5, 0.35, 0.5)
	border.custom_minimum_size = Vector2(504, 354)
	border.position = Vector2(388, 183)
	border.z_index = -1
	add_child(border)

	match game_type:
		"roulette": _setup_roulette()
		"reflex": _setup_reflex()
		"watch": _setup_watch()
		"shuffle": _setup_shuffle()
		"mushroom": _setup_mushroom()
		"memory": _setup_memory()
		"riddle": _setup_riddle()
		_: _finish(0.5)

func _get_window() -> ColorRect:
	return get_node("Window") as ColorRect

# ============================================================
# ROULETTE — Spinning wheel
# ============================================================
var _roulette_speed: float = 600.0
var _roulette_angle: float = 0.0
var _roulette_spinning := false
var _roulette_segments := ["BIG DMG", "Heal 5", "Poison 4", "Small DMG", "Draw 3", "Oops!", "DMG+Block", "Energy"]

func _setup_roulette() -> void:
	var w = _get_window()
	var title = Label.new(); title.text = "☕ TEA PARTY ROULETTE ☕"; title.position = Vector2(100, 10)
	title.add_theme_font_size_override("font_size", 20); title.add_theme_color_override("font_color", Color(0.9, 0.7, 0.3)); w.add_child(title)
	var info = Label.new(); info.text = "Click SPIN, then click STOP!"; info.position = Vector2(150, 40)
	info.add_theme_font_size_override("font_size", 13); info.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6)); w.add_child(info)
	# Indicator
	var indicator = Label.new(); indicator.name = "Indicator"; indicator.text = "▶ " + _roulette_segments[0]
	indicator.position = Vector2(150, 160); indicator.add_theme_font_size_override("font_size", 28)
	indicator.add_theme_color_override("font_color", Color(1, 0.9, 0.3)); w.add_child(indicator)
	# Segment display
	var seg_label = Label.new(); seg_label.name = "SegList"; seg_label.position = Vector2(30, 70)
	seg_label.add_theme_font_size_override("font_size", 11); seg_label.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
	seg_label.text = " | ".join(_roulette_segments); w.add_child(seg_label)
	var btn = Button.new(); btn.name = "SpinBtn"; btn.text = "SPIN!"; btn.position = Vector2(180, 250)
	btn.custom_minimum_size = Vector2(140, 45); btn.add_theme_font_size_override("font_size", 18)
	btn.pressed.connect(_roulette_toggle); w.add_child(btn)

func _roulette_toggle() -> void:
	var btn = _get_window().get_node("SpinBtn") as Button
	if not _roulette_spinning:
		_roulette_spinning = true; _roulette_speed = randf_range(400, 700); btn.text = "STOP!"
	else:
		_roulette_spinning = false; btn.disabled = true
		var seg_idx = int(_roulette_angle / 45.0) % _roulette_segments.size()
		var result_map = {"BIG DMG": 1.0, "Heal 5": 0.8, "Poison 4": 0.7, "Draw 3": 0.8, "DMG+Block": 0.9, "Energy": 0.7, "Small DMG": 0.4, "Oops!": 0.0}
		var seg = _roulette_segments[seg_idx]
		var indicator = _get_window().get_node("Indicator") as Label
		indicator.text = "✦ " + seg + " ✦"
		await get_tree().create_timer(0.8).timeout
		_finish(result_map.get(seg, 0.5))

func _process(delta: float) -> void:
	if _roulette_spinning:
		_roulette_angle += _roulette_speed * delta
		_roulette_speed *= 0.998
		var seg_idx = int(_roulette_angle / 45.0) % _roulette_segments.size()
		var indicator = _get_window().get_node_or_null("Indicator")
		if indicator: indicator.text = "▶ " + _roulette_segments[seg_idx]

# ============================================================
# REFLEX — Click the Cheshire grin before it fades
# ============================================================
func _setup_reflex() -> void:
	var w = _get_window()
	var title = Label.new(); title.text = "😸 CHESHIRE REFLEX 😸"; title.position = Vector2(130, 10)
	title.add_theme_font_size_override("font_size", 20); title.add_theme_color_override("font_color", Color(0.7, 0.5, 0.9)); w.add_child(title)
	var info = Label.new(); info.text = "Click the grin before it vanishes!"; info.position = Vector2(130, 40)
	info.add_theme_font_size_override("font_size", 13); info.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6)); w.add_child(info)
	# Delay, then show target
	await get_tree().create_timer(0.8).timeout
	if not _active: return
	var target = Button.new(); target.name = "GrinBtn"; target.text = "😸"
	target.position = Vector2(randf_range(40, 380), randf_range(80, 250))
	target.custom_minimum_size = Vector2(70, 70); target.add_theme_font_size_override("font_size", 40)
	target.pressed.connect(func(): _finish(1.0))
	w.add_child(target)
	# Fade timer
	await get_tree().create_timer(1.8).timeout
	if not _active: return
	if is_instance_valid(target) and not target.disabled:
		_finish(0.0)

# ============================================================
# WATCH QTE — Stop the hand in the gold zone
# ============================================================
func _setup_watch() -> void:
	var w = _get_window()
	var title = Label.new(); title.text = "⏱ POCKET WATCH ⏱"; title.position = Vector2(150, 10)
	title.add_theme_font_size_override("font_size", 20); title.add_theme_color_override("font_color", Color(0.9, 0.8, 0.3)); w.add_child(title)
	var info = Label.new(); info.text = "Hit STOP when the bar is in the gold zone!"; info.position = Vector2(100, 40)
	info.add_theme_font_size_override("font_size", 13); info.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6)); w.add_child(info)
	# Progress bar background
	var bar_bg = ColorRect.new(); bar_bg.name = "BarBG"; bar_bg.color = Color(0.2, 0.2, 0.25)
	bar_bg.position = Vector2(30, 130); bar_bg.custom_minimum_size = Vector2(440, 40); bar_bg.size = Vector2(440, 40); w.add_child(bar_bg)
	# Gold zone (target area)
	var zone_start = randf_range(0.3, 0.6)
	var zone_width = 0.15  # 15% of bar
	var zone = ColorRect.new(); zone.name = "Zone"; zone.color = Color(1, 0.85, 0.2, 0.4)
	zone.position = Vector2(zone_start * 440, 0); zone.custom_minimum_size = Vector2(zone_width * 440, 40)
	zone.size = Vector2(zone_width * 440, 40); bar_bg.add_child(zone)
	zone.set_meta("start", zone_start); zone.set_meta("end", zone_start + zone_width)
	# Cursor
	var cursor = ColorRect.new(); cursor.name = "Cursor"; cursor.color = Color(1, 1, 1)
	cursor.position = Vector2(0, 0); cursor.custom_minimum_size = Vector2(4, 40); cursor.size = Vector2(4, 40)
	bar_bg.add_child(cursor)
	# Animate cursor
	var tween = create_tween().set_loops()
	tween.tween_property(cursor, "position:x", 436.0, 0.8)
	tween.tween_property(cursor, "position:x", 0.0, 0.8)
	cursor.set_meta("tween", tween)
	# Stop button
	var btn = Button.new(); btn.text = "STOP!"; btn.position = Vector2(180, 220)
	btn.custom_minimum_size = Vector2(140, 45); btn.add_theme_font_size_override("font_size", 18)
	btn.pressed.connect(func():
		btn.disabled = true
		var tw = cursor.get_meta("tween") as Tween
		if tw: tw.kill()
		var pos_ratio = cursor.position.x / 440.0
		var zs = zone.get_meta("start") as float
		var ze = zone.get_meta("end") as float
		if pos_ratio >= zs and pos_ratio <= ze:
			# Perfect zone
			var center = (zs + ze) / 2.0
			var dist = absf(pos_ratio - center) / (ze - zs)
			_finish(lerpf(1.0, 0.7, dist))
		else:
			_finish(0.2)
	)
	w.add_child(btn)

# ============================================================
# SHUFFLE — Track the right card
# ============================================================
func _setup_shuffle() -> void:
	var w = _get_window()
	var title = Label.new(); title.text = "🃏 CARD SHUFFLE 🃏"; title.position = Vector2(150, 10)
	title.add_theme_font_size_override("font_size", 20); title.add_theme_color_override("font_color", Color(0.3, 0.7, 0.9)); w.add_child(title)
	var info = Label.new(); info.text = "Watch the golden card, then find it!"; info.position = Vector2(120, 40)
	info.add_theme_font_size_override("font_size", 13); info.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6)); w.add_child(info)
	# 3 card positions
	var positions = [Vector2(80, 120), Vector2(210, 120), Vector2(340, 120)]
	var correct_idx = randi() % 3
	var cards: Array = []
	for i in range(3):
		var card = ColorRect.new()
		card.custom_minimum_size = Vector2(100, 140); card.size = Vector2(100, 140)
		card.position = positions[i]
		card.color = Color(1, 0.85, 0.3) if i == correct_idx else Color(0.3, 0.25, 0.35)
		card.name = "Card%d" % i
		w.add_child(card)
		cards.append(card)
	# Show for 1.5 seconds, then hide colors and shuffle
	await get_tree().create_timer(1.5).timeout
	if not _active: return
	for card in cards: card.color = Color(0.25, 0.2, 0.3)
	# Do 5 swaps with tweens
	for _swap in range(5):
		var a = randi() % 3; var b = randi() % 3
		while b == a: b = randi() % 3
		var pos_a = cards[a].position; var pos_b = cards[b].position
		var tw = create_tween(); tw.set_parallel(true)
		tw.tween_property(cards[a], "position", pos_b, 0.3)
		tw.tween_property(cards[b], "position", pos_a, 0.3)
		await tw.finished
		# Swap in array to track correct
		var temp = cards[a]; cards[a] = cards[b]; cards[b] = temp
	if not _active: return
	# Let player pick
	for i in range(3):
		var btn = Button.new(); btn.text = "Pick"; btn.position = cards[i].position + Vector2(15, 145)
		btn.custom_minimum_size = Vector2(70, 30); btn.add_theme_font_size_override("font_size", 12)
		var card_ref = cards[i]
		btn.pressed.connect(func():
			if card_ref.name == "Card%d" % correct_idx: _finish(1.0)
			else: _finish(0.0)
		)
		w.add_child(btn)

# ============================================================
# MUSHROOM — Click at peak growth
# ============================================================
func _setup_mushroom() -> void:
	var w = _get_window()
	var title = Label.new(); title.text = "🍄 MUSHROOM GROWTH 🍄"; title.position = Vector2(130, 10)
	title.add_theme_font_size_override("font_size", 20); title.add_theme_color_override("font_color", Color(0.4, 0.8, 0.4)); w.add_child(title)
	var info = Label.new(); info.text = "Click PICK at the peak of growth!"; info.position = Vector2(130, 40)
	info.add_theme_font_size_override("font_size", 13); info.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6)); w.add_child(info)
	# Growth bar
	var bar_bg = ColorRect.new(); bar_bg.position = Vector2(200, 80); bar_bg.custom_minimum_size = Vector2(100, 200)
	bar_bg.size = Vector2(100, 200); bar_bg.color = Color(0.15, 0.15, 0.2); w.add_child(bar_bg)
	var bar = ColorRect.new(); bar.name = "GrowthBar"; bar.color = Color(0.3, 0.7, 0.3)
	bar.position = Vector2(0, 200); bar.custom_minimum_size = Vector2(100, 0); bar.size = Vector2(100, 0)
	bar_bg.add_child(bar)
	# Animate growth (sine wave)
	var timer := 0.0; var speed := randf_range(2.5, 3.5)
	var tween = create_tween().set_loops()
	tween.tween_method(func(t: float):
		var val = (sin(t * speed) + 1.0) / 2.0  # 0 to 1
		bar.size.y = val * 200
		bar.position.y = 200 - val * 200
		bar.set_meta("value", val)
	, 0.0, TAU, 1.5)
	bar.set_meta("tween", tween)
	# Pick button
	var btn = Button.new(); btn.text = "PICK!"; btn.position = Vector2(180, 300)
	btn.custom_minimum_size = Vector2(140, 40); btn.add_theme_font_size_override("font_size", 18)
	btn.pressed.connect(func():
		btn.disabled = true
		var tw = bar.get_meta("tween") as Tween
		if tw: tw.kill()
		var val = bar.get_meta("value") as float
		_finish(val)
	)
	w.add_child(btn)

# ============================================================
# MEMORY — Remember which card was special
# ============================================================
func _setup_memory() -> void:
	var w = _get_window()
	var title = Label.new(); title.text = "🧠 REMEMBER ME 🧠"; title.position = Vector2(150, 10)
	title.add_theme_font_size_override("font_size", 20); title.add_theme_color_override("font_color", Color(0.9, 0.6, 0.3)); w.add_child(title)
	var info = Label.new(); info.text = "One card is golden. Remember which one!"; info.position = Vector2(100, 40)
	info.add_theme_font_size_override("font_size", 13); info.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6)); w.add_child(info)
	var positions = [Vector2(60, 110), Vector2(200, 110), Vector2(340, 110)]
	var correct = randi() % 3
	var cards: Array = []
	for i in range(3):
		var card = ColorRect.new(); card.custom_minimum_size = Vector2(100, 140); card.size = Vector2(100, 140)
		card.position = positions[i]; card.name = "MCard%d" % i
		card.color = Color(1, 0.85, 0.3) if i == correct else Color(0.4, 0.3, 0.5)
		w.add_child(card); cards.append(card)
	# Show for 2 seconds then hide
	await get_tree().create_timer(2.0).timeout
	if not _active: return
	for card in cards: card.color = Color(0.25, 0.2, 0.3)
	# Pick buttons
	for i in range(3):
		var btn = Button.new(); btn.text = "This one"; btn.position = positions[i] + Vector2(5, 145)
		btn.custom_minimum_size = Vector2(90, 30); btn.add_theme_font_size_override("font_size", 12)
		var idx = i
		btn.pressed.connect(func():
			if idx == correct: _finish(1.0)
			else: _finish(0.0)
		)
		w.add_child(btn)

# ============================================================
# RIDDLE — Answer a Wonderland riddle
# ============================================================
var _riddles := [
	{"q": "Why is a raven like a writing desk?", "answers": ["Because Poe wrote on both", "They both have inky quills", "Neither is ever turned upside down"], "correct": 0},
	{"q": "What's the best way to talk to the Red Queen?", "answers": ["Very carefully", "With a curtsy", "Don't — just run!"], "correct": 2},
	{"q": "How many cups at the Mad Tea Party?", "answers": ["Never enough", "Always too many", "Time stopped counting"], "correct": 0},
	{"q": "What did the Dormouse say?", "answers": ["Twinkle twinkle", "Feed your head", "Curiouser and curiouser"], "correct": 0},
]

func _setup_riddle() -> void:
	var w = _get_window()
	var riddle = _riddles[randi() % _riddles.size()]
	var title = Label.new(); title.text = "🐛 CATERPILLAR'S RIDDLE 🐛"; title.position = Vector2(110, 10)
	title.add_theme_font_size_override("font_size", 20); title.add_theme_color_override("font_color", Color(0.3, 0.6, 0.9)); w.add_child(title)
	var ql = Label.new(); ql.text = "\"" + riddle["q"] + "\""; ql.position = Vector2(30, 60)
	ql.add_theme_font_size_override("font_size", 16); ql.add_theme_color_override("font_color", Color(0.8, 0.8, 0.7))
	ql.custom_minimum_size = Vector2(440, 40); ql.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; w.add_child(ql)
	for i in range(riddle["answers"].size()):
		var btn = Button.new(); btn.text = riddle["answers"][i]; btn.position = Vector2(50, 130 + i * 55)
		btn.custom_minimum_size = Vector2(400, 45); btn.add_theme_font_size_override("font_size", 14)
		var is_correct = (i == riddle["correct"])
		btn.pressed.connect(func(): _finish(1.0 if is_correct else 0.0))
		w.add_child(btn)

# ============================================================
# FINISH
# ============================================================
func _finish(result: float) -> void:
	if not _active: return
	_active = false
	_roulette_spinning = false
	game_finished.emit(result)
	await get_tree().create_timer(0.3).timeout
	queue_free()
