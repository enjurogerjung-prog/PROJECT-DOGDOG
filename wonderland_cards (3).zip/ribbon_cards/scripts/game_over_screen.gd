extends Control

func _ready() -> void:
	var victory = get_meta("victory") if has_meta("victory") else false
	var bg = ColorRect.new(); bg.set_anchors_preset(PRESET_FULL_RECT); add_child(bg)
	var v = VBoxContainer.new(); v.set_anchors_preset(PRESET_CENTER); v.custom_minimum_size = Vector2(600, 400)
	v.position = Vector2(-300, -200); v.alignment = BoxContainer.ALIGNMENT_CENTER; add_child(v)
	if victory:
		bg.color = Color(0.05, 0.07, 0.05)
		_l(v, "♠ ♥ ♦ ♣", 28, Color(0.7, 0.6, 0.3)); _s(v, 12)
		if GM.infinite_cycle == 0:
			_l(v, "WONDERLAND CONQUERED", 36, Color(0.9, 0.8, 0.4))
			_l(v, "The Queen is defeated. But Wonderland never truly ends...", 15, Color(0.6, 0.7, 0.5))
		else:
			_l(v, "CYCLE %d COMPLETE" % GM.infinite_cycle, 36, Color(0.9, 0.8, 0.4))
			_l(v, "Curiouser and curiouser. The madness deepens.", 15, Color(0.6, 0.7, 0.5))
		_s(v, 8)
		_l(v, "HP: %d/%d  |  Gold: %dg  |  Deck: %d" % [GM.hp, GM.max_hp, GM.gold, GM.deck.size()], 13, Color(0.5, 0.5, 0.4))
		if GM.relics.size() > 0:
			var rn: Array = []; for rid in GM.relics: rn.append(GM.RELICS[rid]["name"])
			_l(v, "Relics: " + ", ".join(rn), 11, Color(0.5, 0.45, 0.3))
		_s(v, 10); _l(v, "♠ ♥ ♦ ♣", 28, Color(0.7, 0.6, 0.3)); _s(v, 20)
		var cc = CenterContainer.new(); v.add_child(cc)
		var cb = Button.new(); cb.text = "  Continue (Infinite Scaling)  "; cb.custom_minimum_size = Vector2(280, 45)
		cb.add_theme_font_size_override("font_size", 17); cb.pressed.connect(func(): GM.screen_change.emit("map", {})); cc.add_child(cb)
		_s(v, 8)
	else:
		bg.color = Color(0.08, 0.04, 0.04)
		_l(v, "LOST IN WONDERLAND", 42, Color(0.7, 0.2, 0.2)); _s(v, 12)
		_l(v, "\"We're all mad here...\"\nBut some are madder than others.", 15, Color(0.5, 0.3, 0.3))
		_s(v, 8)
		_l(v, "%s" % GM.act_name(), 13, Color(0.4, 0.3, 0.3))
		_s(v, 25)
	var rc = CenterContainer.new(); v.add_child(rc)
	var rb = Button.new(); rb.text = "  New Run  "; rb.custom_minimum_size = Vector2(180, 40)
	rb.add_theme_font_size_override("font_size", 16); rb.pressed.connect(func(): GM.start_new_run()); rc.add_child(rb)
	_s(v, 6)
	var mc = CenterContainer.new(); v.add_child(mc)
	var mb = Button.new(); mb.text = "  Main Menu  "; mb.custom_minimum_size = Vector2(140, 32)
	mb.add_theme_font_size_override("font_size", 13); mb.pressed.connect(func(): GM.screen_change.emit("menu", {})); mc.add_child(mb)

func _l(p: Node, t: String, sz: int, c: Color) -> void:
	var l = Label.new(); l.text = t; l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", sz); l.add_theme_color_override("font_color", c); p.add_child(l)
func _s(p: Node, h: float) -> void:
	var s = Control.new(); s.custom_minimum_size = Vector2(0, h); p.add_child(s)
