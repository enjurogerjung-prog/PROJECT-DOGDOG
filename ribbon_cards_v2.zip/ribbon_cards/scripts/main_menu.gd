extends Control

func _ready() -> void:
	var bg = ColorRect.new()
	bg.color = Color(0.06, 0.05, 0.08)
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	
	var vbox = VBoxContainer.new()
	vbox.set_anchors_preset(PRESET_CENTER)
	vbox.custom_minimum_size = Vector2(600, 420)
	vbox.position = Vector2(-300, -210)
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	add_child(vbox)
	
	_label(vbox, "─── ✦ ───", 24, Color(0.5, 0.3, 0.4))
	_spacer(vbox, 15)
	_label(vbox, "RIBBON CARDS", 56, Color(0.85, 0.7, 0.75))
	_label(vbox, "A Tale from The Ribbons", 18, Color(0.5, 0.4, 0.45))
	_spacer(vbox, 12)
	_label(vbox, "The Council suppressed the old magic.\nBut the threads remember.", 14, Color(0.4, 0.35, 0.4))
	_spacer(vbox, 30)
	
	# Color archetype legend
	var legend = HBoxContainer.new()
	legend.alignment = BoxContainer.ALIGNMENT_CENTER
	legend.add_theme_constant_override("separation", 20)
	vbox.add_child(legend)
	for arch in ["rock", "scissors", "paper"]:
		var h = HBoxContainer.new()
		h.add_theme_constant_override("separation", 5)
		legend.add_child(h)
		var dot = ColorRect.new()
		dot.color = GameManager.ARCHETYPE_COLORS[arch]
		dot.custom_minimum_size = Vector2(12, 12)
		h.add_child(dot)
		var l = Label.new()
		l.text = GameManager.ARCHETYPE_NAMES[arch]
		l.add_theme_font_size_override("font_size", 13)
		l.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
		h.add_child(l)
	
	_spacer(vbox, 25)
	
	var btn_c = CenterContainer.new()
	vbox.add_child(btn_c)
	var btn = Button.new()
	btn.text = "  UNRAVEL THE THREADS  "
	btn.custom_minimum_size = Vector2(280, 50)
	btn.add_theme_font_size_override("font_size", 20)
	btn.pressed.connect(func(): GameManager.start_new_run())
	btn_c.add_child(btn)
	
	_spacer(vbox, 20)
	_label(vbox, "─── ✦ ───", 24, Color(0.5, 0.3, 0.4))
	_spacer(vbox, 15)
	_label(vbox, "Rock · Paper · Scissors  •  Build · Combine · Survive", 12, Color(0.35, 0.3, 0.35))

func _label(parent: Node, text: String, size: int, color: Color) -> void:
	var l = Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	parent.add_child(l)

func _spacer(parent: Node, h: float) -> void:
	var s = Control.new()
	s.custom_minimum_size = Vector2(0, h)
	parent.add_child(s)
