extends Control

# ============================================================
# Game Over Screen — Victory or Defeat
# ============================================================

func _ready() -> void:
	var victory = get_meta("victory") if has_meta("victory") else false
	_build_ui(victory)

func _build_ui(victory: bool) -> void:
	# Background
	var bg = ColorRect.new()
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	
	var vbox = VBoxContainer.new()
	vbox.set_anchors_preset(PRESET_CENTER)
	vbox.custom_minimum_size = Vector2(600, 400)
	vbox.position = Vector2(-300, -200)
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	add_child(vbox)
	
	if victory:
		bg.color = Color(0.05, 0.07, 0.05)
		
		var line = Label.new()
		line.text = "═══ ✦ ═══"
		line.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		line.add_theme_font_size_override("font_size", 28)
		line.add_theme_color_override("font_color", Color(0.7, 0.6, 0.3))
		vbox.add_child(line)
		
		vbox.add_child(_spacer(20))
		
		var title = Label.new()
		title.text = "THE GRAND WEAVER FALLS"
		title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		title.add_theme_font_size_override("font_size", 42)
		title.add_theme_color_override("font_color", Color(0.9, 0.8, 0.4))
		vbox.add_child(title)
		
		vbox.add_child(_spacer(15))
		
		var subtitle = Label.new()
		subtitle.text = "The threads unravel. The Council's binding is broken.\nThe old magic remembers."
		subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		subtitle.add_theme_font_size_override("font_size", 16)
		subtitle.add_theme_color_override("font_color", Color(0.6, 0.7, 0.5))
		vbox.add_child(subtitle)
		
		vbox.add_child(_spacer(10))
		
		var stats = Label.new()
		stats.text = "Final HP: %d / %d  |  Deck: %d cards" % [GameManager.player_hp, GameManager.player_max_hp, GameManager.deck.size()]
		stats.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		stats.add_theme_font_size_override("font_size", 14)
		stats.add_theme_color_override("font_color", Color(0.5, 0.5, 0.4))
		vbox.add_child(stats)
		
		vbox.add_child(_spacer(10))
		
		var line2 = Label.new()
		line2.text = "═══ ✦ ═══"
		line2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		line2.add_theme_font_size_override("font_size", 28)
		line2.add_theme_color_override("font_color", Color(0.7, 0.6, 0.3))
		vbox.add_child(line2)
	else:
		bg.color = Color(0.08, 0.04, 0.04)
		
		var title = Label.new()
		title.text = "UNRAVELED"
		title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		title.add_theme_font_size_override("font_size", 48)
		title.add_theme_color_override("font_color", Color(0.7, 0.2, 0.2))
		vbox.add_child(title)
		
		vbox.add_child(_spacer(15))
		
		var subtitle = Label.new()
		subtitle.text = "The Council's threads claimed another.\nYour essence returns to the loom."
		subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		subtitle.add_theme_font_size_override("font_size", 16)
		subtitle.add_theme_color_override("font_color", Color(0.5, 0.3, 0.3))
		vbox.add_child(subtitle)
		
		vbox.add_child(_spacer(10))
		
		var act_name = "Unknown"
		if GameManager.current_act < GameManager.ACTS.size():
			act_name = GameManager.ACTS[GameManager.current_act]["name"]
		
		var stats = Label.new()
		stats.text = "Fell during: %s  |  Fight %d" % [act_name, GameManager.current_fight + 1]
		stats.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		stats.add_theme_font_size_override("font_size", 14)
		stats.add_theme_color_override("font_color", Color(0.4, 0.3, 0.3))
		vbox.add_child(stats)
	
	vbox.add_child(_spacer(40))
	
	# Restart button
	var btn_container = CenterContainer.new()
	vbox.add_child(btn_container)
	
	var restart_btn = Button.new()
	restart_btn.text = "  Weave Again  "
	restart_btn.custom_minimum_size = Vector2(220, 50)
	restart_btn.add_theme_font_size_override("font_size", 20)
	restart_btn.pressed.connect(_on_restart)
	btn_container.add_child(restart_btn)
	
	vbox.add_child(_spacer(15))
	
	# Main menu button
	var menu_container = CenterContainer.new()
	vbox.add_child(menu_container)
	
	var menu_btn = Button.new()
	menu_btn.text = "  Main Menu  "
	menu_btn.custom_minimum_size = Vector2(180, 40)
	menu_btn.add_theme_font_size_override("font_size", 16)
	menu_btn.pressed.connect(_on_menu)
	menu_container.add_child(menu_btn)

func _spacer(height: float) -> Control:
	var s = Control.new()
	s.custom_minimum_size = Vector2(0, height)
	return s

func _on_restart() -> void:
	GameManager.start_new_run()

func _on_menu() -> void:
	GameManager.screen_change_requested.emit("menu", {})
