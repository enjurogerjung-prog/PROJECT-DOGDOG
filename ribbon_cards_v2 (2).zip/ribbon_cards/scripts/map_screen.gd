extends Control

func _ready() -> void:
	_build_ui()

func _build_ui() -> void:
	var bg = ColorRect.new()
	bg.color = Color(0.07, 0.06, 0.09)
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	
	# Top bar
	var top = HBoxContainer.new()
	top.position = Vector2(20, 10)
	top.custom_minimum_size = Vector2(1240, 35)
	top.add_theme_constant_override("separation", 20)
	add_child(top)
	
	var act_lbl = Label.new()
	act_lbl.text = GameManager.get_act_name()
	act_lbl.add_theme_font_size_override("font_size", 24)
	act_lbl.add_theme_color_override("font_color", Color(0.8, 0.65, 0.7))
	act_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(act_lbl)
	
	_info_label(top, "HP: %d/%d" % [GameManager.player_hp, GameManager.player_max_hp], Color(0.8, 0.3, 0.3))
	_info_label(top, "Gold: %d" % GameManager.gold, Color(0.9, 0.8, 0.3))
	_info_label(top, "Deck: %d  SB: %d" % [GameManager.deck.size(), GameManager.sideboard.size()], Color(0.5, 0.6, 0.7))
	
	# Level display
	var scroll = ScrollContainer.new()
	scroll.position = Vector2(20, 55)
	scroll.size = Vector2(1240, 600)
	scroll.custom_minimum_size = Vector2(1240, 600)
	add_child(scroll)
	
	var vbox = VBoxContainer.new()
	vbox.custom_minimum_size = Vector2(1200, 0)
	vbox.add_theme_constant_override("separation", 8)
	scroll.add_child(vbox)
	
	for lvl_idx in range(GameManager.act_levels.size()):
		var level = GameManager.act_levels[lvl_idx]
		var is_current_level = (lvl_idx == GameManager.current_level)
		var is_past = (lvl_idx < GameManager.current_level)
		var arch_color = GameManager.ARCHETYPE_COLORS.get(level["archetype"], Color.GRAY)
		
		# Level header
		var level_row = HBoxContainer.new()
		level_row.add_theme_constant_override("separation", 10)
		vbox.add_child(level_row)
		
		# Archetype color indicator
		var arch_dot = ColorRect.new()
		arch_dot.color = arch_color if not is_past else arch_color.darkened(0.5)
		arch_dot.custom_minimum_size = Vector2(8, 50)
		level_row.add_child(arch_dot)
		
		# Level info
		var lvl_vbox = VBoxContainer.new()
		lvl_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		level_row.add_child(lvl_vbox)
		
		var lvl_title = Label.new()
		var boss_data = GameManager.ENEMIES.get(level["boss_id"], {})
		var boss_name = boss_data.get("name", "???")
		var arch_name = GameManager.ARCHETYPE_NAMES.get(level["archetype"], "?")
		var dual = ""
		if boss_data.has("archetype2"):
			dual = "/" + GameManager.ARCHETYPE_NAMES.get(boss_data["archetype2"], "")
		lvl_title.text = "Level %d — %s%s — Boss: %s" % [lvl_idx + 1, arch_name, dual, boss_name]
		lvl_title.add_theme_font_size_override("font_size", 16)
		if is_past:
			lvl_title.add_theme_color_override("font_color", Color(0.35, 0.35, 0.35))
		elif is_current_level:
			lvl_title.add_theme_color_override("font_color", Color(0.9, 0.85, 0.7))
		else:
			lvl_title.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
		lvl_vbox.add_child(lvl_title)
		
		# Phase buttons (only for current level)
		if is_current_level:
			var phase_row = HBoxContainer.new()
			phase_row.add_theme_constant_override("separation", 15)
			lvl_vbox.add_child(phase_row)
			
			for p_idx in range(3):
				var phase = level["phases"][p_idx]
				var is_current_phase = (p_idx == GameManager.current_phase)
				var is_past_phase = (p_idx < GameManager.current_phase)
				
				var p_vbox = VBoxContainer.new()
				p_vbox.custom_minimum_size = Vector2(350, 0)
				phase_row.add_child(p_vbox)
				
				var phase_label = Label.new()
				if phase["is_boss"]:
					phase_label.text = "Phase 3: BOSS"
				else:
					phase_label.text = "Phase %d" % (p_idx + 1)
					if phase["skippable"]:
						phase_label.text += " (skippable)"
				phase_label.add_theme_font_size_override("font_size", 13)
				if is_past_phase:
					phase_label.add_theme_color_override("font_color", Color(0.3, 0.4, 0.3))
				elif is_current_phase:
					phase_label.add_theme_color_override("font_color", Color(0.9, 0.8, 0.5))
				else:
					phase_label.add_theme_color_override("font_color", Color(0.45, 0.45, 0.45))
				p_vbox.add_child(phase_label)
				
				# Enemy list
				var enemy_text = ""
				for eid in phase["enemies"]:
					var ed = GameManager.ENEMIES.get(eid, {})
					if enemy_text != "":
						enemy_text += ", "
					enemy_text += ed.get("name", eid)
				var enemy_lbl = Label.new()
				enemy_lbl.text = enemy_text
				enemy_lbl.add_theme_font_size_override("font_size", 11)
				enemy_lbl.add_theme_color_override("font_color", arch_color.lightened(0.2) if is_current_phase else Color(0.4, 0.4, 0.4))
				p_vbox.add_child(enemy_lbl)
				
				if is_current_phase and not is_past_phase:
					var btn_row = HBoxContainer.new()
					btn_row.add_theme_constant_override("separation", 8)
					p_vbox.add_child(btn_row)
					
					var fight_btn = Button.new()
					fight_btn.text = "FIGHT"
					fight_btn.custom_minimum_size = Vector2(100, 35)
					fight_btn.add_theme_font_size_override("font_size", 14)
					fight_btn.pressed.connect(_on_fight.bind(phase))
					btn_row.add_child(fight_btn)
					
					if phase["skippable"]:
						var skip_btn = Button.new()
						skip_btn.text = "SKIP"
						skip_btn.custom_minimum_size = Vector2(100, 35)
						skip_btn.add_theme_font_size_override("font_size", 14)
						skip_btn.pressed.connect(_on_skip)
						btn_row.add_child(skip_btn)
				elif is_past_phase:
					var done = Label.new()
					done.text = "✓ Done"
					done.add_theme_font_size_override("font_size", 12)
					done.add_theme_color_override("font_color", Color(0.3, 0.5, 0.3))
					p_vbox.add_child(done)
		elif is_past:
			var done = Label.new()
			done.text = "    ✓ Cleared"
			done.add_theme_font_size_override("font_size", 13)
			done.add_theme_color_override("font_color", Color(0.3, 0.4, 0.3))
			lvl_vbox.add_child(done)
		
		# Separator
		var sep = HSeparator.new()
		sep.custom_minimum_size = Vector2(1200, 2)
		vbox.add_child(sep)
	
	# Bottom buttons
	var bot_row = HBoxContainer.new()
	bot_row.position = Vector2(900, 670)
	bot_row.add_theme_constant_override("separation", 10)
	add_child(bot_row)
	
	var deck_btn = Button.new()
	deck_btn.text = "Manage Deck"
	deck_btn.custom_minimum_size = Vector2(130, 32)
	deck_btn.pressed.connect(func(): GameManager.screen_change_requested.emit("deck_manager", {"return_to": "map"}))
	bot_row.add_child(deck_btn)
	
	# Relics display
	if GameManager.owned_relics.size() > 0:
		var relic_lbl = Label.new()
		relic_lbl.position = Vector2(20, 670)
		var relic_names: Array = []
		for rid in GameManager.owned_relics:
			relic_names.append(GameManager.RELICS[rid]["name"])
		relic_lbl.text = "Relics: " + ", ".join(relic_names)
		relic_lbl.add_theme_font_size_override("font_size", 12)
		relic_lbl.add_theme_color_override("font_color", Color(0.6, 0.5, 0.3))
		add_child(relic_lbl)

func _info_label(parent: Node, text: String, color: Color) -> void:
	var l = Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 18)
	l.add_theme_color_override("font_color", color)
	parent.add_child(l)

func _on_fight(phase_data: Dictionary) -> void:
	GameManager.screen_change_requested.emit("combat", {"encounter": phase_data})

func _on_skip() -> void:
	# Give skip reward
	var rewards = GameManager.SKIP_REWARDS.duplicate()
	rewards.shuffle()
	var reward = rewards[0]
	
	match reward["type"]:
		"gold":
			GameManager.gold += reward["value"]
		"heal":
			GameManager.heal_player(reward["value"])
		"random_card":
			var cards = GameManager.get_random_shop_cards(1)
			if cards.size() > 0:
				GameManager.add_card_to_deck(cards[0])
		"random_relic_discount":
			GameManager.relic_discount += reward["value"]
	
	GameManager.advance_phase()
	GameManager.screen_change_requested.emit("shop", {"skip_reward": reward["label"]})
