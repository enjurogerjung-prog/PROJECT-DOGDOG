extends Control

func _ready() -> void:
	var victory = get_meta("victory") if has_meta("victory") else false
	_build_ui(victory)

func _build_ui(victory: bool) -> void:
	var bg = ColorRect.new()
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	
	var vbox = VBoxContainer.new()
	vbox.set_anchors_preset(PRESET_CENTER)
	vbox.custom_minimum_size = Vector2(600, 420)
	vbox.position = Vector2(-300, -210)
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	add_child(vbox)
	
	if victory:
		bg.color = Color(0.05, 0.07, 0.05)
		_lbl(vbox, "═══ ✦ ═══", 28, Color(0.7, 0.6, 0.3))
		_spacer(vbox, 15)
		
		if GameManager.infinite_cycle == 0:
			_lbl(vbox, "THE GRAND WEAVER FALLS", 38, Color(0.9, 0.8, 0.4))
			_lbl(vbox, "The threads unravel. The Council's binding is broken.", 16, Color(0.6, 0.7, 0.5))
		else:
			_lbl(vbox, "CYCLE %d COMPLETE" % GameManager.infinite_cycle, 38, Color(0.9, 0.8, 0.4))
			_lbl(vbox, "The threads grow stronger. But so do you.", 16, Color(0.6, 0.7, 0.5))
		
		_spacer(vbox, 10)
		_lbl(vbox, "HP: %d/%d  |  Gold: %dg  |  Deck: %d cards" % [GameManager.player_hp, GameManager.player_max_hp, GameManager.gold, GameManager.deck.size()], 14, Color(0.5, 0.5, 0.4))
		
		var relics_text = ""
		for rid in GameManager.owned_relics:
			if relics_text != "": relics_text += ", "
			relics_text += GameManager.RELICS[rid]["name"]
		if relics_text != "":
			_lbl(vbox, "Relics: " + relics_text, 12, Color(0.5, 0.45, 0.3))
		
		_spacer(vbox, 15)
		_lbl(vbox, "═══ ✦ ═══", 28, Color(0.7, 0.6, 0.3))
		_spacer(vbox, 25)
		
		# Continue to infinite
		var continue_c = CenterContainer.new()
		vbox.add_child(continue_c)
		var continue_btn = Button.new()
		continue_btn.text = "  Continue (Infinite Scaling)  "
		continue_btn.custom_minimum_size = Vector2(280, 45)
		continue_btn.add_theme_font_size_override("font_size", 18)
		continue_btn.pressed.connect(_on_continue)
		continue_c.add_child(continue_btn)
		
		_spacer(vbox, 10)
	else:
		bg.color = Color(0.08, 0.04, 0.04)
		_lbl(vbox, "UNRAVELED", 48, Color(0.7, 0.2, 0.2))
		_spacer(vbox, 15)
		_lbl(vbox, "The Council's threads claimed another.\nYour essence returns to the loom.", 16, Color(0.5, 0.3, 0.3))
		_spacer(vbox, 10)
		
		var act_name = GameManager.get_act_name()
		_lbl(vbox, "Fell during: %s  |  Level %d" % [act_name, GameManager.current_level + 1], 14, Color(0.4, 0.3, 0.3))
		_lbl(vbox, "Gold: %dg  |  Deck: %d cards" % [GameManager.gold, GameManager.deck.size()], 14, Color(0.4, 0.3, 0.3))
		_spacer(vbox, 30)
	
	# Restart
	var restart_c = CenterContainer.new()
	vbox.add_child(restart_c)
	var restart_btn = Button.new()
	restart_btn.text = "  New Run  "
	restart_btn.custom_minimum_size = Vector2(180, 40)
	restart_btn.add_theme_font_size_override("font_size", 16)
	restart_btn.pressed.connect(func(): GameManager.start_new_run())
	restart_c.add_child(restart_btn)
	
	_spacer(vbox, 8)
	
	var menu_c = CenterContainer.new()
	vbox.add_child(menu_c)
	var menu_btn = Button.new()
	menu_btn.text = "  Main Menu  "
	menu_btn.custom_minimum_size = Vector2(150, 35)
	menu_btn.add_theme_font_size_override("font_size", 14)
	menu_btn.pressed.connect(func(): GameManager.screen_change_requested.emit("menu", {}))
	menu_c.add_child(menu_btn)

func _on_continue() -> void:
	# Continue the run — act/level have already been advanced
	GameManager.screen_change_requested.emit("map", {})

func _lbl(parent: Node, text: String, font_size: int, color: Color) -> void:
	var l = Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	parent.add_child(l)

func _spacer(parent: Node, h: float) -> void:
	var s = Control.new()
	s.custom_minimum_size = Vector2(0, h)
	parent.add_child(s)
