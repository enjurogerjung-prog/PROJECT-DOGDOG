extends Control

func _ready() -> void:
	var bg = ColorRect.new(); bg.color = Color(0.05, 0.07, 0.05); bg.set_anchors_preset(PRESET_FULL_RECT); add_child(bg)
	var v = VBoxContainer.new(); v.set_anchors_preset(PRESET_CENTER); v.custom_minimum_size = Vector2(500, 300)
	v.position = Vector2(-250, -150); v.alignment = BoxContainer.ALIGNMENT_CENTER; v.add_theme_constant_override("separation", 12); add_child(v)
	_l(v, "🏕 REST STOP", 28, Color(0.7, 0.8, 0.6))
	_l(v, "A quiet glade in Wonderland. The mushrooms glow softly.", 14, Color(0.5, 0.5, 0.45))
	_l(v, "HP: %d / %d" % [GM.hp, GM.max_hp], 16, Color(0.7, 0.4, 0.4))
	var sp = Control.new(); sp.custom_minimum_size = Vector2(0, 15); v.add_child(sp)
	var heal_amt = int(GM.max_hp * 0.3)
	var hb = Button.new(); hb.text = "  Rest — Heal %d HP  " % heal_amt; hb.custom_minimum_size = Vector2(300, 45)
	hb.add_theme_font_size_override("font_size", 16)
	hb.pressed.connect(func(): GM.heal(heal_amt); GM.screen_change.emit("map", {}))
	var hc = CenterContainer.new(); v.add_child(hc); hc.add_child(hb)
	var ub = Button.new(); ub.text = "  Manage Deck (Sell/Combine)  "; ub.custom_minimum_size = Vector2(300, 40)
	ub.add_theme_font_size_override("font_size", 14)
	ub.pressed.connect(func(): GM.screen_change.emit("deck_manager", {"return_to": "rest"}))
	var uc = CenterContainer.new(); v.add_child(uc); uc.add_child(ub)
	var lb = Button.new(); lb.text = "  Leave  "; lb.custom_minimum_size = Vector2(200, 35)
	lb.add_theme_font_size_override("font_size", 14)
	lb.pressed.connect(func(): GM.screen_change.emit("map", {}))
	var lc = CenterContainer.new(); v.add_child(lc); lc.add_child(lb)

func _l(p: Node, t: String, sz: int, c: Color) -> void:
	var l = Label.new(); l.text = t; l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", sz); l.add_theme_color_override("font_color", c); p.add_child(l)
