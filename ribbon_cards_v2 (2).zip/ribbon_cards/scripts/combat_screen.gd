extends Control

# ============================================================
# Combat Screen — Cards, enemies, statuses, synergy, type advantage
# ============================================================

var energy: int = 3
var max_energy: int = 3
var player_block: int = 0
var player_statuses: Dictionary = {"poison": 0, "strength": 0, "weak": 0, "vulnerable": 0}

var draw_pile: Array = []  # Array of {id, tier}
var hand: Array = []
var discard_pile: Array = []
var hand_size: int = 6

var enemies: Array = []
var enemy_archetype: String = ""
var selected_card_idx: int = -1
var combat_over: bool = false
var player_turn: bool = true
var turn_number: int = 0
var is_boss_fight: bool = false

# Synergy tracking
var cards_played_by_arch: Dictionary = {"rock": 0, "scissors": 0, "paper": 0, "neutral": 0}
var synergies_triggered: Array = []

# UI refs
var hand_container: HBoxContainer
var enemy_container: HBoxContainer
var energy_label: Label
var hp_label: Label
var block_label: Label
var status_label: Label
var turn_label: Label
var gold_preview: Label
var synergy_label: RichTextLabel
var draw_label: Label
var discard_label: Label
var end_turn_btn: Button
var log_label: RichTextLabel

func _ready() -> void:
	var encounter = get_meta("encounter") if has_meta("encounter") else {}
	_init_combat(encounter)
	_build_ui()
	_start_player_turn()

func _init_combat(encounter: Dictionary) -> void:
	max_energy = GameManager.MAX_ENERGY + GameManager.energy_bonus
	hand_size = GameManager.HAND_SIZE + GameManager.hand_size_bonus
	energy = max_energy
	player_block = 0
	player_statuses = {"poison": 0, "strength": 0, "weak": 0, "vulnerable": 0}
	turn_number = 0
	is_boss_fight = encounter.get("is_boss", false)
	
	# Relic: start strength
	for rid in GameManager.owned_relics:
		var r = GameManager.RELICS[rid]
		if r["effect"] == "start_strength":
			player_statuses["strength"] += r["value"]
		elif r["effect"] == "start_block":
			player_block += r["value"]
	
	# Build draw pile from deck
	draw_pile = GameManager.deck.duplicate(true)
	draw_pile.shuffle()
	hand.clear()
	discard_pile.clear()
	
	# Spawn enemies with scaling
	enemies.clear()
	var scaling = GameManager.get_scaling_multiplier()
	var enemy_ids = encounter.get("enemies", ["frayed_hound"])
	for eid in enemy_ids:
		var edata = GameManager.ENEMIES[eid]
		var hp = int(randi_range(edata["min_hp"], edata["max_hp"]) * scaling)
		enemy_archetype = edata.get("archetype", "neutral")
		enemies.append({
			"id": eid, "name": edata["name"],
			"archetype": edata.get("archetype", "neutral"),
			"hp": hp, "max_hp": hp, "block": 0,
			"intents": edata["intents"],
			"intent_idx": randi() % edata["intents"].size(),
			"statuses": {"poison": 0, "strength": 0, "weak": 0, "vulnerable": 0},
		})

func _build_ui() -> void:
	var bg = ColorRect.new()
	bg.color = Color(0.05, 0.04, 0.07)
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	
	# Top bar
	var top = HBoxContainer.new()
	top.position = Vector2(15, 8)
	top.add_theme_constant_override("separation", 20)
	add_child(top)
	
	hp_label = Label.new()
	hp_label.add_theme_font_size_override("font_size", 18)
	top.add_child(hp_label)
	
	block_label = Label.new()
	block_label.add_theme_font_size_override("font_size", 18)
	block_label.add_theme_color_override("font_color", Color(0.3, 0.6, 0.9))
	top.add_child(block_label)
	
	energy_label = Label.new()
	energy_label.add_theme_font_size_override("font_size", 18)
	energy_label.add_theme_color_override("font_color", Color(0.9, 0.8, 0.3))
	top.add_child(energy_label)
	
	status_label = Label.new()
	status_label.add_theme_font_size_override("font_size", 14)
	status_label.add_theme_color_override("font_color", Color(0.7, 0.6, 0.8))
	top.add_child(status_label)
	
	# Turn counter + gold preview (prominent)
	var turn_box = VBoxContainer.new()
	turn_box.position = Vector2(1100, 8)
	add_child(turn_box)
	
	turn_label = Label.new()
	turn_label.add_theme_font_size_override("font_size", 22)
	turn_label.add_theme_color_override("font_color", Color(0.9, 0.75, 0.3))
	turn_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	turn_box.add_child(turn_label)
	
	gold_preview = Label.new()
	gold_preview.add_theme_font_size_override("font_size", 13)
	gold_preview.add_theme_color_override("font_color", Color(0.6, 0.55, 0.3))
	gold_preview.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	turn_box.add_child(gold_preview)
	
	# Synergy indicator
	synergy_label = RichTextLabel.new()
	synergy_label.position = Vector2(15, 35)
	synergy_label.custom_minimum_size = Vector2(500, 20)
	synergy_label.size = Vector2(500, 20)
	synergy_label.bbcode_enabled = true
	synergy_label.add_theme_font_size_override("normal_font_size", 12)
	synergy_label.fit_content = true
	add_child(synergy_label)
	
	# Draw / Discard
	draw_label = Label.new()
	draw_label.position = Vector2(15, 685)
	draw_label.add_theme_font_size_override("font_size", 13)
	draw_label.add_theme_color_override("font_color", Color(0.45, 0.45, 0.55))
	add_child(draw_label)
	
	discard_label = Label.new()
	discard_label.position = Vector2(150, 685)
	discard_label.add_theme_font_size_override("font_size", 13)
	discard_label.add_theme_color_override("font_color", Color(0.45, 0.45, 0.55))
	add_child(discard_label)
	
	# Enemy area
	enemy_container = HBoxContainer.new()
	enemy_container.position = Vector2(0, 65)
	enemy_container.custom_minimum_size = Vector2(1280, 230)
	enemy_container.alignment = BoxContainer.ALIGNMENT_CENTER
	enemy_container.add_theme_constant_override("separation", 20)
	add_child(enemy_container)
	_build_enemy_nodes()
	
	# Hand area
	hand_container = HBoxContainer.new()
	hand_container.position = Vector2(0, 485)
	hand_container.custom_minimum_size = Vector2(1280, 195)
	hand_container.alignment = BoxContainer.ALIGNMENT_CENTER
	hand_container.add_theme_constant_override("separation", 5)
	add_child(hand_container)
	
	# End turn
	end_turn_btn = Button.new()
	end_turn_btn.text = "END TURN"
	end_turn_btn.position = Vector2(1130, 495)
	end_turn_btn.custom_minimum_size = Vector2(120, 40)
	end_turn_btn.add_theme_font_size_override("font_size", 15)
	end_turn_btn.pressed.connect(_on_end_turn)
	add_child(end_turn_btn)
	
	# Log
	log_label = RichTextLabel.new()
	log_label.position = Vector2(860, 370)
	log_label.size = Vector2(400, 110)
	log_label.custom_minimum_size = Vector2(400, 110)
	log_label.bbcode_enabled = true
	log_label.add_theme_font_size_override("normal_font_size", 11)
	log_label.scroll_following = true
	add_child(log_label)
	
	_update_all_ui()

func _build_enemy_nodes() -> void:
	for c in enemy_container.get_children(): c.queue_free()
	for i in range(enemies.size()):
		enemy_container.add_child(_create_enemy_panel(enemies[i], i))

func _create_enemy_panel(enemy: Dictionary, idx: int) -> PanelContainer:
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(200, 220)
	
	var arch_color = GameManager.ARCHETYPE_COLORS.get(enemy["archetype"], Color.GRAY)
	
	var bg = ColorRect.new()
	bg.name = "BG"
	bg.color = Color(0.12, 0.1, 0.15)
	bg.custom_minimum_size = Vector2(200, 220)
	panel.add_child(bg)
	
	# Archetype stripe
	var stripe = ColorRect.new()
	stripe.color = arch_color
	stripe.custom_minimum_size = Vector2(200, 4)
	stripe.position = Vector2(0, 0)
	bg.add_child(stripe)
	
	var vbox = VBoxContainer.new()
	vbox.name = "VBox"
	vbox.position = Vector2(8, 8)
	vbox.custom_minimum_size = Vector2(184, 204)
	vbox.add_theme_constant_override("separation", 3)
	panel.add_child(vbox)
	
	var name_lbl = Label.new()
	name_lbl.name = "Name"
	name_lbl.text = enemy["name"]
	name_lbl.add_theme_font_size_override("font_size", 14)
	name_lbl.add_theme_color_override("font_color", arch_color.lightened(0.4))
	name_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(name_lbl)
	
	# HP
	var hp_bg = ColorRect.new()
	hp_bg.name = "HPBg"
	hp_bg.color = Color(0.2, 0.1, 0.1)
	hp_bg.custom_minimum_size = Vector2(184, 18)
	vbox.add_child(hp_bg)
	var hp_bar = ColorRect.new()
	hp_bar.name = "HPBar"
	hp_bar.color = Color(0.7, 0.2, 0.2)
	hp_bar.custom_minimum_size = Vector2(184, 18)
	hp_bg.add_child(hp_bar)
	var hp_txt = Label.new()
	hp_txt.name = "HPText"
	hp_txt.add_theme_font_size_override("font_size", 12)
	hp_txt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hp_txt.custom_minimum_size = Vector2(184, 18)
	hp_bg.add_child(hp_txt)
	
	var block_lbl = Label.new()
	block_lbl.name = "Block"
	block_lbl.add_theme_font_size_override("font_size", 13)
	block_lbl.add_theme_color_override("font_color", Color(0.3, 0.6, 0.9))
	block_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(block_lbl)
	
	var stat_lbl = Label.new()
	stat_lbl.name = "Status"
	stat_lbl.add_theme_font_size_override("font_size", 11)
	stat_lbl.add_theme_color_override("font_color", Color(0.7, 0.5, 0.8))
	stat_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(stat_lbl)
	
	# Intent
	var intent = enemy["intents"][enemy["intent_idx"]]
	var intent_bg = ColorRect.new()
	intent_bg.name = "IntentBG"
	intent_bg.color = GameManager.get_intent_color(intent) * 0.25
	intent_bg.custom_minimum_size = Vector2(184, 30)
	vbox.add_child(intent_bg)
	var intent_lbl = Label.new()
	intent_lbl.name = "Intent"
	intent_lbl.text = "» " + GameManager.get_intent_text(intent)
	intent_lbl.add_theme_font_size_override("font_size", 13)
	intent_lbl.add_theme_color_override("font_color", GameManager.get_intent_color(intent))
	intent_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	intent_lbl.custom_minimum_size = Vector2(184, 30)
	intent_bg.add_child(intent_lbl)
	
	# Body placeholder
	var body = ColorRect.new()
	body.color = arch_color.darkened(0.7)
	body.custom_minimum_size = Vector2(184, 55)
	vbox.add_child(body)
	var skull = Label.new()
	skull.text = "☠" if not is_boss_fight else "⚔"
	skull.add_theme_font_size_override("font_size", 30)
	skull.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	skull.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	skull.custom_minimum_size = Vector2(184, 55)
	body.add_child(skull)
	
	# Click
	var btn = Button.new()
	btn.flat = true
	btn.set_anchors_preset(PRESET_FULL_RECT)
	btn.custom_minimum_size = Vector2(200, 220)
	btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	btn.pressed.connect(_on_enemy_clicked.bind(idx))
	panel.add_child(btn)
	
	return panel

func _create_card_node(card_entry: Dictionary, hand_idx: int) -> PanelContainer:
	var card_data = GameManager.get_card_at_tier(card_entry["id"], card_entry["tier"])
	var arch_color = GameManager.get_card_color(card_entry["id"])
	var tier_color = GameManager.get_tier_color(card_entry["tier"])
	
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(130, 185)
	
	var bg = ColorRect.new()
	bg.name = "CardBG"
	bg.color = arch_color.darkened(0.2)
	bg.custom_minimum_size = Vector2(130, 185)
	panel.add_child(bg)
	
	# Tier stripe at top
	if card_entry["tier"] != GameManager.TIER_BASE:
		var tier_stripe = ColorRect.new()
		tier_stripe.color = tier_color
		tier_stripe.custom_minimum_size = Vector2(130, 3)
		bg.add_child(tier_stripe)
	
	var vbox = VBoxContainer.new()
	vbox.position = Vector2(6, 5)
	vbox.custom_minimum_size = Vector2(118, 175)
	vbox.add_theme_constant_override("separation", 2)
	panel.add_child(vbox)
	
	# Cost + Name
	var top_row = HBoxContainer.new()
	vbox.add_child(top_row)
	var cost_bg = ColorRect.new()
	cost_bg.color = Color(0.12, 0.1, 0.08)
	cost_bg.custom_minimum_size = Vector2(24, 24)
	top_row.add_child(cost_bg)
	var cost_lbl = Label.new()
	cost_lbl.text = str(card_data["cost"])
	cost_lbl.add_theme_font_size_override("font_size", 15)
	cost_lbl.add_theme_color_override("font_color", Color(0.9, 0.8, 0.3))
	cost_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	cost_lbl.custom_minimum_size = Vector2(24, 24)
	cost_bg.add_child(cost_lbl)
	
	var name_lbl = Label.new()
	var prefix = GameManager.get_tier_prefix(card_entry["tier"])
	name_lbl.text = " " + prefix + card_data["name"]
	name_lbl.add_theme_font_size_override("font_size", 11)
	if card_entry["tier"] != GameManager.TIER_BASE:
		name_lbl.add_theme_color_override("font_color", tier_color)
	top_row.add_child(name_lbl)
	
	# Type + Archetype
	var type_row = HBoxContainer.new()
	vbox.add_child(type_row)
	var type_lbl = Label.new()
	type_lbl.text = card_data["type"].to_upper()
	type_lbl.add_theme_font_size_override("font_size", 9)
	type_lbl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	type_row.add_child(type_lbl)
	var arch_lbl = Label.new()
	arch_lbl.text = "  " + card_data.get("archetype", "neutral").to_upper()
	arch_lbl.add_theme_font_size_override("font_size", 9)
	arch_lbl.add_theme_color_override("font_color", arch_color.lightened(0.3))
	type_row.add_child(arch_lbl)
	
	# Art area
	var art = ColorRect.new()
	art.color = arch_color.darkened(0.45)
	art.custom_minimum_size = Vector2(118, 55)
	vbox.add_child(art)
	
	# Desc
	var desc = Label.new()
	desc.text = card_data["desc"]
	desc.add_theme_font_size_override("font_size", 11)
	desc.add_theme_color_override("font_color", Color(0.88, 0.88, 0.84))
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.custom_minimum_size = Vector2(118, 50)
	vbox.add_child(desc)
	
	# Click
	var btn = Button.new()
	btn.flat = true
	btn.set_anchors_preset(PRESET_FULL_RECT)
	btn.custom_minimum_size = Vector2(130, 185)
	btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	btn.pressed.connect(_on_card_clicked.bind(hand_idx))
	panel.add_child(btn)
	
	return panel

# ============================================================
# TURN FLOW
# ============================================================

func _start_player_turn() -> void:
	if combat_over: return
	player_turn = true
	turn_number += 1
	energy = max_energy
	player_block = 0
	cards_played_by_arch = {"rock": 0, "scissors": 0, "paper": 0, "neutral": 0}
	synergies_triggered.clear()
	
	# Tick poison
	if player_statuses["poison"] > 0:
		GameManager.damage_player(player_statuses["poison"])
		_log("[color=green]Poison: -%d HP[/color]" % player_statuses["poison"])
		player_statuses["poison"] = maxi(player_statuses["poison"] - 1, 0)
		if GameManager.player_hp <= 0:
			_end_combat(false)
			return
	player_statuses["weak"] = maxi(player_statuses["weak"] - 1, 0)
	player_statuses["vulnerable"] = maxi(player_statuses["vulnerable"] - 1, 0)
	
	_draw_cards(hand_size)
	_rebuild_hand_ui()
	_update_all_ui()
	end_turn_btn.disabled = false

func _on_end_turn() -> void:
	if not player_turn or combat_over: return
	player_turn = false
	end_turn_btn.disabled = true
	selected_card_idx = -1
	for c in hand: discard_pile.append(c)
	hand.clear()
	_rebuild_hand_ui()
	
	await _execute_enemy_turns()
	if GameManager.player_hp <= 0:
		_end_combat(false)
		return
	_start_player_turn()

func _execute_enemy_turns() -> void:
	for i in range(enemies.size()):
		if combat_over: return
		var enemy = enemies[i]
		if enemy["hp"] <= 0: continue
		enemy["block"] = 0
		
		# Tick poison
		if enemy["statuses"]["poison"] > 0:
			enemy["hp"] -= enemy["statuses"]["poison"]
			_log("[color=green]%s: -%d poison[/color]" % [enemy["name"], enemy["statuses"]["poison"]])
			enemy["statuses"]["poison"] = maxi(enemy["statuses"]["poison"] - 1, 0)
			if enemy["hp"] <= 0:
				_log("[color=yellow]%s destroyed![/color]" % enemy["name"])
				if _check_all_dead(): return
				_update_all_ui()
				continue
		enemy["statuses"]["weak"] = maxi(enemy["statuses"]["weak"] - 1, 0)
		enemy["statuses"]["vulnerable"] = maxi(enemy["statuses"]["vulnerable"] - 1, 0)
		
		var intent = enemy["intents"][enemy["intent_idx"]]
		var val = int(intent["value"] * GameManager.get_scaling_multiplier()) if GameManager.infinite_cycle > 0 else intent["value"]
		_execute_intent(enemy, intent["type"], val)
		enemy["intent_idx"] = (enemy["intent_idx"] + 1) % enemy["intents"].size()
		_update_all_ui()
		await get_tree().create_timer(0.25).timeout

func _execute_intent(enemy: Dictionary, itype: String, value: int) -> void:
	match itype:
		"attack", "lifesteal_attack":
			var atk = value + enemy["statuses"]["strength"]
			if enemy["statuses"]["weak"] > 0: atk = int(atk * 0.75)
			if player_statuses["vulnerable"] > 0: atk = int(atk * 1.5)
			atk = maxi(atk, 0)
			var actual = _damage_player(atk)
			_log("%s attacks: %d dmg" % [enemy["name"], actual])
			if itype == "lifesteal_attack":
				enemy["hp"] = mini(enemy["hp"] + actual, enemy["max_hp"])
				_log("[color=red]%s heals %d[/color]" % [enemy["name"], actual])
		"defend":
			enemy["block"] += value
			_log("%s blocks %d" % [enemy["name"], value])
		"buff_strength":
			enemy["statuses"]["strength"] += value
			_log("%s +%d Str" % [enemy["name"], value])
		"debuff_poison":
			player_statuses["poison"] += value
			_log("[color=green]%s poisons you %d[/color]" % [enemy["name"], value])
		"debuff_weak":
			player_statuses["weak"] += value
			_log("[color=purple]%s weakens you %d[/color]" % [enemy["name"], value])
		"debuff_vulnerable":
			player_statuses["vulnerable"] += value
			_log("[color=purple]%s vulns you %d[/color]" % [enemy["name"], value])

func _damage_player(amount: int) -> int:
	var rem = amount
	if player_block > 0:
		if player_block >= rem:
			player_block -= rem
			return 0
		rem -= player_block
		player_block = 0
	GameManager.damage_player(rem)
	return rem

# ============================================================
# CARD PLAYING
# ============================================================

func _on_card_clicked(hand_idx: int) -> void:
	if not player_turn or combat_over: return
	if hand_idx < 0 or hand_idx >= hand.size(): return
	var entry = hand[hand_idx]
	var card = GameManager.get_card_at_tier(entry["id"], entry["tier"])
	if card["cost"] > energy:
		_log("[color=red]Not enough energy![/color]")
		return
	var target = card.get("target", "self")
	if target == "single":
		if selected_card_idx == hand_idx:
			selected_card_idx = -1
		else:
			selected_card_idx = hand_idx
		_rebuild_hand_ui()
	else:
		_play_card(hand_idx, -1)

func _on_enemy_clicked(enemy_idx: int) -> void:
	if not player_turn or combat_over: return
	if selected_card_idx < 0 or selected_card_idx >= hand.size(): return
	if enemy_idx < 0 or enemy_idx >= enemies.size(): return
	if enemies[enemy_idx]["hp"] <= 0: return
	_play_card(selected_card_idx, enemy_idx)

func _play_card(hand_idx: int, target: int) -> void:
	var entry = hand[hand_idx]
	var card = GameManager.get_card_at_tier(entry["id"], entry["tier"])
	energy -= card["cost"]
	
	var card_arch = card.get("archetype", "neutral")
	
	for effect in card["effects"]:
		_apply_effect(effect, target, card.get("target", "self"), card_arch)
	
	# Track synergy
	cards_played_by_arch[card_arch] = cards_played_by_arch.get(card_arch, 0) + 1
	_check_synergy(card_arch)
	
	_log("Played %s%s" % [GameManager.get_tier_prefix(entry["tier"]), card["name"]])
	
	hand.remove_at(hand_idx)
	discard_pile.append(entry)
	selected_card_idx = -1
	_check_all_dead()
	_rebuild_hand_ui()
	_update_all_ui()

func _check_synergy(arch: String) -> void:
	var threshold = GameManager.synergy_threshold
	if cards_played_by_arch.get(arch, 0) == threshold and arch not in synergies_triggered:
		synergies_triggered.append(arch)
		match arch:
			"rock":
				player_block += 5
				_log("[color=cyan]⚡ Rock Synergy: +5 Block![/color]")
			"scissors":
				for i in range(enemies.size()):
					if enemies[i]["hp"] > 0:
						_deal_damage_to_enemy(i, 3)
				_log("[color=red]⚡ Scissors Synergy: 3 dmg ALL![/color]")
			"paper":
				for i in range(enemies.size()):
					if enemies[i]["hp"] > 0:
						enemies[i]["statuses"]["weak"] += 1
				_log("[color=white]⚡ Paper Synergy: 1 Weak ALL![/color]")
			"neutral":
				_draw_cards(1)
				_log("[color=gray]⚡ Neutral Synergy: Draw 1![/color]")

func _apply_effect(effect: Dictionary, target: int, target_type: String, card_arch: String) -> void:
	var val = effect["value"]
	match effect["type"]:
		"damage":
			var atk = val + player_statuses["strength"]
			if player_statuses["weak"] > 0: atk = int(atk * 0.75)
			atk = maxi(atk, 0)
			if target_type == "all":
				for i in range(enemies.size()):
					if enemies[i]["hp"] > 0:
						var a = _calc_final_atk(atk, card_arch, enemies[i])
						_deal_damage_to_enemy(i, a)
			elif target >= 0:
				var a = _calc_final_atk(atk, card_arch, enemies[target])
				_deal_damage_to_enemy(target, a)
		"block": player_block += val
		"heal": GameManager.heal_player(val)
		"lifesteal":
			GameManager.heal_player(val)
		"draw": _draw_cards(val)
		"energy": energy += val
		"self_damage": GameManager.damage_player(val)
		"strength": player_statuses["strength"] += val
		"cleanse":
			player_statuses["poison"] = 0
			player_statuses["weak"] = 0
			player_statuses["vulnerable"] = 0
		"poison":
			if target_type == "all":
				for i in range(enemies.size()):
					if enemies[i]["hp"] > 0: enemies[i]["statuses"]["poison"] += val
			elif target >= 0: enemies[target]["statuses"]["poison"] += val
		"weak":
			if target_type == "all" or target_type == "self":
				# "self" target with weak means apply to single enemy
				if target >= 0: enemies[target]["statuses"]["weak"] += val
			elif target >= 0: enemies[target]["statuses"]["weak"] += val
		"weak_all":
			for i in range(enemies.size()):
				if enemies[i]["hp"] > 0: enemies[i]["statuses"]["weak"] += val
		"vulnerable":
			if target >= 0: enemies[target]["statuses"]["vulnerable"] += val
			elif target_type == "all":
				for i in range(enemies.size()):
					if enemies[i]["hp"] > 0: enemies[i]["statuses"]["vulnerable"] += val

func _calc_final_atk(base_atk: int, card_arch: String, enemy: Dictionary) -> int:
	var atk = base_atk
	# Type advantage
	var advantage = GameManager.get_type_advantage(card_arch, enemy["archetype"])
	if advantage != 0.0:
		atk = int(atk * (1.0 + advantage))
	# Vulnerable
	if enemy["statuses"]["vulnerable"] > 0:
		atk = int(atk * 1.5)
	return maxi(atk, 0)

func _deal_damage_to_enemy(idx: int, amount: int) -> void:
	var enemy = enemies[idx]
	var rem = amount
	if enemy["block"] > 0:
		if enemy["block"] >= rem:
			enemy["block"] -= rem
			return
		rem -= enemy["block"]
		enemy["block"] = 0
	enemy["hp"] = maxi(enemy["hp"] - rem, 0)
	if enemy["hp"] <= 0:
		_log("[color=yellow]%s destroyed![/color]" % enemy["name"])

func _draw_cards(count: int) -> void:
	for i in range(count):
		if hand.size() >= 10: break
		if draw_pile.is_empty():
			draw_pile = discard_pile.duplicate(true)
			discard_pile.clear()
			draw_pile.shuffle()
			if draw_pile.is_empty(): break
		hand.append(draw_pile.pop_back())

func _check_all_dead() -> bool:
	for e in enemies:
		if e["hp"] > 0: return false
	_end_combat(true)
	return true

func _end_combat(victory: bool) -> void:
	if combat_over: return
	combat_over = true
	end_turn_btn.disabled = true
	if victory:
		_log("[color=yellow]VICTORY! (%d turns)[/color]" % turn_number)
		var phase_data = GameManager.get_current_phase_data()
		var was_boss = phase_data.get("is_boss", false)
		var prev_cycle = GameManager.infinite_cycle
		var was_last_level = (GameManager.current_level >= GameManager.act_levels.size() - 1)
		var was_last_act = (GameManager.current_act >= 2)
		var rewards = GameManager.apply_post_fight_rewards(turn_number)
		GameManager.advance_phase()
		await get_tree().create_timer(0.8).timeout
		# Check if we just completed Act 3
		if was_boss and was_last_level and was_last_act and GameManager.infinite_cycle > prev_cycle:
			GameManager.screen_change_requested.emit("game_over", {"victory": true})
		else:
			GameManager.screen_change_requested.emit("round_summary", {"rewards": rewards, "was_boss": was_boss})
	else:
		_log("[color=red]DEFEAT...[/color]")
		await get_tree().create_timer(1.2).timeout
		GameManager.screen_change_requested.emit("game_over", {"victory": false})

# ============================================================
# UI
# ============================================================

func _update_all_ui() -> void:
	hp_label.text = "HP: %d/%d" % [GameManager.player_hp, GameManager.player_max_hp]
	hp_label.add_theme_color_override("font_color", Color(1, 0.3, 0.3) if GameManager.player_hp < GameManager.player_max_hp * 0.3 else Color(0.8, 0.3, 0.3))
	block_label.text = "Blk: %d" % player_block if player_block > 0 else ""
	energy_label.text = "⚡ %d/%d" % [energy, max_energy]
	
	turn_label.text = "Turn %d" % turn_number
	var preview_gold = GameManager.calculate_fight_gold(turn_number)
	gold_preview.text = "Win now: +%dg" % preview_gold if preview_gold > 0 else "Win now: +0g"
	
	# Status
	var parts: Array = []
	if player_statuses["poison"] > 0: parts.append("PSN:%d" % player_statuses["poison"])
	if player_statuses["strength"] > 0: parts.append("STR:+%d" % player_statuses["strength"])
	if player_statuses["weak"] > 0: parts.append("WK:%d" % player_statuses["weak"])
	if player_statuses["vulnerable"] > 0: parts.append("VL:%d" % player_statuses["vulnerable"])
	status_label.text = "  ".join(parts)
	
	# Synergy tracker
	var syn_parts: Array = []
	for arch in ["rock", "scissors", "paper", "neutral"]:
		var count = cards_played_by_arch.get(arch, 0)
		if count > 0:
			var thresh = GameManager.synergy_threshold
			var triggered = arch in synergies_triggered
			var color_hex = GameManager.ARCHETYPE_COLORS[arch].to_html(false)
			if triggered:
				syn_parts.append("[color=#%s]%s ⚡[/color]" % [color_hex, arch.to_upper()])
			else:
				syn_parts.append("[color=#%s]%s %d/%d[/color]" % [color_hex, arch.substr(0,1).to_upper(), count, thresh])
	synergy_label.clear()
	synergy_label.append_text("  ".join(syn_parts) if syn_parts.size() > 0 else "")
	
	draw_label.text = "Draw: %d" % draw_pile.size()
	discard_label.text = "Disc: %d" % discard_pile.size()
	
	# Enemies
	for i in range(enemies.size()):
		_update_enemy_panel(i)

func _update_enemy_panel(idx: int) -> void:
	if idx >= enemy_container.get_child_count(): return
	var panel = enemy_container.get_child(idx)
	var enemy = enemies[idx]
	
	var hp_bar = _find(panel, "HPBar")
	if hp_bar:
		var ratio = clampf(float(enemy["hp"]) / float(enemy["max_hp"]), 0.0, 1.0)
		hp_bar.custom_minimum_size.x = 184.0 * ratio
		hp_bar.color = Color(0.9, 0.2, 0.1) if ratio < 0.3 else Color(0.7, 0.2, 0.2)
	
	var hp_txt = _find(panel, "HPText")
	if hp_txt: hp_txt.text = "%d/%d" % [maxi(enemy["hp"], 0), enemy["max_hp"]]
	
	var blk = _find(panel, "Block")
	if blk: blk.text = "Blk: %d" % enemy["block"] if enemy["block"] > 0 else ""
	
	var stat = _find(panel, "Status")
	if stat:
		var p: Array = []
		if enemy["statuses"]["poison"] > 0: p.append("PSN:%d" % enemy["statuses"]["poison"])
		if enemy["statuses"]["strength"] > 0: p.append("STR:+%d" % enemy["statuses"]["strength"])
		if enemy["statuses"]["weak"] > 0: p.append("WK:%d" % enemy["statuses"]["weak"])
		if enemy["statuses"]["vulnerable"] > 0: p.append("VL:%d" % enemy["statuses"]["vulnerable"])
		stat.text = " ".join(p)
	
	var intent_lbl = _find(panel, "Intent")
	if intent_lbl:
		if enemy["hp"] <= 0:
			intent_lbl.text = "DEFEATED"
			intent_lbl.add_theme_color_override("font_color", Color(0.4, 0.4, 0.4))
		else:
			var intent = enemy["intents"][enemy["intent_idx"]]
			intent_lbl.text = "» " + GameManager.get_intent_text(intent)
			intent_lbl.add_theme_color_override("font_color", GameManager.get_intent_color(intent))
	
	if enemy["hp"] <= 0: panel.modulate = Color(0.35, 0.35, 0.35)

func _rebuild_hand_ui() -> void:
	for c in hand_container.get_children(): c.queue_free()
	for i in range(hand.size()):
		var node = _create_card_node(hand[i], i)
		hand_container.add_child(node)
		if i == selected_card_idx:
			node.position.y -= 20
			var cbg = _find(node, "CardBG")
			if cbg: cbg.color = cbg.color.lightened(0.25)

func _find(node: Node, n: String) -> Node:
	if node.name == n: return node
	for c in node.get_children():
		var r = _find(c, n)
		if r: return r
	return null

func _log(t: String) -> void:
	log_label.append_text(t + "\n")
