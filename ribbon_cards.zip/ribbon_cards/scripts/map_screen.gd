extends Control

# ============================================================
# Map Screen — Shows act progress and fight choices
# ============================================================

func _ready() -> void:
	_build_ui()

func _build_ui() -> void:
	# Background
	var bg = ColorRect.new()
	bg.color = Color(0.07, 0.06, 0.09)
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	
	var act_data = GameManager.ACTS[GameManager.current_act]
	
	# Top bar — Act name + player HP
	var top_bar = HBoxContainer.new()
	top_bar.position = Vector2(30, 15)
	top_bar.custom_minimum_size = Vector2(1220, 40)
	add_child(top_bar)
	
	var act_label = Label.new()
	act_label.text = act_data["name"]
	act_label.add_theme_font_size_override("font_size", 28)
	act_label.add_theme_color_override("font_color", Color(0.8, 0.65, 0.7))
	act_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top_bar.add_child(act_label)
	
	var hp_label = Label.new()
	hp_label.text = "HP: %d / %d" % [GameManager.player_hp, GameManager.player_max_hp]
	hp_label.add_theme_font_size_override("font_size", 20)
	hp_label.add_theme_color_override("font_color", Color(0.8, 0.3, 0.3))
	top_bar.add_child(hp_label)
	
	# Act description
	var desc_label = Label.new()
	desc_label.text = act_data["desc"]
	desc_label.position = Vector2(30, 55)
	desc_label.add_theme_font_size_override("font_size", 14)
	desc_label.add_theme_color_override("font_color", Color(0.45, 0.4, 0.45))
	add_child(desc_label)
	
	# Deck count
	var deck_label = Label.new()
	deck_label.text = "Deck: %d cards" % GameManager.deck.size()
	deck_label.position = Vector2(30, 80)
	deck_label.add_theme_font_size_override("font_size", 14)
	deck_label.add_theme_color_override("font_color", Color(0.4, 0.5, 0.6))
	add_child(deck_label)
	
	# Map nodes visualization
	var map_container = VBoxContainer.new()
	map_container.set_anchors_preset(PRESET_CENTER)
	map_container.custom_minimum_size = Vector2(800, 450)
	map_container.position = Vector2(-400, -180)
	map_container.alignment = BoxContainer.ALIGNMENT_CENTER
	add_child(map_container)
	
	# Draw 3 fight nodes + boss
	for i in range(4):
		var is_boss = (i == 3)
		var is_current = (i == GameManager.current_fight)
		var is_completed = (i < GameManager.current_fight)
		
		# Node row
		var row = HBoxContainer.new()
		row.alignment = BoxContainer.ALIGNMENT_CENTER
		row.add_theme_constant_override("separation", 30)
		map_container.add_child(row)
		
		# Node number / label
		var node_label = Label.new()
		if is_boss:
			node_label.text = "⚔ "
		else:
			node_label.text = "%d " % (i + 1)
		node_label.add_theme_font_size_override("font_size", 20)
		node_label.custom_minimum_size = Vector2(30, 0)
		if is_completed:
			node_label.add_theme_color_override("font_color", Color(0.3, 0.3, 0.3))
		elif is_current:
			node_label.add_theme_color_override("font_color", Color(0.9, 0.8, 0.5))
		else:
			node_label.add_theme_color_override("font_color", Color(0.4, 0.4, 0.4))
		row.add_child(node_label)
		
		if is_boss:
			# Boss node
			var boss_data = act_data["boss"]
			var boss_btn = _make_encounter_btn(boss_data["label"], is_current, true)
			if is_current:
				boss_btn.pressed.connect(_on_encounter_chosen.bind(boss_data))
			row.add_child(boss_btn)
		elif is_current and not is_boss:
			# Current fight — show two choices
			var node_data = GameManager.get_current_map_node()
			var btn_a = _make_encounter_btn(node_data["choice_a"]["label"], true, false)
			btn_a.pressed.connect(_on_encounter_chosen.bind(node_data["choice_a"]))
			row.add_child(btn_a)
			
			var or_label = Label.new()
			or_label.text = " OR "
			or_label.add_theme_font_size_override("font_size", 16)
			or_label.add_theme_color_override("font_color", Color(0.6, 0.5, 0.4))
			row.add_child(or_label)
			
			var btn_b = _make_encounter_btn(node_data["choice_b"]["label"], true, false)
			btn_b.pressed.connect(_on_encounter_chosen.bind(node_data["choice_b"]))
			row.add_child(btn_b)
		else:
			# Completed or future node
			var placeholder = Label.new()
			if is_completed:
				placeholder.text = "✓ Cleared"
				placeholder.add_theme_color_override("font_color", Color(0.3, 0.5, 0.3))
			else:
				placeholder.text = "· · ·"
				placeholder.add_theme_color_override("font_color", Color(0.3, 0.3, 0.3))
			placeholder.add_theme_font_size_override("font_size", 18)
			placeholder.custom_minimum_size = Vector2(300, 40)
			row.add_child(placeholder)
		
		# Connector line between nodes
		if i < 3:
			var line = Label.new()
			line.text = "│"
			line.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			line.add_theme_font_size_override("font_size", 18)
			line.add_theme_color_override("font_color", Color(0.25, 0.22, 0.28))
			map_container.add_child(line)
	
	# View Deck button
	var view_deck_btn = Button.new()
	view_deck_btn.text = "View Deck"
	view_deck_btn.position = Vector2(1130, 670)
	view_deck_btn.custom_minimum_size = Vector2(120, 35)
	view_deck_btn.pressed.connect(_on_view_deck)
	add_child(view_deck_btn)

func _make_encounter_btn(label_text: String, active: bool, is_boss: bool) -> Button:
	var btn = Button.new()
	btn.text = label_text
	btn.custom_minimum_size = Vector2(260, 50)
	btn.add_theme_font_size_override("font_size", 16)
	btn.disabled = not active
	
	if is_boss:
		btn.custom_minimum_size = Vector2(350, 55)
		btn.add_theme_font_size_override("font_size", 18)
	
	return btn

func _on_encounter_chosen(encounter_data: Dictionary) -> void:
	GameManager.screen_change_requested.emit("combat", {"encounter": encounter_data})

func _on_view_deck() -> void:
	# Simple popup showing deck contents
	var popup = Panel.new()
	popup.set_anchors_preset(PRESET_FULL_RECT)
	popup.position = Vector2(100, 50)
	popup.size = Vector2(1080, 620)
	add_child(popup)
	
	var popup_bg = ColorRect.new()
	popup_bg.color = Color(0.1, 0.08, 0.12, 0.95)
	popup_bg.set_anchors_preset(PRESET_FULL_RECT)
	popup.add_child(popup_bg)
	
	var scroll = ScrollContainer.new()
	scroll.set_anchors_preset(PRESET_FULL_RECT)
	scroll.position = Vector2(20, 50)
	scroll.size = Vector2(1040, 520)
	popup.add_child(scroll)
	
	var grid = GridContainer.new()
	grid.columns = 5
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	scroll.add_child(grid)
	
	for card_id in GameManager.deck:
		var card_data = GameManager.CARDS[card_id]
		var card_panel = _make_mini_card(card_data)
		grid.add_child(card_panel)
	
	var title_label = Label.new()
	title_label.text = "YOUR DECK (%d cards)" % GameManager.deck.size()
	title_label.position = Vector2(20, 10)
	title_label.add_theme_font_size_override("font_size", 22)
	title_label.add_theme_color_override("font_color", Color(0.8, 0.7, 0.75))
	popup.add_child(title_label)
	
	var close_btn = Button.new()
	close_btn.text = "X"
	close_btn.position = Vector2(1030, 5)
	close_btn.custom_minimum_size = Vector2(35, 35)
	close_btn.pressed.connect(func(): popup.queue_free())
	popup.add_child(close_btn)

func _make_mini_card(card_data: Dictionary) -> PanelContainer:
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(190, 60)
	
	var bg = ColorRect.new()
	bg.color = card_data.get("color", Color(0.3, 0.3, 0.3))
	bg.custom_minimum_size = Vector2(190, 60)
	panel.add_child(bg)
	
	var vbox = VBoxContainer.new()
	vbox.position = Vector2(5, 5)
	panel.add_child(vbox)
	
	var name_label = Label.new()
	name_label.text = "%s [%d]" % [card_data["name"], card_data["cost"]]
	name_label.add_theme_font_size_override("font_size", 13)
	vbox.add_child(name_label)
	
	var desc_label = Label.new()
	desc_label.text = card_data["desc"]
	desc_label.add_theme_font_size_override("font_size", 11)
	desc_label.add_theme_color_override("font_color", Color(0.8, 0.8, 0.8))
	vbox.add_child(desc_label)
	
	return panel
