extends Control

var boosters_picked: int = 0
var drafted_cards: Array = []
var current_booster_cards: Array = []

func _ready() -> void: _build_choose_ui()

func _build_choose_ui() -> void:
	for c in get_children(): c.queue_free()
	var bg = ColorRect.new(); bg.color = Color(0.06, 0.05, 0.08); bg.set_anchors_preset(PRESET_FULL_RECT); add_child(bg)
	_l(self, "DRAFT YOUR DECK", 30, Color(0.85, 0.75, 0.6), Vector2(0, 20), 1280)
	_l(self, "Pick booster %d of 3 — choose a color" % (boosters_picked + 1), 18, Color(0.6, 0.55, 0.5), Vector2(0, 58), 1280)
	_l(self, "Drafted: %d cards + 4 Strike + 4 Guard = %d/20" % [drafted_cards.size(), drafted_cards.size() + 8], 14, Color(0.5, 0.5, 0.5), Vector2(0, 85), 1280)
	var row = HBoxContainer.new(); row.position = Vector2(0, 140); row.custom_minimum_size = Vector2(1280, 400)
	row.alignment = BoxContainer.ALIGNMENT_CENTER; row.add_theme_constant_override("separation", 40); add_child(row)
	for arch in ["red_queen", "mad_hatter", "march_hare"]:
		var panel = PanelContainer.new(); panel.custom_minimum_size = Vector2(280, 360)
		var pbg = ColorRect.new(); pbg.color = GM.ARCH_COLORS[arch].darkened(0.6); pbg.custom_minimum_size = Vector2(280, 360); panel.add_child(pbg)
		var stripe = ColorRect.new(); stripe.color = GM.ARCH_COLORS[arch]; stripe.custom_minimum_size = Vector2(280, 5); pbg.add_child(stripe)
		var vb = VBoxContainer.new(); vb.position = Vector2(15, 15); vb.custom_minimum_size = Vector2(250, 330); vb.add_theme_constant_override("separation", 8); panel.add_child(vb)
		var nl = Label.new(); nl.text = GM.ARCH_NAMES[arch]; nl.add_theme_font_size_override("font_size", 22); nl.add_theme_color_override("font_color", GM.ARCH_COLORS[arch].lightened(0.4)); nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vb.add_child(nl)
		var desc_text: String
		match arch:
			"red_queen": desc_text = "Control & Shields\nDebuffs enemies\nNegate damage"
			"mad_hatter": desc_text = "Chaos & Mini-games\nMulti-hit attacks\nRandom effects"
			"march_hare": desc_text = "Speed & Card Draw\nShields + Draw combos\nNever run out of options"
		var dl = Label.new(); dl.text = desc_text; dl.add_theme_font_size_override("font_size", 13); dl.add_theme_color_override("font_color", Color(0.7, 0.7, 0.65)); vb.add_child(dl)
		var sp = Control.new(); sp.custom_minimum_size = Vector2(0, 10); vb.add_child(sp)
		# Preview cards
		var cards = GM.cards_by_arch(arch)
		var preview_count = mini(4, cards.size())
		for i in range(preview_count):
			var cd = GM.CARDS[cards[i]]
			var cl = Label.new(); cl.text = "• [%d] %s: %s" % [cd["cost"], cd["name"], cd["desc"]]
			cl.add_theme_font_size_override("font_size", 10); cl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.55)); cl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; cl.custom_minimum_size = Vector2(240, 0); vb.add_child(cl)
		var sp2 = Control.new(); sp2.custom_minimum_size = Vector2(0, 5); vb.add_child(sp2)
		var btn = Button.new(); btn.text = "Open %s Pack" % GM.ARCH_NAMES[arch]; btn.custom_minimum_size = Vector2(240, 40); btn.add_theme_font_size_override("font_size", 15)
		btn.pressed.connect(_on_pick_booster.bind(arch)); vb.add_child(btn)
		row.add_child(panel)

func _on_pick_booster(arch: String) -> void:
	var pool = GM.cards_by_arch(arch); pool.shuffle()
	current_booster_cards = pool.slice(0, mini(6, pool.size()))
	_build_card_pick_ui(arch)

func _build_card_pick_ui(arch: String) -> void:
	for c in get_children(): c.queue_free()
	var bg = ColorRect.new(); bg.color = Color(0.06, 0.05, 0.08); bg.set_anchors_preset(PRESET_FULL_RECT); add_child(bg)
	_l(self, "%s Pack — Pick 4 cards" % GM.ARCH_NAMES[arch], 24, GM.ARCH_COLORS[arch].lightened(0.3), Vector2(0, 20), 1280)
	_l(self, "Selected: %d / 4" % 0, 16, Color(0.6, 0.55, 0.5), Vector2(0, 52), 1280)
	var selected: Array = []
	var row = HBoxContainer.new(); row.position = Vector2(0, 90); row.custom_minimum_size = Vector2(1280, 300)
	row.alignment = BoxContainer.ALIGNMENT_CENTER; row.add_theme_constant_override("separation", 12); add_child(row)
	for i in range(current_booster_cards.size()):
		var cid = current_booster_cards[i]; var cd = GM.CARDS[cid]
		var panel = PanelContainer.new(); panel.custom_minimum_size = Vector2(180, 260)
		var cbg = ColorRect.new(); cbg.color = GM.ARCH_COLORS[cd["arch"]].darkened(0.3); cbg.custom_minimum_size = Vector2(180, 260); panel.add_child(cbg)
		var vb = VBoxContainer.new(); vb.position = Vector2(8, 8); vb.custom_minimum_size = Vector2(164, 240); vb.add_theme_constant_override("separation", 4); panel.add_child(vb)
		var nl = Label.new(); nl.text = "[%d] %s" % [cd["cost"], cd["name"]]; nl.add_theme_font_size_override("font_size", 15); vb.add_child(nl)
		var tl = Label.new(); tl.text = "%s • %s" % [cd["type"].to_upper(), cd["rarity"].to_upper()]; tl.add_theme_font_size_override("font_size", 10); tl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6)); vb.add_child(tl)
		var art = ColorRect.new(); art.color = GM.ARCH_COLORS[cd["arch"]].darkened(0.5); art.custom_minimum_size = Vector2(164, 60); vb.add_child(art)
		var dl = Label.new(); dl.text = cd["desc"]; dl.add_theme_font_size_override("font_size", 12); dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; dl.custom_minimum_size = Vector2(164, 50); vb.add_child(dl)
		var btn = Button.new(); btn.text = "Select"; btn.custom_minimum_size = Vector2(164, 30); btn.add_theme_font_size_override("font_size", 13)
		btn.pressed.connect(func():
			if cid not in selected and selected.size() < 4:
				selected.append(cid); btn.text = "✓ Selected"; btn.disabled = true
				# Update counter
				if selected.size() >= 4:
					# All picked, proceed
					for sid in selected: drafted_cards.append(sid)
					boosters_picked += 1
					if boosters_picked >= 3:
						GM.setup_starter_deck(drafted_cards)
					else:
						_build_choose_ui()
		)
		vb.add_child(btn)
		row.add_child(panel)

func _l(p: Node, t: String, sz: int, c: Color, pos: Vector2 = Vector2.ZERO, w: float = 0) -> void:
	var l = Label.new(); l.text = t; l.position = pos; l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	if w > 0: l.custom_minimum_size = Vector2(w, 0)
	l.add_theme_font_size_override("font_size", sz); l.add_theme_color_override("font_color", c); p.add_child(l)
