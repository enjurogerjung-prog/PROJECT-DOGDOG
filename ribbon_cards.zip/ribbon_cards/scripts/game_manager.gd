extends Node

# ============================================================
# RIBBON CARDS — Game Manager (Autoload)
# All card data, enemy data, act structure, and run state
# ============================================================

signal run_started
signal screen_change_requested(screen_name: String, data: Dictionary)

# === CARD DATABASE ===
var CARDS: Dictionary = {
	# --- Starter Cards ---
	"strike": {
		"name": "Strike", "cost": 1, "type": "attack", "target": "single",
		"desc": "Deal 6 damage.",
		"effects": [{"type": "damage", "value": 6}],
		"color": Color(0.7, 0.2, 0.2)
	},
	"guard": {
		"name": "Guard", "cost": 1, "type": "defend", "target": "self",
		"desc": "Gain 5 Block.",
		"effects": [{"type": "block", "value": 5}],
		"color": Color(0.2, 0.4, 0.7)
	},
	"thread_sense": {
		"name": "Thread Sense", "cost": 0, "type": "skill", "target": "self",
		"desc": "Draw 1 card.",
		"effects": [{"type": "draw", "value": 1}],
		"color": Color(0.2, 0.6, 0.3)
	},
	# --- Attack Cards ---
	"sever_thread": {
		"name": "Sever Thread", "cost": 1, "type": "attack", "target": "single",
		"desc": "Deal 9 damage.",
		"effects": [{"type": "damage", "value": 9}],
		"color": Color(0.7, 0.2, 0.2)
	},
	"unweave": {
		"name": "Unweave", "cost": 2, "type": "attack", "target": "single",
		"desc": "Deal 14 damage.",
		"effects": [{"type": "damage", "value": 14}],
		"color": Color(0.8, 0.15, 0.15)
	},
	"ribbon_lash": {
		"name": "Ribbon Lash", "cost": 1, "type": "attack", "target": "all",
		"desc": "Deal 4 damage to ALL.",
		"effects": [{"type": "damage", "value": 4}],
		"color": Color(0.8, 0.3, 0.2)
	},
	"venomous_thread": {
		"name": "Venomous Thread", "cost": 1, "type": "attack", "target": "single",
		"desc": "Deal 3 dmg. Apply 4 Poison.",
		"effects": [{"type": "damage", "value": 3}, {"type": "poison", "value": 4}],
		"color": Color(0.6, 0.3, 0.5)
	},
	"councils_fury": {
		"name": "Council's Fury", "cost": 3, "type": "attack", "target": "single",
		"desc": "Deal 24 damage.",
		"effects": [{"type": "damage", "value": 24}],
		"color": Color(0.9, 0.1, 0.1)
	},
	"fraying_cut": {
		"name": "Fraying Cut", "cost": 1, "type": "attack", "target": "single",
		"desc": "Deal 5 dmg. Apply 1 Vulnerable.",
		"effects": [{"type": "damage", "value": 5}, {"type": "vulnerable", "value": 1}],
		"color": Color(0.7, 0.25, 0.3)
	},
	"binding_slash": {
		"name": "Binding Slash", "cost": 1, "type": "attack", "target": "single",
		"desc": "Deal 6 dmg. Apply 1 Weak.",
		"effects": [{"type": "damage", "value": 6}, {"type": "weak", "value": 1}],
		"color": Color(0.65, 0.2, 0.35)
	},
	"thread_ripper": {
		"name": "Thread Ripper", "cost": 2, "type": "attack", "target": "single",
		"desc": "Deal 8 dmg twice.",
		"effects": [{"type": "damage", "value": 8}, {"type": "damage", "value": 8}],
		"color": Color(0.75, 0.15, 0.2)
	},
	# --- Defend Cards ---
	"weave_shield": {
		"name": "Weave Shield", "cost": 1, "type": "defend", "target": "self",
		"desc": "Gain 8 Block.",
		"effects": [{"type": "block", "value": 8}],
		"color": Color(0.2, 0.45, 0.75)
	},
	"thread_barrier": {
		"name": "Thread Barrier", "cost": 2, "type": "defend", "target": "self",
		"desc": "Gain 15 Block.",
		"effects": [{"type": "block", "value": 15}],
		"color": Color(0.2, 0.5, 0.8)
	},
	"silk_cocoon": {
		"name": "Silk Cocoon", "cost": 1, "type": "defend", "target": "self",
		"desc": "Gain 5 Block. Heal 3.",
		"effects": [{"type": "block", "value": 5}, {"type": "heal", "value": 3}],
		"color": Color(0.3, 0.5, 0.65)
	},
	"woven_ward": {
		"name": "Woven Ward", "cost": 1, "type": "defend", "target": "self",
		"desc": "Gain 6 Block. Gain 1 Str.",
		"effects": [{"type": "block", "value": 6}, {"type": "strength", "value": 1}],
		"color": Color(0.3, 0.4, 0.7)
	},
	# --- Skill Cards ---
	"expose_threads": {
		"name": "Expose Threads", "cost": 1, "type": "skill", "target": "single",
		"desc": "Apply 2 Vulnerable.",
		"effects": [{"type": "vulnerable", "value": 2}],
		"color": Color(0.2, 0.6, 0.3)
	},
	"suppress": {
		"name": "Suppress", "cost": 1, "type": "skill", "target": "single",
		"desc": "Apply 2 Weak.",
		"effects": [{"type": "weak", "value": 2}],
		"color": Color(0.3, 0.55, 0.3)
	},
	"gather_threads": {
		"name": "Gather Threads", "cost": 1, "type": "skill", "target": "self",
		"desc": "Draw 3 cards.",
		"effects": [{"type": "draw", "value": 3}],
		"color": Color(0.2, 0.65, 0.4)
	},
	"venom_cloud": {
		"name": "Venom Cloud", "cost": 2, "type": "skill", "target": "all",
		"desc": "Apply 4 Poison to ALL.",
		"effects": [{"type": "poison", "value": 4}],
		"color": Color(0.4, 0.55, 0.2)
	},
	"strengthen_weave": {
		"name": "Strengthen Weave", "cost": 1, "type": "skill", "target": "self",
		"desc": "Gain 2 Strength.",
		"effects": [{"type": "strength", "value": 2}],
		"color": Color(0.5, 0.5, 0.2)
	},
	"ribbon_meditation": {
		"name": "Ribbon Meditation", "cost": 0, "type": "skill", "target": "self",
		"desc": "Gain 1 Energy.",
		"effects": [{"type": "energy", "value": 1}],
		"color": Color(0.4, 0.6, 0.5)
	},
	"blood_unraveling": {
		"name": "Blood Unraveling", "cost": 0, "type": "skill", "target": "self",
		"desc": "Lose 3 HP. Draw 2 cards.",
		"effects": [{"type": "self_damage", "value": 3}, {"type": "draw", "value": 2}],
		"color": Color(0.5, 0.2, 0.4)
	},
	"dark_pact": {
		"name": "Dark Pact", "cost": 1, "type": "skill", "target": "self",
		"desc": "Lose 5 HP. Gain 3 Str.",
		"effects": [{"type": "self_damage", "value": 5}, {"type": "strength", "value": 3}],
		"color": Color(0.45, 0.15, 0.45)
	},
}

# === ENEMY DATABASE ===
var ENEMIES: Dictionary = {
	# --- Act 1: The Fraying ---
	"frayed_hound": {
		"name": "Frayed Hound", "min_hp": 14, "max_hp": 18,
		"intents": [
			{"type": "attack", "value": 6},
			{"type": "attack", "value": 9},
		]
	},
	"hollow_acolyte": {
		"name": "Hollow Acolyte", "min_hp": 20, "max_hp": 26,
		"intents": [
			{"type": "attack", "value": 5},
			{"type": "defend", "value": 6},
			{"type": "attack", "value": 8},
		]
	},
	"threadbare_shade": {
		"name": "Threadbare Shade", "min_hp": 12, "max_hp": 16,
		"intents": [
			{"type": "debuff_poison", "value": 3},
			{"type": "attack", "value": 4},
			{"type": "debuff_poison", "value": 5},
		]
	},
	"council_inquisitor": {
		"name": "Council Inquisitor", "min_hp": 55, "max_hp": 65,
		"intents": [
			{"type": "attack", "value": 8},
			{"type": "defend", "value": 10},
			{"type": "attack", "value": 12},
			{"type": "buff_strength", "value": 2},
			{"type": "attack", "value": 14},
		]
	},
	# --- Act 2: The Weaving ---
	"silken_wraith": {
		"name": "Silken Wraith", "min_hp": 22, "max_hp": 30,
		"intents": [
			{"type": "defend", "value": 8},
			{"type": "attack", "value": 10},
			{"type": "debuff_weak", "value": 2},
		]
	},
	"bone_weaver": {
		"name": "Bone Weaver", "min_hp": 24, "max_hp": 32,
		"intents": [
			{"type": "buff_strength", "value": 2},
			{"type": "attack", "value": 7},
			{"type": "attack", "value": 11},
		]
	},
	"loom_spider": {
		"name": "Loom Spider", "min_hp": 18, "max_hp": 24,
		"intents": [
			{"type": "debuff_poison", "value": 4},
			{"type": "attack", "value": 6},
			{"type": "attack", "value": 9},
		]
	},
	"the_unraveler": {
		"name": "The Unraveler", "min_hp": 80, "max_hp": 90,
		"intents": [
			{"type": "attack", "value": 10},
			{"type": "debuff_vulnerable", "value": 2},
			{"type": "attack", "value": 15},
			{"type": "defend", "value": 12},
			{"type": "debuff_weak", "value": 2},
			{"type": "attack", "value": 20},
		]
	},
	# --- Act 3: The Binding ---
	"council_enforcer": {
		"name": "Council Enforcer", "min_hp": 32, "max_hp": 42,
		"intents": [
			{"type": "attack", "value": 12},
			{"type": "defend", "value": 10},
			{"type": "attack", "value": 16},
		]
	},
	"void_singer": {
		"name": "Void Singer", "min_hp": 28, "max_hp": 36,
		"intents": [
			{"type": "debuff_weak", "value": 2},
			{"type": "debuff_vulnerable", "value": 2},
			{"type": "attack", "value": 10},
			{"type": "debuff_poison", "value": 6},
		]
	},
	"ribbon_golem": {
		"name": "Ribbon Golem", "min_hp": 38, "max_hp": 48,
		"intents": [
			{"type": "defend", "value": 12},
			{"type": "attack", "value": 14},
			{"type": "buff_strength", "value": 3},
			{"type": "attack", "value": 18},
		]
	},
	"the_grand_weaver": {
		"name": "The Grand Weaver", "min_hp": 100, "max_hp": 120,
		"intents": [
			{"type": "buff_strength", "value": 2},
			{"type": "attack", "value": 12},
			{"type": "debuff_vulnerable", "value": 2},
			{"type": "attack", "value": 18},
			{"type": "defend", "value": 15},
			{"type": "debuff_poison", "value": 8},
			{"type": "attack", "value": 25},
		]
	},
}

# === ACT STRUCTURE ===
# Each act has a pool of encounter groups and a boss
var ACTS: Array = [
	{
		"name": "Act I — The Fraying",
		"desc": "The outer territories unravel. The Council's grip loosens at the edges.",
		"encounter_pool": [
			{"enemies": ["frayed_hound"], "label": "Lone Hound"},
			{"enemies": ["frayed_hound", "frayed_hound"], "label": "Hound Pack"},
			{"enemies": ["hollow_acolyte"], "label": "Fallen Acolyte"},
			{"enemies": ["threadbare_shade", "frayed_hound"], "label": "Shade & Hound"},
			{"enemies": ["threadbare_shade"], "label": "Lurking Shade"},
			{"enemies": ["hollow_acolyte", "threadbare_shade"], "label": "Corrupted Pair"},
		],
		"boss": {"enemies": ["council_inquisitor"], "label": "BOSS: Council Inquisitor"},
		"card_pool": ["sever_thread", "ribbon_lash", "venomous_thread", "fraying_cut",
					  "binding_slash", "weave_shield", "silk_cocoon", "expose_threads",
					  "suppress", "gather_threads", "ribbon_meditation", "blood_unraveling"],
	},
	{
		"name": "Act II — The Weaving",
		"desc": "Deeper into Council territory. The threads grow thick and hostile.",
		"encounter_pool": [
			{"enemies": ["silken_wraith"], "label": "Silken Wraith"},
			{"enemies": ["bone_weaver"], "label": "Bone Weaver"},
			{"enemies": ["loom_spider", "loom_spider"], "label": "Spider Nest"},
			{"enemies": ["silken_wraith", "loom_spider"], "label": "Wraith & Spider"},
			{"enemies": ["bone_weaver", "silken_wraith"], "label": "Woven Ambush"},
			{"enemies": ["loom_spider", "bone_weaver", "loom_spider"], "label": "Weaver's Den"},
		],
		"boss": {"enemies": ["the_unraveler"], "label": "BOSS: The Unraveler"},
		"card_pool": ["unweave", "councils_fury", "thread_ripper", "thread_barrier",
					  "woven_ward", "venom_cloud", "strengthen_weave", "dark_pact",
					  "sever_thread", "venomous_thread", "gather_threads", "expose_threads"],
	},
	{
		"name": "Act III — The Binding",
		"desc": "The Council's inner sanctum. Every thread is a weapon.",
		"encounter_pool": [
			{"enemies": ["council_enforcer"], "label": "Council Enforcer"},
			{"enemies": ["void_singer"], "label": "Void Singer"},
			{"enemies": ["ribbon_golem"], "label": "Ribbon Golem"},
			{"enemies": ["council_enforcer", "void_singer"], "label": "Council Guard"},
			{"enemies": ["ribbon_golem", "void_singer"], "label": "Golem & Singer"},
			{"enemies": ["council_enforcer", "ribbon_golem"], "label": "Heavy Patrol"},
		],
		"boss": {"enemies": ["the_grand_weaver"], "label": "BOSS: The Grand Weaver"},
		"card_pool": ["councils_fury", "thread_ripper", "unweave", "thread_barrier",
					  "woven_ward", "venom_cloud", "strengthen_weave", "dark_pact",
					  "gather_threads", "ribbon_meditation", "blood_unraveling", "silk_cocoon"],
	},
]

# === RUN STATE ===
var player_hp: int = 70
var player_max_hp: int = 70
var deck: Array = []  # Array of card IDs (strings)
var current_act: int = 0  # 0-indexed
var current_fight: int = 0  # 0-2 fights per act, then boss
var run_active: bool = false

# Map nodes for current act — each node has two encounter choices
var map_nodes: Array = []

# === STARTER DECK ===
var STARTER_DECK: Array = [
	"strike", "strike", "strike", "strike", "strike",
	"guard", "guard", "guard", "guard",
	"thread_sense",
]

# === METHODS ===

func start_new_run() -> void:
	player_hp = player_max_hp
	deck = STARTER_DECK.duplicate()
	current_act = 0
	current_fight = 0
	run_active = true
	_generate_map_for_act()
	run_started.emit()
	screen_change_requested.emit("map", {})

func _generate_map_for_act() -> void:
	map_nodes.clear()
	var act_data = ACTS[current_act]
	var pool = act_data["encounter_pool"].duplicate()
	pool.shuffle()
	
	# Generate 3 fight nodes, each with 2 choices
	for i in range(3):
		var choice_a = pool[i * 2 % pool.size()]
		var choice_b = pool[(i * 2 + 1) % pool.size()]
		# Make sure choices are different
		if choice_a == choice_b and pool.size() > 1:
			choice_b = pool[(i * 2 + 2) % pool.size()]
		map_nodes.append({"choice_a": choice_a, "choice_b": choice_b})

func get_current_map_node() -> Dictionary:
	if current_fight < map_nodes.size():
		return map_nodes[current_fight]
	return {}

func get_boss_encounter() -> Dictionary:
	return ACTS[current_act]["boss"]

func is_boss_fight() -> bool:
	# Called AFTER advance_fight(), so current_fight > 3 means boss was just beaten
	return current_fight > 3

func advance_fight() -> void:
	current_fight += 1

func advance_act() -> bool:
	current_act += 1
	current_fight = 0
	if current_act >= ACTS.size():
		return false  # Game won!
	_generate_map_for_act()
	return true

func get_reward_cards(count: int = 3) -> Array:
	var pool = ACTS[current_act]["card_pool"].duplicate()
	# Remove cards already heavily in deck
	pool.shuffle()
	var result: Array = []
	for card_id in pool:
		if card_id not in result:
			result.append(card_id)
		if result.size() >= count:
			break
	return result

func add_card_to_deck(card_id: String) -> void:
	deck.append(card_id)

func remove_card_from_deck(index: int) -> void:
	if index >= 0 and index < deck.size():
		deck.remove_at(index)

func heal_player(amount: int) -> void:
	player_hp = mini(player_hp + amount, player_max_hp)

func damage_player(amount: int) -> void:
	player_hp = maxi(player_hp - amount, 0)

func get_intent_text(intent: Dictionary) -> String:
	match intent["type"]:
		"attack":
			return "ATK " + str(intent["value"])
		"defend":
			return "DEF " + str(intent["value"])
		"buff_strength":
			return "BUFF +%d Str" % intent["value"]
		"debuff_poison":
			return "PSN %d" % intent["value"]
		"debuff_weak":
			return "WEAK %d" % intent["value"]
		"debuff_vulnerable":
			return "VULN %d" % intent["value"]
	return "???"

func get_intent_color(intent: Dictionary) -> Color:
	match intent["type"]:
		"attack":
			return Color(1.0, 0.3, 0.3)
		"defend":
			return Color(0.3, 0.5, 1.0)
		"buff_strength":
			return Color(1.0, 0.8, 0.2)
		"debuff_poison":
			return Color(0.3, 0.8, 0.3)
		"debuff_weak", "debuff_vulnerable":
			return Color(0.8, 0.4, 0.8)
	return Color.WHITE
