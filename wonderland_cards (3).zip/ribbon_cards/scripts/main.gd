extends Control

var current_screen: Control = null
var scripts_map: Dictionary = {}

func _ready() -> void:
	scripts_map = {
		"menu": preload("res://scripts/main_menu.gd"),
		"draft": preload("res://scripts/draft_screen.gd"),
		"map": preload("res://scripts/map_screen.gd"),
		"combat": preload("res://scripts/combat_screen.gd"),
		"shop": preload("res://scripts/shop_screen.gd"),
		"deck_manager": preload("res://scripts/deck_screen.gd"),
		"booster_open": preload("res://scripts/booster_screen.gd"),
		"round_summary": preload("res://scripts/round_summary.gd"),
		"rest": preload("res://scripts/rest_screen.gd"),
		"event": preload("res://scripts/event_screen.gd"),
		"treasure": preload("res://scripts/treasure_screen.gd"),
		"game_over": preload("res://scripts/game_over_screen.gd"),
	}
	GM.screen_change.connect(_on_change)
	_show("menu", {})

func _show(scr_name: String, data: Dictionary) -> void:
	if current_screen: current_screen.queue_free(); current_screen = null
	await get_tree().process_frame
	if scripts_map.has(scr_name):
		var s = Control.new()
		s.set_script(scripts_map[scr_name])
		for k in data: s.set_meta(k, data[k])
		s.set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(s); current_screen = s

func _on_change(scr_name: String, data: Dictionary) -> void: _show(scr_name, data)
