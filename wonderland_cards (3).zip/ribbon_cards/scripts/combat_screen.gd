extends Control

var energy: int = 3; var max_energy: int = 3; var block: int = 0
var statuses := {"poison": 0, "strength": 0, "weak": 0, "vulnerable": 0}
var draw_pile: Array = []; var hand: Array = []; var discard_pile: Array = []
var enemies: Array = []; var selected_card: int = -1
var combat_over := false; var player_turn := true; var turn_num := 0
var is_boss := false; var is_elite := false
var cards_by_arch := {"red_queen": 0, "mad_hatter": 0, "march_hare": 0, "neutral": 0}
var synergies_done: Array = []
# Powers
var power_draw: int = 0; var power_str_per_turn: int = 0; var synergy_reduction: int = 0

var hand_box: HBoxContainer; var enemy_box: HBoxContainer
var energy_lbl: Label; var hp_lbl: Label; var block_lbl: Label; var stat_lbl: Label
var turn_lbl: Label; var gold_lbl: Label; var syn_lbl: RichTextLabel
var draw_lbl: Label; var disc_lbl: Label; var end_btn: Button; var log_box: RichTextLabel

func _ready() -> void:
	var enc = get_meta("encounter") if has_meta("encounter") else {}
	is_boss = get_meta("is_boss") if has_meta("is_boss") else false
	is_elite = get_meta("is_elite") if has_meta("is_elite") else false
	_init(enc); _build_ui(); _start_turn()

func _init(enc: Dictionary) -> void:
	GM.reset_powers()
	max_energy = GM.MAX_ENERGY + GM.energy_bonus; energy = max_energy
	block = 0; statuses = {"poison": 0, "strength": 0, "weak": 0, "vulnerable": 0}
	turn_num = 0; power_draw = 0; power_str_per_turn = 0; synergy_reduction = GM.synergy_mod
	draw_pile = GM.deck.duplicate(true); draw_pile.shuffle()
	hand.clear(); discard_pile.clear()
	# Relic bonuses
	for rid in GM.relics:
		var r = GM.RELICS[rid]
		if r["effect"] == "start_str": statuses["strength"] += r["value"]
		elif r["effect"] == "start_block": block += r["value"]
	enemies.clear()
	var scale = GM.scaling()
	for eid in enc.get("enemies", ["card_soldier"]):
		var ed = GM.ENEMIES[eid]
		var ehp = int(randi_range(ed["min_hp"], ed["max_hp"]) * scale)
		enemies.append({"id": eid, "name": ed["name"], "arch": ed.get("arch", "neutral"),
			"hp": ehp, "max_hp": ehp, "block": 0, "intents": ed["intents"],
			"intent_idx": randi() % ed["intents"].size(),
			"statuses": {"poison": 0, "strength": 0, "weak": 0, "vulnerable": 0}})

func _build_ui() -> void:
	var bg = ColorRect.new(); bg.color = Color(0.05, 0.04, 0.07); bg.set_anchors_preset(PRESET_FULL_RECT); add_child(bg)
	var top = HBoxContainer.new(); top.position = Vector2(12, 6); top.add_theme_constant_override("separation", 15); add_child(top)
	hp_lbl = _mk_lbl(top, "", 17, Color(0.8, 0.3, 0.3))
	block_lbl = _mk_lbl(top, "", 17, Color(0.3, 0.6, 0.9))
	energy_lbl = _mk_lbl(top, "", 17, Color(0.9, 0.8, 0.3))
	stat_lbl = _mk_lbl(top, "", 13, Color(0.7, 0.6, 0.8))
	turn_lbl = Label.new(); turn_lbl.position = Vector2(1120, 6); turn_lbl.add_theme_font_size_override("font_size", 20)
	turn_lbl.add_theme_color_override("font_color", Color(0.9, 0.75, 0.3)); add_child(turn_lbl)
	gold_lbl = Label.new(); gold_lbl.position = Vector2(1120, 30); gold_lbl.add_theme_font_size_override("font_size", 12)
	gold_lbl.add_theme_color_override("font_color", Color(0.6, 0.55, 0.3)); add_child(gold_lbl)
	syn_lbl = RichTextLabel.new(); syn_lbl.position = Vector2(12, 30); syn_lbl.custom_minimum_size = Vector2(500, 18)
	syn_lbl.size = Vector2(500, 18); syn_lbl.bbcode_enabled = true; syn_lbl.fit_content = true
	syn_lbl.add_theme_font_size_override("normal_font_size", 11); add_child(syn_lbl)
	draw_lbl = Label.new(); draw_lbl.position = Vector2(12, 690); draw_lbl.add_theme_font_size_override("font_size", 12)
	draw_lbl.add_theme_color_override("font_color", Color(0.45, 0.45, 0.55)); add_child(draw_lbl)
	disc_lbl = Label.new(); disc_lbl.position = Vector2(130, 690); disc_lbl.add_theme_font_size_override("font_size", 12)
	disc_lbl.add_theme_color_override("font_color", Color(0.45, 0.45, 0.55)); add_child(disc_lbl)
	enemy_box = HBoxContainer.new(); enemy_box.position = Vector2(0, 55); enemy_box.custom_minimum_size = Vector2(1280, 220)
	enemy_box.alignment = BoxContainer.ALIGNMENT_CENTER; enemy_box.add_theme_constant_override("separation", 15); add_child(enemy_box)
	_build_enemies()
	hand_box = HBoxContainer.new(); hand_box.position = Vector2(0, 490); hand_box.custom_minimum_size = Vector2(1280, 190)
	hand_box.alignment = BoxContainer.ALIGNMENT_CENTER; hand_box.add_theme_constant_override("separation", 4); add_child(hand_box)
	end_btn = Button.new(); end_btn.text = "END TURN"; end_btn.position = Vector2(1140, 495)
	end_btn.custom_minimum_size = Vector2(110, 38); end_btn.add_theme_font_size_override("font_size", 14)
	end_btn.pressed.connect(_end_turn); add_child(end_btn)
	log_box = RichTextLabel.new(); log_box.position = Vector2(850, 360); log_box.size = Vector2(410, 120)
	log_box.custom_minimum_size = Vector2(410, 120); log_box.bbcode_enabled = true
	log_box.add_theme_font_size_override("normal_font_size", 10); log_box.scroll_following = true; add_child(log_box)
	_update_ui()

func _build_enemies() -> void:
	for c in enemy_box.get_children(): c.queue_free()
	for i in range(enemies.size()):
		var e = enemies[i]; var ac = GM.ARCH_COLORS.get(e["arch"], Color.GRAY)
		var p = PanelContainer.new(); p.custom_minimum_size = Vector2(190, 210)
		var pbg = ColorRect.new(); pbg.name = "BG"; pbg.color = Color(0.11, 0.09, 0.13); pbg.custom_minimum_size = Vector2(190, 210); p.add_child(pbg)
		var st = ColorRect.new(); st.color = ac; st.custom_minimum_size = Vector2(190, 3); pbg.add_child(st)
		var vb = VBoxContainer.new(); vb.name = "VB"; vb.position = Vector2(6, 6); vb.custom_minimum_size = Vector2(178, 198); vb.add_theme_constant_override("separation", 2); p.add_child(vb)
		var nl = Label.new(); nl.name = "Name"; nl.text = e["name"]; nl.add_theme_font_size_override("font_size", 13)
		nl.add_theme_color_override("font_color", ac.lightened(0.4)); nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vb.add_child(nl)
		var hbg = ColorRect.new(); hbg.name = "HPBg"; hbg.color = Color(0.2, 0.1, 0.1); hbg.custom_minimum_size = Vector2(178, 16); vb.add_child(hbg)
		var hb = ColorRect.new(); hb.name = "HPBar"; hb.color = Color(0.7, 0.2, 0.2); hb.custom_minimum_size = Vector2(178, 16); hbg.add_child(hb)
		var ht = Label.new(); ht.name = "HPTxt"; ht.add_theme_font_size_override("font_size", 11); ht.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; ht.custom_minimum_size = Vector2(178, 16); hbg.add_child(ht)
		var bl = Label.new(); bl.name = "Blk"; bl.add_theme_font_size_override("font_size", 12); bl.add_theme_color_override("font_color", Color(0.3, 0.6, 0.9)); bl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vb.add_child(bl)
		var sl = Label.new(); sl.name = "Sts"; sl.add_theme_font_size_override("font_size", 10); sl.add_theme_color_override("font_color", Color(0.7, 0.5, 0.8)); sl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vb.add_child(sl)
		var intent = e["intents"][e["intent_idx"]]; var ic = GM.get_intent_color(intent)
		var ibg = ColorRect.new(); ibg.name = "IBg"; ibg.color = ic * 0.25; ibg.custom_minimum_size = Vector2(178, 26); vb.add_child(ibg)
		var il = Label.new(); il.name = "Intent"; il.text = "» " + GM.get_intent_text(intent); il.add_theme_font_size_override("font_size", 12)
		il.add_theme_color_override("font_color", ic); il.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; il.custom_minimum_size = Vector2(178, 26); ibg.add_child(il)
		var body = ColorRect.new(); body.color = ac.darkened(0.7); body.custom_minimum_size = Vector2(178, 50); vb.add_child(body)
		var skull = Label.new(); skull.text = "👑" if is_boss else ("💀" if is_elite else "⚔")
		skull.add_theme_font_size_override("font_size", 28); skull.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; skull.custom_minimum_size = Vector2(178, 50); body.add_child(skull)
		var btn = Button.new(); btn.flat = true; btn.set_anchors_preset(PRESET_FULL_RECT); btn.custom_minimum_size = Vector2(190, 210)
		btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND; btn.pressed.connect(_on_enemy.bind(i)); p.add_child(btn)
		enemy_box.add_child(p)

func _mk_card(entry: Dictionary, idx: int) -> PanelContainer:
	var cd = GM.card_at_tier(entry["id"], entry["tier"]); var ac = GM.get_arch_color(entry["id"])
	var tc = GM.TIER_COLORS.get(entry["tier"], Color.GRAY)
	var p = PanelContainer.new(); p.custom_minimum_size = Vector2(125, 180)
	var cbg = ColorRect.new(); cbg.name = "CardBG"; cbg.color = ac.darkened(0.2); cbg.custom_minimum_size = Vector2(125, 180); p.add_child(cbg)
	if entry["tier"] != GM.TIER_BRONZE:
		var ts = ColorRect.new(); ts.color = tc; ts.custom_minimum_size = Vector2(125, 3); cbg.add_child(ts)
	var vb = VBoxContainer.new(); vb.position = Vector2(5, 4); vb.custom_minimum_size = Vector2(115, 170); vb.add_theme_constant_override("separation", 1); p.add_child(vb)
	var tr = HBoxContainer.new(); vb.add_child(tr)
	var cb = ColorRect.new(); cb.color = Color(0.1, 0.08, 0.06); cb.custom_minimum_size = Vector2(22, 22); tr.add_child(cb)
	var cl = Label.new(); cl.text = str(cd["cost"]); cl.add_theme_font_size_override("font_size", 14); cl.add_theme_color_override("font_color", Color(0.9, 0.8, 0.3))
	cl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; cl.custom_minimum_size = Vector2(22, 22); cb.add_child(cl)
	var nl = Label.new(); nl.text = " " + GM.TIER_PREFIX.get(entry["tier"], "") + cd["name"]; nl.add_theme_font_size_override("font_size", 10)
	if entry["tier"] != GM.TIER_BRONZE: nl.add_theme_color_override("font_color", tc)
	tr.add_child(nl)
	var tl = Label.new(); tl.text = cd["type"].to_upper(); tl.add_theme_font_size_override("font_size", 8); tl.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5)); vb.add_child(tl)
	var art = ColorRect.new(); art.color = ac.darkened(0.45); art.custom_minimum_size = Vector2(115, 48); vb.add_child(art)
	var dl = Label.new(); dl.text = cd["desc"]; dl.add_theme_font_size_override("font_size", 10); dl.add_theme_color_override("font_color", Color(0.88, 0.88, 0.84))
	dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; dl.custom_minimum_size = Vector2(115, 50); vb.add_child(dl)
	var btn = Button.new(); btn.flat = true; btn.set_anchors_preset(PRESET_FULL_RECT); btn.custom_minimum_size = Vector2(125, 180)
	btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND; btn.pressed.connect(_on_card.bind(idx)); p.add_child(btn)
	return p

func _start_turn() -> void:
	if combat_over: return
	player_turn = true; turn_num += 1; energy = max_energy; block = 0
	cards_by_arch = {"red_queen": 0, "mad_hatter": 0, "march_hare": 0, "neutral": 0}; synergies_done.clear()
	# Power: strength per turn
	if power_str_per_turn > 0:
		statuses["strength"] += power_str_per_turn
		_log("[color=yellow]Power: +%d Str[/color]" % power_str_per_turn)
	# Tick poison
	if statuses["poison"] > 0:
		GM.damage(statuses["poison"]); _log("[color=green]Poison: -%d[/color]" % statuses["poison"])
		statuses["poison"] = maxi(statuses["poison"] - 1, 0)
		if GM.hp <= 0: _end_combat(false); return
	statuses["weak"] = maxi(statuses["weak"] - 1, 0); statuses["vulnerable"] = maxi(statuses["vulnerable"] - 1, 0)
	var draw_count = GM.HAND_SIZE + GM.hand_bonus + power_draw
	_draw_cards(draw_count); _rebuild_hand(); _update_ui(); end_btn.disabled = false

func _end_turn() -> void:
	if not player_turn or combat_over: return
	player_turn = false; end_btn.disabled = true; selected_card = -1
	for c in hand: discard_pile.append(c)
	hand.clear(); _rebuild_hand()
	await _enemy_turns()
	if GM.hp <= 0: _end_combat(false); return
	_start_turn()

func _enemy_turns() -> void:
	for i in range(enemies.size()):
		if combat_over: return
		var e = enemies[i]
		if e["hp"] <= 0: continue
		e["block"] = 0
		if e["statuses"]["poison"] > 0:
			e["hp"] -= e["statuses"]["poison"]; _log("[color=green]%s: -%d psn[/color]" % [e["name"], e["statuses"]["poison"]])
			e["statuses"]["poison"] = maxi(e["statuses"]["poison"] - 1, 0)
			if e["hp"] <= 0: _log("[color=yellow]%s destroyed![/color]" % e["name"]); _check_win(); continue
		e["statuses"]["weak"] = maxi(e["statuses"]["weak"] - 1, 0); e["statuses"]["vulnerable"] = maxi(e["statuses"]["vulnerable"] - 1, 0)
		var intent = e["intents"][e["intent_idx"]]; var val = int(intent["value"] * GM.scaling()) if GM.infinite_cycle > 0 else intent["value"]
		_do_intent(e, intent["type"], val)
		e["intent_idx"] = (e["intent_idx"] + 1) % e["intents"].size()
		_update_ui(); await get_tree().create_timer(0.2).timeout

func _do_intent(e: Dictionary, itype: String, val: int) -> void:
	match itype:
		"attack", "lifesteal_attack":
			var atk = val + e["statuses"]["strength"]
			if e["statuses"]["weak"] > 0: atk = int(atk * 0.75)
			if statuses["vulnerable"] > 0: atk = int(atk * 1.5)
			var actual = _dmg_player(maxi(atk, 0)); _log("%s: %d dmg" % [e["name"], actual])
			if itype == "lifesteal_attack": e["hp"] = mini(e["hp"] + actual, e["max_hp"])
		"defend": e["block"] += val; _log("%s: +%d blk" % [e["name"], val])
		"buff_strength": e["statuses"]["strength"] += val; _log("%s: +%d str" % [e["name"], val])
		"debuff_poison": statuses["poison"] += val; _log("[color=green]%s: psn %d[/color]" % [e["name"], val])
		"debuff_weak": statuses["weak"] += val; _log("[color=purple]%s: weak %d[/color]" % [e["name"], val])
		"debuff_vulnerable": statuses["vulnerable"] += val; _log("[color=purple]%s: vuln %d[/color]" % [e["name"], val])

func _dmg_player(amt: int) -> int:
	var rem = amt
	if block > 0:
		if block >= rem: block -= rem; return 0
		rem -= block; block = 0
	GM.damage(rem); return rem

# === CARD PLAYING ===
func _on_card(idx: int) -> void:
	if not player_turn or combat_over or idx < 0 or idx >= hand.size(): return
	var entry = hand[idx]; var cd = GM.card_at_tier(entry["id"], entry["tier"])
	if cd["cost"] > energy: _log("[color=red]No energy![/color]"); return
	if cd.get("target", "self") == "single":
		selected_card = idx if selected_card != idx else -1; _rebuild_hand(); return
	_play(idx, -1)

func _on_enemy(eidx: int) -> void:
	if not player_turn or combat_over or selected_card < 0: return
	if eidx < 0 or eidx >= enemies.size() or enemies[eidx]["hp"] <= 0: return
	_play(selected_card, eidx)

func _play(hidx: int, target: int) -> void:
	var entry = hand[hidx]; var cd = GM.card_at_tier(entry["id"], entry["tier"])
	energy -= cd["cost"]; var arch = cd.get("arch", "neutral")
	# Check for minigame effects
	var has_minigame := false
	for fx in cd["effects"]:
		if fx["t"] == "minigame":
			has_minigame = true
			await _play_minigame(fx.get("game", "roulette"), target, cd)
			break
	if not has_minigame:
		for fx in cd["effects"]: _apply(fx, target, cd.get("target", "self"), arch)
	# Powers
	if cd["type"] == "power":
		for fx in cd["effects"]:
			match fx["t"]:
				"power_draw": power_draw += fx["v"]; _log("[color=yellow]POWER: +%d draw/turn[/color]" % fx["v"])
				"power_strength": power_str_per_turn += fx["v"]; _log("[color=yellow]POWER: +%d str/turn[/color]" % fx["v"])
				"power_synergy": synergy_reduction += abs(fx["v"]); _log("[color=yellow]POWER: synergy -%d[/color]" % abs(fx["v"]))
	# Synergy
	cards_by_arch[arch] = cards_by_arch.get(arch, 0) + 1; _check_synergy(arch)
	_log("Played %s%s" % [GM.TIER_PREFIX.get(entry["tier"], ""), cd["name"]])
	hand.remove_at(hidx); discard_pile.append(entry); selected_card = -1
	_check_win(); _rebuild_hand(); _update_ui()

func _play_minigame(game_type: String, target: int, cd: Dictionary) -> void:
	var mg = MiniGame.create(self, game_type)
	var result = await mg.game_finished
	# Apply result
	var base_dmg = 10; var max_dmg = 20
	match game_type:
		"roulette":
			if result >= 0.9: _apply({"t": "damage", "v": 15}, target, "single", ""); _apply({"t": "block", "v": 8}, -1, "self", "")
			elif result >= 0.7: _apply({"t": "damage", "v": 10}, target, "single", ""); _apply({"t": "draw", "v": 2}, -1, "self", "")
			elif result >= 0.4: _apply({"t": "damage", "v": 6}, target, "single", "")
			else: GM.damage(3); _log("[color=red]Oops! -3 HP[/color]")
		"reflex":
			var dmg = int(lerpf(5, 15, result))
			_apply({"t": "damage", "v": dmg}, target, "single", "")
		"watch":
			var dmg = int(lerpf(8, 24, result))
			_apply({"t": "damage", "v": dmg}, target, "single", "")
		"shuffle":
			if result > 0.5: _apply({"t": "damage", "v": 12}, target, "single", ""); _apply({"t": "draw", "v": 2}, -1, "self", "")
			else: _apply({"t": "damage", "v": 4}, target, "single", "")
		"mushroom":
			var dmg = int(lerpf(2, 18, result))
			_apply({"t": "damage", "v": dmg}, target, "single", "")

func _check_synergy(arch: String) -> void:
	var thresh = maxi(GM.SYNERGY_THRESHOLD - synergy_reduction, 1)
	if cards_by_arch.get(arch, 0) == thresh and arch not in synergies_done:
		synergies_done.append(arch)
		match arch:
			"red_queen": block += 6; _log("[color=red]♠ Queen Synergy: +6 Block[/color]")
			"mad_hatter":
				for i in range(enemies.size()):
					if enemies[i]["hp"] > 0: _dmg_enemy(i, 3)
				var debuffs = ["poison", "weak", "vulnerable"]; var d = debuffs[randi() % 3]
				for i in range(enemies.size()):
					if enemies[i]["hp"] > 0: enemies[i]["statuses"][d] += 1
				_log("[color=purple]🎩 Hatter Synergy: 3 dmg ALL + %s[/color]" % d)
			"march_hare": _draw_cards(2); _log("[color=green]🐰 Hare Synergy: Draw 2[/color]")
			"neutral": energy += 1; _log("[color=gray]✦ Neutral Synergy: +1 Energy[/color]")

func _apply(fx: Dictionary, target: int, ttype: String, arch: String) -> void:
	var v = fx["v"]
	match fx["t"]:
		"damage":
			var atk = v + statuses["strength"]
			if statuses["weak"] > 0: atk = int(atk * 0.75)
			if ttype == "all":
				for i in range(enemies.size()):
					if enemies[i]["hp"] > 0:
						var a = atk; if enemies[i]["statuses"]["vulnerable"] > 0: a = int(a * 1.5)
						_dmg_enemy(i, maxi(a, 0))
			elif target >= 0:
				var a = atk; if enemies[target]["statuses"]["vulnerable"] > 0: a = int(a * 1.5)
				_dmg_enemy(target, maxi(a, 0))
		"block": block += v
		"heal": GM.heal(v)
		"draw": _draw_cards(v)
		"energy": energy += v
		"self_damage": GM.damage(v)
		"strength": statuses["strength"] += v
		"cleanse": statuses["poison"] = 0; statuses["weak"] = 0; statuses["vulnerable"] = 0
		"poison":
			if ttype == "all": for i in range(enemies.size()): if enemies[i]["hp"] > 0: enemies[i]["statuses"]["poison"] += v
			elif target >= 0: enemies[target]["statuses"]["poison"] += v
		"weak":
			if target >= 0: enemies[target]["statuses"]["weak"] += v
		"weak_all":
			for i in range(enemies.size()): if enemies[i]["hp"] > 0: enemies[i]["statuses"]["weak"] += v
		"vulnerable":
			if target >= 0: enemies[target]["statuses"]["vulnerable"] += v
		"random_debuff":
			if target >= 0:
				var opts = ["poison", "weak", "vulnerable"]; enemies[target]["statuses"][opts[randi() % 3]] += v

func _dmg_enemy(idx: int, amt: int) -> void:
	var e = enemies[idx]; var rem = amt
	if e["block"] > 0:
		if e["block"] >= rem: e["block"] -= rem; return
		rem -= e["block"]; e["block"] = 0
	e["hp"] = maxi(e["hp"] - rem, 0)
	if e["hp"] <= 0: _log("[color=yellow]%s destroyed![/color]" % e["name"])

func _draw_cards(count: int) -> void:
	for _i in range(count):
		if hand.size() >= 10: break
		if draw_pile.is_empty():
			draw_pile = discard_pile.duplicate(true); discard_pile.clear(); draw_pile.shuffle()
			if draw_pile.is_empty(): break
		hand.append(draw_pile.pop_back())

func _check_win() -> bool:
	for e in enemies: if e["hp"] > 0: return false
	_end_combat(true); return true

func _end_combat(win: bool) -> void:
	if combat_over: return
	combat_over = true; end_btn.disabled = true
	if win:
		_log("[color=yellow]VICTORY! (%d turns)[/color]" % turn_num)
		var rewards = GM.post_fight_rewards(turn_num)
		await get_tree().create_timer(0.7).timeout
		if is_boss:
			var prev_cycle = GM.infinite_cycle
			GM.advance_act()
			# First completion: show victory. Subsequent: continue to summary
			if prev_cycle == 0 and GM.infinite_cycle > 0:
				GM.screen_change.emit("game_over", {"victory": true})
			else:
				GM.screen_change.emit("round_summary", {"rewards": rewards, "was_boss": true})
		else:
			GM.screen_change.emit("round_summary", {"rewards": rewards, "was_boss": false})
	else:
		_log("[color=red]DEFEAT...[/color]")
		await get_tree().create_timer(1.0).timeout
		GM.screen_change.emit("game_over", {"victory": false})

func _update_ui() -> void:
	hp_lbl.text = "HP: %d/%d" % [GM.hp, GM.max_hp]
	hp_lbl.add_theme_color_override("font_color", Color(1, 0.3, 0.3) if GM.hp < GM.max_hp * 0.3 else Color(0.8, 0.3, 0.3))
	block_lbl.text = "Blk: %d" % block if block > 0 else ""
	energy_lbl.text = "⚡%d/%d" % [energy, max_energy]
	turn_lbl.text = "Turn %d" % turn_num
	gold_lbl.text = "Win: +%dg" % GM.fight_gold(turn_num)
	var sp: Array = []
	if statuses["poison"] > 0: sp.append("PSN:%d" % statuses["poison"])
	if statuses["strength"] > 0: sp.append("STR:+%d" % statuses["strength"])
	if statuses["weak"] > 0: sp.append("WK:%d" % statuses["weak"])
	if statuses["vulnerable"] > 0: sp.append("VL:%d" % statuses["vulnerable"])
	stat_lbl.text = "  ".join(sp)
	# Powers display
	var pw: Array = []
	if power_draw > 0: pw.append("📜+%d" % power_draw)
	if power_str_per_turn > 0: pw.append("💪+%d/t" % power_str_per_turn)
	if synergy_reduction > 0: pw.append("🔗-%d" % synergy_reduction)
	if pw.size() > 0: stat_lbl.text += "  " + " ".join(pw)
	# Synergy
	syn_lbl.clear(); var syn_parts: Array = []
	var thresh = maxi(GM.SYNERGY_THRESHOLD - synergy_reduction, 1)
	for arch in ["red_queen", "mad_hatter", "march_hare", "neutral"]:
		var cnt = cards_by_arch.get(arch, 0)
		if cnt > 0:
			var ch = GM.ARCH_COLORS[arch].to_html(false)
			if arch in synergies_done: syn_parts.append("[color=#%s]%s ⚡[/color]" % [ch, arch.substr(0, 2).to_upper()])
			else: syn_parts.append("[color=#%s]%s %d/%d[/color]" % [ch, arch.substr(0, 2).to_upper(), cnt, thresh])
	syn_lbl.append_text("  ".join(syn_parts))
	draw_lbl.text = "Draw: %d" % draw_pile.size(); disc_lbl.text = "Disc: %d" % discard_pile.size()
	# Enemies
	for i in range(mini(enemies.size(), enemy_box.get_child_count())):
		var e = enemies[i]; var p = enemy_box.get_child(i)
		var hb = _f(p, "HPBar"); if hb: hb.custom_minimum_size.x = 178.0 * clampf(float(e["hp"]) / float(e["max_hp"]), 0, 1)
		var ht = _f(p, "HPTxt"); if ht: ht.text = "%d/%d" % [maxi(e["hp"], 0), e["max_hp"]]
		var bl = _f(p, "Blk"); if bl: bl.text = "Blk: %d" % e["block"] if e["block"] > 0 else ""
		var sl = _f(p, "Sts")
		if sl:
			var ep: Array = []
			if e["statuses"]["poison"] > 0: ep.append("PSN:%d" % e["statuses"]["poison"])
			if e["statuses"]["strength"] > 0: ep.append("STR:+%d" % e["statuses"]["strength"])
			if e["statuses"]["weak"] > 0: ep.append("WK:%d" % e["statuses"]["weak"])
			if e["statuses"]["vulnerable"] > 0: ep.append("VL:%d" % e["statuses"]["vulnerable"])
			sl.text = " ".join(ep)
		var il = _f(p, "Intent")
		if il:
			if e["hp"] <= 0:
				il.text = "DEAD"
				il.add_theme_color_override("font_color", Color(0.4, 0.4, 0.4))
			else:
				var intent = e["intents"][e["intent_idx"]]
				il.text = "» " + GM.get_intent_text(intent)
				il.add_theme_color_override("font_color", GM.get_intent_color(intent))
		if e["hp"] <= 0: p.modulate = Color(0.3, 0.3, 0.3)

func _rebuild_hand() -> void:
	for c in hand_box.get_children(): c.queue_free()
	for i in range(hand.size()):
		var n = _mk_card(hand[i], i); hand_box.add_child(n)
		if i == selected_card:
			n.position.y -= 18
			var bg = _f(n, "CardBG")
			if bg: bg.color = bg.color.lightened(0.25)

func _f(node: Node, n: String) -> Node:
	if node.name == n: return node
	for c in node.get_children():
		var r = _f(c, n)
		if r: return r
	return null

func _mk_lbl(p: Node, t: String, sz: int, c: Color) -> Label:
	var l = Label.new(); l.text = t; l.add_theme_font_size_override("font_size", sz); l.add_theme_color_override("font_color", c); p.add_child(l); return l

func _log(t: String) -> void: log_box.append_text(t + "\n")
