extends Control

func _ready() -> void:
	var rewards = get_meta("rewards") if has_meta("rewards") else {}
	var was_boss = get_meta("was_boss") if has_meta("was_boss") else false
	_build_ui(rewards, was_boss)

func _build_ui(rewards: Dictionary, was_boss: bool) -> void:
	var bg = ColorRect.new()
	bg.color = Color(0.06, 0.05, 0.08)
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	
	var vbox = VBoxContainer.new()
	vbox.set_anchors_preset(PRESET_CENTER)
	vbox.custom_minimum_size = Vector2(500, 450)
	vbox.position = Vector2(-250, -225)
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	vbox.add_theme_constant_override("separation", 8)
	add_child(vbox)
	
	_lbl(vbox, "─── ROUND COMPLETE ───", 26, Color(0.85, 0.75, 0.5))
	_spacer(vbox, 15)
	
	var turns = rewards.get("turns", 0)
	var fight_gold = rewards.get("fight_gold", 0)
	var interest = rewards.get("interest", 0)
	var heal = rewards.get("heal", 0)
	var total = rewards.get("total_gold", GameManager.gold)
	
	# Speed bonus
	_lbl(vbox, "Cleared in %d turn%s" % [turns, "s" if turns != 1 else ""], 20, Color(0.8, 0.7, 0.4))
	_spacer(vbox, 5)
	
	# Gold breakdown
	var speed_color = Color(0.3, 0.8, 0.3) if fight_gold >= 4 else Color(0.7, 0.7, 0.5) if fight_gold >= 2 else Color(0.5, 0.4, 0.4)
	_lbl(vbox, "Speed Bonus: +%dg" % fight_gold, 18, speed_color)
	
	# Speed scale reference
	var scale_text = "( T1: +5g  T2: +4g  T3: +3g  T4: +2g  T5: +1g )"
	_lbl(vbox, scale_text, 11, Color(0.4, 0.4, 0.4))
	_spacer(vbox, 5)
	
	# Interest
	_lbl(vbox, "Interest: +%dg" % interest, 18, Color(0.9, 0.8, 0.3))
	var banked = GameManager.gold - fight_gold - interest
	if banked < 0: banked = 0
	_lbl(vbox, "( Every 5g banked = +1g interest, cap %d )" % GameManager.interest_cap, 11, Color(0.5, 0.45, 0.3))
	_spacer(vbox, 5)
	
	if heal > 0:
		_lbl(vbox, "Relic Heal: +%d HP" % heal, 16, Color(0.4, 0.7, 0.4))
		_spacer(vbox, 5)
	
	# Total
	_lbl(vbox, "───────────", 14, Color(0.3, 0.3, 0.3))
	_lbl(vbox, "Total Gold: %dg" % total, 24, Color(1.0, 0.9, 0.4))
	_lbl(vbox, "HP: %d / %d" % [GameManager.player_hp, GameManager.player_max_hp], 16, Color(0.7, 0.4, 0.4))
	
	_spacer(vbox, 5)
	
	# Tip
	var tip_box = ColorRect.new()
	tip_box.color = Color(0.1, 0.09, 0.12)
	tip_box.custom_minimum_size = Vector2(460, 50)
	vbox.add_child(tip_box)
	var tip = Label.new()
	tip.text = "💡 TIP: Save gold for interest! Having 25g+ gives the\nmax +5g interest each round. Faster kills = more gold."
	tip.add_theme_font_size_override("font_size", 11)
	tip.add_theme_color_override("font_color", Color(0.5, 0.5, 0.45))
	tip.position = Vector2(10, 8)
	tip_box.add_child(tip)
	
	_spacer(vbox, 15)
	
	# Continue button
	var btn_row = CenterContainer.new()
	vbox.add_child(btn_row)
	
	if was_boss:
		var boss_btn = Button.new()
		boss_btn.text = "  Open Boss Booster (5 cards)  "
		boss_btn.custom_minimum_size = Vector2(300, 45)
		boss_btn.add_theme_font_size_override("font_size", 16)
		boss_btn.pressed.connect(_on_boss_booster)
		btn_row.add_child(boss_btn)
	else:
		var shop_btn = Button.new()
		shop_btn.text = "  Continue to Shop  "
		shop_btn.custom_minimum_size = Vector2(220, 45)
		shop_btn.add_theme_font_size_override("font_size", 16)
		shop_btn.pressed.connect(_on_shop)
		btn_row.add_child(shop_btn)

func _on_shop() -> void:
	GameManager.screen_change_requested.emit("shop", {})

func _on_boss_booster() -> void:
	# Boss booster: 5 cards weighted toward the boss's archetype
	GameManager.screen_change_requested.emit("booster_open", {"count": 5, "archetype": "boss", "from": "boss_reward"})

func _lbl(parent: Node, text: String, font_size: int, color: Color) -> void:
	var l = Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	parent.add_child(l)

func _spacer(parent: Node, h: float) -> void:
	var s = Control.new()
	s.custom_minimum_size = Vector2(0, h)
	parent.add_child(s)
