extends Control

# ============================================================
# Card Reward Screen — Pick a card or remove a card
# ============================================================

var reward_cards: Array = []
var showing_remove: bool = false

func _ready() -> void:
	reward_cards = GameManager.get_reward_cards(3)
	_build_ui()

func _build_ui() -> void:
	# Background
	var bg = ColorRect.new()
	bg.color = Color(0.06, 0.05, 0.08)
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	
	# Title
	var title = Label.new()
	title.text = "VICTORY — Choose Your Reward"
	title.position = Vector2(0, 30)
	title.custom_minimum_size = Vector2(1280, 40)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 30)
	title.add_theme_color_override("font_color", Color(0.85, 0.75, 0.5))
	add_child(title)
	
	# Player HP
	var hp_label = Label.new()
	hp_label.text = "HP: %d / %d  |  Deck: %d cards" % [GameManager.player_hp, GameManager.player_max_hp, GameManager.deck.size()]
	hp_label.position = Vector2(0, 70)
	hp_label.custom_minimum_size = Vector2(1280, 25)
	hp_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hp_label.add_theme_font_size_override("font_size", 16)
	hp_label.add_theme_color_override("font_color", Color(0.6, 0.5, 0.55))
	add_child(hp_label)
	
	# Card choices
	var card_container = HBoxContainer.new()
	card_container.position = Vector2(0, 120)
	card_container.custom_minimum_size = Vector2(1280, 300)
	card_container.alignment = BoxContainer.ALIGNMENT_CENTER
	card_container.add_theme_constant_override("separation", 30)
	add_child(card_container)
	
	for i in range(reward_cards.size()):
		var card_id = reward_cards[i]
		var card_panel = _make_reward_card(card_id, i)
		card_container.add_child(card_panel)
	
	# Skip button
	var skip_btn = Button.new()
	skip_btn.text = "Skip Reward"
	skip_btn.position = Vector2(540, 440)
	skip_btn.custom_minimum_size = Vector2(200, 40)
	skip_btn.add_theme_font_size_override("font_size", 16)
	skip_btn.pressed.connect(_on_skip)
	add_child(skip_btn)
	
	# Remove card button
	var remove_btn = Button.new()
	remove_btn.text = "Remove a Card from Deck"
	remove_btn.position = Vector2(460, 500)
	remove_btn.custom_minimum_size = Vector2(360, 40)
	remove_btn.add_theme_font_size_override("font_size", 16)
	remove_btn.pressed.connect(_show_remove_screen)
	add_child(remove_btn)
	
	# Flavor text
	var flavor = Label.new()
	flavor.text = "The threads hum with new potential..."
	flavor.position = Vector2(0, 560)
	flavor.custom_minimum_size = Vector2(1280, 30)
	flavor.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	flavor.add_theme_font_size_override("font_size", 13)
	flavor.add_theme_color_override("font_color", Color(0.35, 0.3, 0.38))
	add_child(flavor)

func _make_reward_card(card_id: String, idx: int) -> PanelContainer:
	var card_data = GameManager.CARDS[card_id]
	
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(200, 280)
	
	var bg = ColorRect.new()
	bg.color = card_data.get("color", Color(0.3, 0.3, 0.3))
	bg.custom_minimum_size = Vector2(200, 280)
	panel.add_child(bg)
	
	var vbox = VBoxContainer.new()
	vbox.position = Vector2(12, 10)
	vbox.custom_minimum_size = Vector2(176, 260)
	vbox.add_theme_constant_override("separation", 6)
	panel.add_child(vbox)
	
	# Cost + Name
	var top_row = HBoxContainer.new()
	vbox.add_child(top_row)
	
	var cost_bg = ColorRect.new()
	cost_bg.color = Color(0.15, 0.12, 0.1)
	cost_bg.custom_minimum_size = Vector2(32, 32)
	top_row.add_child(cost_bg)
	
	var cost_lbl = Label.new()
	cost_lbl.text = str(card_data["cost"])
	cost_lbl.add_theme_font_size_override("font_size", 20)
	cost_lbl.add_theme_color_override("font_color", Color(0.9, 0.8, 0.3))
	cost_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	cost_lbl.custom_minimum_size = Vector2(32, 32)
	cost_bg.add_child(cost_lbl)
	
	var name_lbl = Label.new()
	name_lbl.text = "  " + card_data["name"]
	name_lbl.add_theme_font_size_override("font_size", 18)
	name_lbl.add_theme_color_override("font_color", Color(1, 1, 1))
	top_row.add_child(name_lbl)
	
	# Type
	var type_lbl = Label.new()
	type_lbl.text = card_data["type"].to_upper()
	type_lbl.add_theme_font_size_override("font_size", 12)
	type_lbl.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	vbox.add_child(type_lbl)
	
	# Art placeholder
	var art = ColorRect.new()
	art.color = card_data.get("color", Color(0.3, 0.3, 0.3)).darkened(0.3)
	art.custom_minimum_size = Vector2(176, 90)
	vbox.add_child(art)
	
	# Description
	var desc_lbl = Label.new()
	desc_lbl.text = card_data["desc"]
	desc_lbl.add_theme_font_size_override("font_size", 15)
	desc_lbl.add_theme_color_override("font_color", Color(0.9, 0.9, 0.85))
	desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc_lbl.custom_minimum_size = Vector2(176, 60)
	vbox.add_child(desc_lbl)
	
	# Add button
	var add_btn = Button.new()
	add_btn.text = "Add to Deck"
	add_btn.custom_minimum_size = Vector2(176, 35)
	add_btn.add_theme_font_size_override("font_size", 14)
	add_btn.pressed.connect(_on_card_chosen.bind(card_id))
	vbox.add_child(add_btn)
	
	return panel

func _on_card_chosen(card_id: String) -> void:
	GameManager.add_card_to_deck(card_id)
	_proceed_to_map()

func _on_skip() -> void:
	_proceed_to_map()

func _show_remove_screen() -> void:
	if showing_remove:
		return
	showing_remove = true
	
	# Overlay
	var overlay = ColorRect.new()
	overlay.name = "RemoveOverlay"
	overlay.color = Color(0.05, 0.04, 0.07, 0.95)
	overlay.set_anchors_preset(PRESET_FULL_RECT)
	add_child(overlay)
	
	var title = Label.new()
	title.text = "Choose a card to REMOVE from your deck"
	title.position = Vector2(0, 20)
	title.custom_minimum_size = Vector2(1280, 40)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 24)
	title.add_theme_color_override("font_color", Color(0.9, 0.5, 0.5))
	overlay.add_child(title)
	
	var scroll = ScrollContainer.new()
	scroll.position = Vector2(80, 70)
	scroll.custom_minimum_size = Vector2(1120, 540)
	scroll.size = Vector2(1120, 540)
	overlay.add_child(scroll)
	
	var grid = GridContainer.new()
	grid.columns = 5
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	scroll.add_child(grid)
	
	for i in range(GameManager.deck.size()):
		var card_id = GameManager.deck[i]
		var card_data = GameManager.CARDS[card_id]
		
		var panel = PanelContainer.new()
		panel.custom_minimum_size = Vector2(200, 90)
		
		var bg = ColorRect.new()
		bg.color = card_data.get("color", Color(0.3, 0.3, 0.3)).darkened(0.2)
		bg.custom_minimum_size = Vector2(200, 90)
		panel.add_child(bg)
		
		var vbox = VBoxContainer.new()
		vbox.position = Vector2(8, 5)
		panel.add_child(vbox)
		
		var name_lbl = Label.new()
		name_lbl.text = "%s [%d]" % [card_data["name"], card_data["cost"]]
		name_lbl.add_theme_font_size_override("font_size", 14)
		vbox.add_child(name_lbl)
		
		var desc_lbl = Label.new()
		desc_lbl.text = card_data["desc"]
		desc_lbl.add_theme_font_size_override("font_size", 11)
		desc_lbl.add_theme_color_override("font_color", Color(0.8, 0.8, 0.8))
		vbox.add_child(desc_lbl)
		
		var remove_btn = Button.new()
		remove_btn.text = "Remove"
		remove_btn.custom_minimum_size = Vector2(80, 25)
		remove_btn.add_theme_font_size_override("font_size", 11)
		remove_btn.pressed.connect(_on_card_removed.bind(i))
		vbox.add_child(remove_btn)
		
		grid.add_child(panel)
	
	# Cancel button
	var cancel_btn = Button.new()
	cancel_btn.text = "Cancel"
	cancel_btn.position = Vector2(580, 630)
	cancel_btn.custom_minimum_size = Vector2(120, 35)
	cancel_btn.pressed.connect(func():
		overlay.queue_free()
		showing_remove = false
	)
	overlay.add_child(cancel_btn)

func _on_card_removed(deck_idx: int) -> void:
	GameManager.remove_card_from_deck(deck_idx)
	_proceed_to_map()

func _proceed_to_map() -> void:
	GameManager.screen_change_requested.emit("map", {})
