extends Control

var cards: Array = []  # card IDs
var from_source: String = "shop"

func _ready() -> void:
	var count = get_meta("count") if has_meta("count") else 3
	var archetype = get_meta("archetype") if has_meta("archetype") else "neutral"
	from_source = get_meta("from") if has_meta("from") else "shop"
	
	_generate_cards(count, archetype)
	_build_ui()

func _generate_cards(count: int, archetype: String) -> void:
	cards.clear()
	if archetype == "boss":
		# Boss booster: 5 cards, weighted toward the type
		# Since we don't have the boss archetype stored, pick random with mixed types
		var archetypes = ["rock", "scissors", "paper"]
		var primary = archetypes[randi() % archetypes.size()]
		for i in range(count):
			var arch = primary if randf() < 0.6 else archetypes[randi() % archetypes.size()]
			var pool = GameManager.get_cards_by_archetype(arch)
			if pool.size() > 0:
				cards.append(pool[randi() % pool.size()])
	else:
		var pool = GameManager.get_cards_by_archetype(archetype)
		pool.shuffle()
		for i in range(mini(count, pool.size())):
			cards.append(pool[i])

func _build_ui() -> void:
	var bg = ColorRect.new()
	bg.color = Color(0.06, 0.05, 0.08)
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	
	var title = Label.new()
	title.text = "BOOSTER PACK — Choose cards to keep"
	title.position = Vector2(0, 30)
	title.custom_minimum_size = Vector2(1280, 40)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 26)
	title.add_theme_color_override("font_color", Color(0.85, 0.75, 0.5))
	add_child(title)
	
	var info = Label.new()
	info.text = "Deck: %d/%d  |  Sideboard: %d/%d" % [GameManager.deck.size(), GameManager.max_deck_size, GameManager.sideboard.size(), GameManager.max_sideboard_size]
	info.position = Vector2(0, 65)
	info.custom_minimum_size = Vector2(1280, 25)
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info.add_theme_font_size_override("font_size", 14)
	info.add_theme_color_override("font_color", Color(0.5, 0.5, 0.55))
	add_child(info)
	
	var card_row = HBoxContainer.new()
	card_row.position = Vector2(0, 100)
	card_row.custom_minimum_size = Vector2(1280, 340)
	card_row.alignment = BoxContainer.ALIGNMENT_CENTER
	card_row.add_theme_constant_override("separation", 20)
	add_child(card_row)
	
	for i in range(cards.size()):
		var card_id = cards[i]
		var panel = _make_booster_card(card_id, i)
		card_row.add_child(panel)
	
	# Skip button
	var skip_btn = Button.new()
	skip_btn.text = "Skip All / Done"
	skip_btn.position = Vector2(540, 480)
	skip_btn.custom_minimum_size = Vector2(200, 40)
	skip_btn.add_theme_font_size_override("font_size", 16)
	skip_btn.pressed.connect(_on_done)
	add_child(skip_btn)

func _make_booster_card(card_id: String, idx: int) -> PanelContainer:
	var card_data = GameManager.CARDS[card_id]
	var arch_color = GameManager.get_card_color(card_id)
	
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(200, 310)
	
	var bg = ColorRect.new()
	bg.color = arch_color.darkened(0.2)
	bg.custom_minimum_size = Vector2(200, 310)
	panel.add_child(bg)
	
	var vbox = VBoxContainer.new()
	vbox.position = Vector2(10, 8)
	vbox.custom_minimum_size = Vector2(180, 290)
	vbox.add_theme_constant_override("separation", 4)
	panel.add_child(vbox)
	
	# Header
	var name_row = HBoxContainer.new()
	vbox.add_child(name_row)
	var cost = Label.new()
	cost.text = "[%d] " % card_data["cost"]
	cost.add_theme_font_size_override("font_size", 16)
	cost.add_theme_color_override("font_color", Color(0.9, 0.8, 0.3))
	name_row.add_child(cost)
	var name_lbl = Label.new()
	name_lbl.text = card_data["name"]
	name_lbl.add_theme_font_size_override("font_size", 16)
	name_row.add_child(name_lbl)
	
	var type_lbl = Label.new()
	type_lbl.text = "%s • %s • %s" % [card_data["type"].to_upper(), card_data["archetype"].to_upper(), card_data["rarity"].to_upper()]
	type_lbl.add_theme_font_size_override("font_size", 10)
	type_lbl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	vbox.add_child(type_lbl)
	
	# Art
	var art = ColorRect.new()
	art.color = arch_color.darkened(0.4)
	art.custom_minimum_size = Vector2(180, 80)
	vbox.add_child(art)
	
	# Desc
	var desc = Label.new()
	desc.text = card_data["desc"]
	desc.add_theme_font_size_override("font_size", 14)
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.custom_minimum_size = Vector2(180, 50)
	vbox.add_child(desc)
	
	# Buttons
	var add_deck_btn = Button.new()
	add_deck_btn.text = "Add to Deck"
	add_deck_btn.custom_minimum_size = Vector2(180, 30)
	add_deck_btn.add_theme_font_size_override("font_size", 13)
	add_deck_btn.disabled = GameManager.deck.size() >= GameManager.max_deck_size
	add_deck_btn.pressed.connect(_on_add_deck.bind(card_id, idx))
	vbox.add_child(add_deck_btn)
	
	var add_sb_btn = Button.new()
	add_sb_btn.text = "Add to Sideboard"
	add_sb_btn.custom_minimum_size = Vector2(180, 30)
	add_sb_btn.add_theme_font_size_override("font_size", 13)
	add_sb_btn.disabled = GameManager.sideboard.size() >= GameManager.max_sideboard_size
	add_sb_btn.pressed.connect(_on_add_sb.bind(card_id, idx))
	vbox.add_child(add_sb_btn)
	
	return panel

func _on_add_deck(card_id: String, idx: int) -> void:
	GameManager.add_card_to_deck(card_id)
	cards.remove_at(idx)
	_refresh()

func _on_add_sb(card_id: String, idx: int) -> void:
	GameManager.add_card_to_sideboard(card_id)
	cards.remove_at(idx)
	_refresh()

func _refresh() -> void:
	for c in get_children(): c.queue_free()
	if cards.size() == 0:
		_on_done()
		return
	_build_ui()

func _on_done() -> void:
	if from_source == "boss_reward":
		GameManager.screen_change_requested.emit("shop", {})
	else:
		GameManager.screen_change_requested.emit("shop", {})
