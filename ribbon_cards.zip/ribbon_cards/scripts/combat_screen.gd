extends Control

# ============================================================
# Combat Screen — Full card combat system
# ============================================================

# --- Combat State ---
var energy: int = 3
var max_energy: int = 3
var player_block: int = 0
var player_statuses: Dictionary = {"poison": 0, "strength": 0, "weak": 0, "vulnerable": 0}

var draw_pile: Array = []
var hand: Array = []
var discard_pile: Array = []
const HAND_SIZE: int = 5

var enemies: Array = []  # Array of enemy state dicts
var selected_card_idx: int = -1
var combat_over: bool = false
var player_turn: bool = true

# --- UI References ---
var hand_container: HBoxContainer
var enemy_container: HBoxContainer
var energy_label: Label
var hp_label: Label
var block_label: Label
var status_label: Label
var draw_label: Label
var discard_label: Label
var end_turn_btn: Button
var log_label: RichTextLabel
var card_nodes: Array = []
var enemy_nodes: Array = []

func _ready() -> void:
	var encounter_data = get_meta("encounter_data") if has_meta("encounter_data") else {}
	_init_combat(encounter_data)
	_build_ui()
	_start_player_turn()

# ============================================================
# INITIALIZATION
# ============================================================

func _init_combat(encounter_data: Dictionary) -> void:
	# Build draw pile from deck
	draw_pile = GameManager.deck.duplicate()
	draw_pile.shuffle()
	hand.clear()
	discard_pile.clear()
	
	player_block = 0
	player_statuses = {"poison": 0, "strength": 0, "weak": 0, "vulnerable": 0}
	energy = max_energy
	
	# Spawn enemies
	enemies.clear()
	var enemy_ids = encounter_data.get("enemies", ["frayed_hound"])
	for eid in enemy_ids:
		var edata = GameManager.ENEMIES[eid]
		var hp = randi_range(edata["min_hp"], edata["max_hp"])
		enemies.append({
			"id": eid,
			"name": edata["name"],
			"hp": hp,
			"max_hp": hp,
			"block": 0,
			"intents": edata["intents"],
			"intent_idx": randi() % edata["intents"].size(),
			"statuses": {"poison": 0, "strength": 0, "weak": 0, "vulnerable": 0},
		})

# ============================================================
# UI BUILDING
# ============================================================

func _build_ui() -> void:
	# Background
	var bg = ColorRect.new()
	bg.color = Color(0.05, 0.04, 0.07)
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	
	# === TOP BAR: Player info ===
	var top_bar = HBoxContainer.new()
	top_bar.position = Vector2(20, 10)
	top_bar.add_theme_constant_override("separation", 25)
	add_child(top_bar)
	
	hp_label = Label.new()
	hp_label.add_theme_font_size_override("font_size", 20)
	top_bar.add_child(hp_label)
	
	block_label = Label.new()
	block_label.add_theme_font_size_override("font_size", 20)
	block_label.add_theme_color_override("font_color", Color(0.3, 0.6, 0.9))
	top_bar.add_child(block_label)
	
	energy_label = Label.new()
	energy_label.add_theme_font_size_override("font_size", 20)
	energy_label.add_theme_color_override("font_color", Color(0.9, 0.8, 0.3))
	top_bar.add_child(energy_label)
	
	status_label = Label.new()
	status_label.add_theme_font_size_override("font_size", 16)
	top_bar.add_child(status_label)
	
	# Draw / Discard pile info
	draw_label = Label.new()
	draw_label.position = Vector2(20, 680)
	draw_label.add_theme_font_size_override("font_size", 14)
	draw_label.add_theme_color_override("font_color", Color(0.5, 0.5, 0.6))
	add_child(draw_label)
	
	discard_label = Label.new()
	discard_label.position = Vector2(180, 680)
	discard_label.add_theme_font_size_override("font_size", 14)
	discard_label.add_theme_color_override("font_color", Color(0.5, 0.5, 0.6))
	add_child(discard_label)
	
	# === ENEMY AREA ===
	enemy_container = HBoxContainer.new()
	enemy_container.position = Vector2(0, 100)
	enemy_container.custom_minimum_size = Vector2(1280, 250)
	enemy_container.alignment = BoxContainer.ALIGNMENT_CENTER
	enemy_container.add_theme_constant_override("separation", 30)
	add_child(enemy_container)
	
	_build_enemy_nodes()
	
	# === HAND AREA ===
	hand_container = HBoxContainer.new()
	hand_container.position = Vector2(0, 490)
	hand_container.custom_minimum_size = Vector2(1280, 190)
	hand_container.alignment = BoxContainer.ALIGNMENT_CENTER
	hand_container.add_theme_constant_override("separation", 8)
	add_child(hand_container)
	
	# === END TURN BUTTON ===
	end_turn_btn = Button.new()
	end_turn_btn.text = "END TURN"
	end_turn_btn.position = Vector2(1130, 500)
	end_turn_btn.custom_minimum_size = Vector2(130, 45)
	end_turn_btn.add_theme_font_size_override("font_size", 16)
	end_turn_btn.pressed.connect(_on_end_turn)
	add_child(end_turn_btn)
	
	# === COMBAT LOG ===
	log_label = RichTextLabel.new()
	log_label.position = Vector2(900, 400)
	log_label.custom_minimum_size = Vector2(360, 80)
	log_label.size = Vector2(360, 80)
	log_label.bbcode_enabled = true
	log_label.add_theme_font_size_override("normal_font_size", 12)
	log_label.scroll_following = true
	add_child(log_label)
	
	_update_all_ui()

func _build_enemy_nodes() -> void:
	for child in enemy_container.get_children():
		child.queue_free()
	enemy_nodes.clear()
	
	for i in range(enemies.size()):
		var enemy = enemies[i]
		var panel = _create_enemy_panel(enemy, i)
		enemy_container.add_child(panel)
		enemy_nodes.append(panel)

func _create_enemy_panel(enemy: Dictionary, idx: int) -> PanelContainer:
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(200, 230)
	
	var bg = ColorRect.new()
	bg.color = Color(0.12, 0.1, 0.15)
	bg.custom_minimum_size = Vector2(200, 230)
	panel.add_child(bg)
	
	var vbox = VBoxContainer.new()
	vbox.position = Vector2(10, 10)
	vbox.custom_minimum_size = Vector2(180, 210)
	vbox.add_theme_constant_override("separation", 4)
	panel.add_child(vbox)
	
	# Name
	var name_lbl = Label.new()
	name_lbl.name = "EnemyName"
	name_lbl.text = enemy["name"]
	name_lbl.add_theme_font_size_override("font_size", 16)
	name_lbl.add_theme_color_override("font_color", Color(0.9, 0.7, 0.7))
	name_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(name_lbl)
	
	# HP Bar background
	var hp_bg = ColorRect.new()
	hp_bg.color = Color(0.2, 0.1, 0.1)
	hp_bg.custom_minimum_size = Vector2(180, 20)
	vbox.add_child(hp_bg)
	
	var hp_bar = ColorRect.new()
	hp_bar.name = "HPBar"
	hp_bar.color = Color(0.7, 0.2, 0.2)
	hp_bar.custom_minimum_size = Vector2(180, 20)
	hp_bg.add_child(hp_bar)
	
	var hp_text = Label.new()
	hp_text.name = "HPText"
	hp_text.text = "%d / %d" % [enemy["hp"], enemy["max_hp"]]
	hp_text.add_theme_font_size_override("font_size", 13)
	hp_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hp_text.custom_minimum_size = Vector2(180, 20)
	hp_bg.add_child(hp_text)
	
	# Block
	var block_lbl = Label.new()
	block_lbl.name = "EnemyBlock"
	block_lbl.add_theme_font_size_override("font_size", 14)
	block_lbl.add_theme_color_override("font_color", Color(0.3, 0.6, 0.9))
	block_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(block_lbl)
	
	# Status effects
	var status_lbl = Label.new()
	status_lbl.name = "EnemyStatus"
	status_lbl.add_theme_font_size_override("font_size", 12)
	status_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(status_lbl)
	
	# Intent
	var intent_bg = ColorRect.new()
	intent_bg.custom_minimum_size = Vector2(180, 35)
	var intent = enemy["intents"][enemy["intent_idx"]]
	intent_bg.color = GameManager.get_intent_color(intent) * 0.3
	vbox.add_child(intent_bg)
	
	var intent_lbl = Label.new()
	intent_lbl.name = "IntentLabel"
	intent_lbl.text = "Intent: " + GameManager.get_intent_text(intent)
	intent_lbl.add_theme_font_size_override("font_size", 14)
	intent_lbl.add_theme_color_override("font_color", GameManager.get_intent_color(intent))
	intent_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	intent_lbl.custom_minimum_size = Vector2(180, 35)
	intent_bg.add_child(intent_lbl)
	
	# Spacer for visual body
	var body = ColorRect.new()
	body.color = Color(0.15, 0.12, 0.18)
	body.custom_minimum_size = Vector2(180, 60)
	vbox.add_child(body)
	
	var body_lbl = Label.new()
	body_lbl.text = "☠"
	body_lbl.add_theme_font_size_override("font_size", 36)
	body_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	body_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	body_lbl.custom_minimum_size = Vector2(180, 60)
	body.add_child(body_lbl)
	
	# Click detection — use a Button overlay
	var click_btn = Button.new()
	click_btn.flat = true
	click_btn.set_anchors_preset(PRESET_FULL_RECT)
	click_btn.custom_minimum_size = Vector2(200, 230)
	click_btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	click_btn.pressed.connect(_on_enemy_clicked.bind(idx))
	panel.add_child(click_btn)
	
	return panel

func _create_card_node(card_id: String, hand_idx: int) -> PanelContainer:
	var card_data = GameManager.CARDS[card_id]
	
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(135, 180)
	
	var bg = ColorRect.new()
	bg.name = "CardBG"
	bg.color = card_data.get("color", Color(0.3, 0.3, 0.3))
	bg.custom_minimum_size = Vector2(135, 180)
	panel.add_child(bg)
	
	var vbox = VBoxContainer.new()
	vbox.position = Vector2(8, 6)
	vbox.custom_minimum_size = Vector2(119, 168)
	vbox.add_theme_constant_override("separation", 3)
	panel.add_child(vbox)
	
	# Cost + Name row
	var top_row = HBoxContainer.new()
	vbox.add_child(top_row)
	
	var cost_bg = ColorRect.new()
	cost_bg.color = Color(0.15, 0.12, 0.1)
	cost_bg.custom_minimum_size = Vector2(26, 26)
	top_row.add_child(cost_bg)
	
	var cost_lbl = Label.new()
	cost_lbl.text = str(card_data["cost"])
	cost_lbl.add_theme_font_size_override("font_size", 16)
	cost_lbl.add_theme_color_override("font_color", Color(0.9, 0.8, 0.3))
	cost_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	cost_lbl.custom_minimum_size = Vector2(26, 26)
	cost_bg.add_child(cost_lbl)
	
	var name_lbl = Label.new()
	name_lbl.text = " " + card_data["name"]
	name_lbl.add_theme_font_size_override("font_size", 13)
	name_lbl.add_theme_color_override("font_color", Color(1, 1, 1))
	top_row.add_child(name_lbl)
	
	# Type
	var type_lbl = Label.new()
	type_lbl.text = card_data["type"].to_upper()
	type_lbl.add_theme_font_size_override("font_size", 10)
	type_lbl.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	vbox.add_child(type_lbl)
	
	# Card art area (placeholder)
	var art = ColorRect.new()
	art.color = card_data.get("color", Color(0.3, 0.3, 0.3)).darkened(0.3)
	art.custom_minimum_size = Vector2(119, 60)
	vbox.add_child(art)
	
	# Description
	var desc_lbl = Label.new()
	desc_lbl.text = card_data["desc"]
	desc_lbl.add_theme_font_size_override("font_size", 12)
	desc_lbl.add_theme_color_override("font_color", Color(0.9, 0.9, 0.85))
	desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc_lbl.custom_minimum_size = Vector2(119, 50)
	vbox.add_child(desc_lbl)
	
	# Click button overlay
	var click_btn = Button.new()
	click_btn.flat = true
	click_btn.set_anchors_preset(PRESET_FULL_RECT)
	click_btn.custom_minimum_size = Vector2(135, 180)
	click_btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	click_btn.pressed.connect(_on_card_clicked.bind(hand_idx))
	panel.add_child(click_btn)
	
	return panel

# ============================================================
# TURN FLOW
# ============================================================

func _start_player_turn() -> void:
	if combat_over:
		return
	
	player_turn = true
	energy = max_energy
	player_block = 0
	
	# Tick player poison
	if player_statuses["poison"] > 0:
		var dmg = player_statuses["poison"]
		GameManager.damage_player(dmg)
		_log("[color=green]You take %d poison damage.[/color]" % dmg)
		player_statuses["poison"] = maxi(player_statuses["poison"] - 1, 0)
		if GameManager.player_hp <= 0:
			_end_combat(false)
			return
	
	# Decrement player debuffs
	player_statuses["weak"] = maxi(player_statuses["weak"] - 1, 0)
	player_statuses["vulnerable"] = maxi(player_statuses["vulnerable"] - 1, 0)
	
	# Draw cards
	_draw_cards(HAND_SIZE)
	_rebuild_hand_ui()
	_update_all_ui()
	end_turn_btn.disabled = false

func _on_end_turn() -> void:
	if not player_turn or combat_over:
		return
	
	player_turn = false
	end_turn_btn.disabled = true
	selected_card_idx = -1
	
	# Discard hand
	for card_id in hand:
		discard_pile.append(card_id)
	hand.clear()
	_rebuild_hand_ui()
	
	# Enemy turn
	await _execute_enemy_turns()
	
	# Check player death
	if GameManager.player_hp <= 0:
		_end_combat(false)
		return
	
	# Start new player turn
	_start_player_turn()

func _execute_enemy_turns() -> void:
	for i in range(enemies.size()):
		if combat_over:
			return
		var enemy = enemies[i]
		if enemy["hp"] <= 0:
			continue
		
		# Reset enemy block
		enemy["block"] = 0
		
		# Tick enemy poison
		if enemy["statuses"]["poison"] > 0:
			var dmg = enemy["statuses"]["poison"]
			enemy["hp"] -= dmg
			_log("[color=green]%s takes %d poison.[/color]" % [enemy["name"], dmg])
			enemy["statuses"]["poison"] = maxi(enemy["statuses"]["poison"] - 1, 0)
			if enemy["hp"] <= 0:
				_log("[color=yellow]%s is destroyed![/color]" % enemy["name"])
				_check_all_enemies_dead()
				_update_all_ui()
				continue
		
		# Decrement enemy debuffs
		enemy["statuses"]["weak"] = maxi(enemy["statuses"]["weak"] - 1, 0)
		enemy["statuses"]["vulnerable"] = maxi(enemy["statuses"]["vulnerable"] - 1, 0)
		
		# Execute intent
		var intent = enemy["intents"][enemy["intent_idx"]]
		_execute_enemy_intent(enemy, intent)
		
		# Advance intent
		enemy["intent_idx"] = (enemy["intent_idx"] + 1) % enemy["intents"].size()
		
		_update_all_ui()
		
		# Small delay for readability
		await get_tree().create_timer(0.3).timeout
	
	_update_all_ui()

func _execute_enemy_intent(enemy: Dictionary, intent: Dictionary) -> void:
	var value = intent["value"]
	
	match intent["type"]:
		"attack":
			var atk = value + enemy["statuses"]["strength"]
			if enemy["statuses"]["weak"] > 0:
				atk = int(atk * 0.75)
			atk = maxi(atk, 0)
			
			# Apply vulnerable
			if player_statuses["vulnerable"] > 0:
				atk = int(atk * 1.5)
			
			var actual = _apply_damage_to_player(atk)
			_log("%s attacks for %d!" % [enemy["name"], actual])
		
		"defend":
			enemy["block"] += value
			_log("%s gains %d Block." % [enemy["name"], value])
		
		"buff_strength":
			enemy["statuses"]["strength"] += value
			_log("%s gains %d Strength!" % [enemy["name"], value])
		
		"debuff_poison":
			player_statuses["poison"] += value
			_log("[color=green]%s poisons you for %d![/color]" % [enemy["name"], value])
		
		"debuff_weak":
			player_statuses["weak"] += value
			_log("[color=purple]%s weakens you for %d![/color]" % [enemy["name"], value])
		
		"debuff_vulnerable":
			player_statuses["vulnerable"] += value
			_log("[color=purple]%s makes you Vulnerable for %d![/color]" % [enemy["name"], value])

func _apply_damage_to_player(amount: int) -> int:
	var remaining = amount
	if player_block > 0:
		if player_block >= remaining:
			player_block -= remaining
			return 0
		else:
			remaining -= player_block
			player_block = 0
	GameManager.damage_player(remaining)
	return remaining

# ============================================================
# CARD PLAYING
# ============================================================

func _on_card_clicked(hand_idx: int) -> void:
	if not player_turn or combat_over:
		return
	
	if hand_idx < 0 or hand_idx >= hand.size():
		return
	
	var card_id = hand[hand_idx]
	var card_data = GameManager.CARDS[card_id]
	
	# Check energy
	if card_data["cost"] > energy:
		_log("[color=red]Not enough energy![/color]")
		return
	
	var target_type = card_data.get("target", "self")
	
	if target_type == "single":
		# Need to select an enemy target
		if selected_card_idx == hand_idx:
			selected_card_idx = -1  # Deselect
		else:
			selected_card_idx = hand_idx
		_rebuild_hand_ui()
		return
	elif target_type == "all" or target_type == "self":
		# Play immediately
		_play_card(hand_idx, -1)

func _on_enemy_clicked(enemy_idx: int) -> void:
	if not player_turn or combat_over:
		return
	if selected_card_idx < 0 or selected_card_idx >= hand.size():
		return
	if enemy_idx < 0 or enemy_idx >= enemies.size():
		return
	if enemies[enemy_idx]["hp"] <= 0:
		return
	
	_play_card(selected_card_idx, enemy_idx)

func _play_card(hand_idx: int, target_enemy: int) -> void:
	var card_id = hand[hand_idx]
	var card_data = GameManager.CARDS[card_id]
	
	# Pay energy
	energy -= card_data["cost"]
	
	# Apply effects
	for effect in card_data["effects"]:
		_apply_effect(effect, target_enemy, card_data.get("target", "self"))
	
	_log("Played %s." % card_data["name"])
	
	# Move card to discard
	hand.remove_at(hand_idx)
	discard_pile.append(card_id)
	selected_card_idx = -1
	
	# Check if enemies are dead
	_check_all_enemies_dead()
	
	_rebuild_hand_ui()
	_update_all_ui()

func _apply_effect(effect: Dictionary, target_enemy: int, target_type: String) -> void:
	var value = effect["value"]
	
	match effect["type"]:
		"damage":
			var atk = value + player_statuses["strength"]
			if player_statuses["weak"] > 0:
				atk = int(atk * 0.75)
			atk = maxi(atk, 0)
			
			if target_type == "all":
				for i in range(enemies.size()):
					if enemies[i]["hp"] > 0:
						var actual_atk = atk
						if enemies[i]["statuses"]["vulnerable"] > 0:
							actual_atk = int(actual_atk * 1.5)
						_deal_damage_to_enemy(i, actual_atk)
			elif target_enemy >= 0:
				var actual_atk = atk
				if enemies[target_enemy]["statuses"]["vulnerable"] > 0:
					actual_atk = int(actual_atk * 1.5)
				_deal_damage_to_enemy(target_enemy, actual_atk)
		
		"block":
			player_block += value
		
		"heal":
			GameManager.heal_player(value)
		
		"draw":
			_draw_cards(value)
		
		"energy":
			energy += value
		
		"self_damage":
			GameManager.damage_player(value)
		
		"poison":
			if target_type == "all":
				for i in range(enemies.size()):
					if enemies[i]["hp"] > 0:
						enemies[i]["statuses"]["poison"] += value
			elif target_enemy >= 0:
				enemies[target_enemy]["statuses"]["poison"] += value
		
		"vulnerable":
			if target_type == "all":
				for i in range(enemies.size()):
					if enemies[i]["hp"] > 0:
						enemies[i]["statuses"]["vulnerable"] += value
			elif target_enemy >= 0:
				enemies[target_enemy]["statuses"]["vulnerable"] += value
		
		"weak":
			if target_type == "all":
				for i in range(enemies.size()):
					if enemies[i]["hp"] > 0:
						enemies[i]["statuses"]["weak"] += value
			elif target_enemy >= 0:
				enemies[target_enemy]["statuses"]["weak"] += value
		
		"strength":
			player_statuses["strength"] += value

func _deal_damage_to_enemy(idx: int, amount: int) -> void:
	var enemy = enemies[idx]
	var remaining = amount
	if enemy["block"] > 0:
		if enemy["block"] >= remaining:
			enemy["block"] -= remaining
			return
		else:
			remaining -= enemy["block"]
			enemy["block"] = 0
	enemy["hp"] = maxi(enemy["hp"] - remaining, 0)
	if enemy["hp"] <= 0:
		_log("[color=yellow]%s is destroyed![/color]" % enemy["name"])

# ============================================================
# DECK OPERATIONS
# ============================================================

func _draw_cards(count: int) -> void:
	for i in range(count):
		if hand.size() >= 10:  # Max hand size
			break
		if draw_pile.is_empty():
			_shuffle_discard_into_draw()
		if draw_pile.is_empty():
			break
		hand.append(draw_pile.pop_back())

func _shuffle_discard_into_draw() -> void:
	draw_pile = discard_pile.duplicate()
	discard_pile.clear()
	draw_pile.shuffle()
	_log("[color=gray]Deck reshuffled.[/color]")

# ============================================================
# COMBAT END
# ============================================================

func _check_all_enemies_dead() -> void:
	for enemy in enemies:
		if enemy["hp"] > 0:
			return
	# All enemies dead — victory!
	_end_combat(true)

func _end_combat(victory: bool) -> void:
	if combat_over:
		return
	combat_over = true
	end_turn_btn.disabled = true
	
	if victory:
		_log("[color=yellow]VICTORY![/color]")
		GameManager.advance_fight()
		
		# Wait, then go to reward or map
		await get_tree().create_timer(1.0).timeout
		
		if GameManager.is_boss_fight():
			# Just beat the boss — advance act or win game
			# We already advanced fight to 4, so we need to check next act
			# Boss was fight index 3, so current_fight is now 4
			# advance_act resets current_fight to 0
			if not GameManager.advance_act():
				# Beat final boss — game won!
				GameManager.screen_change_requested.emit("game_over", {"victory": true})
			else:
				# Next act — go to reward first
				GameManager.screen_change_requested.emit("reward", {})
		else:
			GameManager.screen_change_requested.emit("reward", {})
	else:
		_log("[color=red]DEFEAT...[/color]")
		await get_tree().create_timer(1.5).timeout
		GameManager.screen_change_requested.emit("game_over", {"victory": false})

# ============================================================
# UI UPDATE
# ============================================================

func _update_all_ui() -> void:
	hp_label.text = "HP: %d / %d" % [GameManager.player_hp, GameManager.player_max_hp]
	if GameManager.player_hp <= GameManager.player_max_hp * 0.3:
		hp_label.add_theme_color_override("font_color", Color(1, 0.3, 0.3))
	else:
		hp_label.add_theme_color_override("font_color", Color(0.8, 0.3, 0.3))
	
	block_label.text = "Block: %d" % player_block
	block_label.visible = player_block > 0
	
	energy_label.text = "Energy: %d / %d" % [energy, max_energy]
	
	# Player status
	var status_parts: Array = []
	if player_statuses["poison"] > 0:
		status_parts.append("PSN:%d" % player_statuses["poison"])
	if player_statuses["strength"] > 0:
		status_parts.append("STR:+%d" % player_statuses["strength"])
	if player_statuses["weak"] > 0:
		status_parts.append("WEAK:%d" % player_statuses["weak"])
	if player_statuses["vulnerable"] > 0:
		status_parts.append("VULN:%d" % player_statuses["vulnerable"])
	status_label.text = "  ".join(status_parts)
	
	var status_colors = ""
	if player_statuses["poison"] > 0:
		status_colors = "font_color"
	status_label.add_theme_color_override("font_color", Color(0.7, 0.6, 0.8))
	
	draw_label.text = "Draw: %d" % draw_pile.size()
	discard_label.text = "Discard: %d" % discard_pile.size()
	
	# Update enemy panels
	_rebuild_enemy_ui()

func _rebuild_enemy_ui() -> void:
	for i in range(mini(enemies.size(), enemy_nodes.size())):
		var enemy = enemies[i]
		var panel = enemy_nodes[i]
		
		# Update HP bar
		var hp_bar = _find_child_recursive(panel, "HPBar")
		if hp_bar and hp_bar is ColorRect:
			var ratio = float(enemy["hp"]) / float(enemy["max_hp"])
			hp_bar.custom_minimum_size.x = 180.0 * ratio
			if enemy["hp"] <= 0:
				hp_bar.color = Color(0.3, 0.3, 0.3)
			elif ratio < 0.3:
				hp_bar.color = Color(0.9, 0.2, 0.1)
			else:
				hp_bar.color = Color(0.7, 0.2, 0.2)
		
		# Update HP text
		var hp_text = _find_child_recursive(panel, "HPText")
		if hp_text and hp_text is Label:
			hp_text.text = "%d / %d" % [maxi(enemy["hp"], 0), enemy["max_hp"]]
		
		# Block
		var block_lbl = _find_child_recursive(panel, "EnemyBlock")
		if block_lbl and block_lbl is Label:
			if enemy["block"] > 0:
				block_lbl.text = "Block: %d" % enemy["block"]
			else:
				block_lbl.text = ""
		
		# Status effects
		var status_lbl = _find_child_recursive(panel, "EnemyStatus")
		if status_lbl and status_lbl is Label:
			var parts: Array = []
			if enemy["statuses"]["poison"] > 0:
				parts.append("PSN:%d" % enemy["statuses"]["poison"])
			if enemy["statuses"]["strength"] > 0:
				parts.append("STR:+%d" % enemy["statuses"]["strength"])
			if enemy["statuses"]["weak"] > 0:
				parts.append("WK:%d" % enemy["statuses"]["weak"])
			if enemy["statuses"]["vulnerable"] > 0:
				parts.append("VL:%d" % enemy["statuses"]["vulnerable"])
			status_lbl.text = " ".join(parts)
			status_lbl.add_theme_color_override("font_color", Color(0.7, 0.5, 0.8))
		
		# Intent
		var intent_lbl = _find_child_recursive(panel, "IntentLabel")
		if intent_lbl and intent_lbl is Label and enemy["hp"] > 0:
			var intent = enemy["intents"][enemy["intent_idx"]]
			intent_lbl.text = "Intent: " + GameManager.get_intent_text(intent)
			intent_lbl.add_theme_color_override("font_color", GameManager.get_intent_color(intent))
		elif intent_lbl and enemy["hp"] <= 0:
			intent_lbl.text = "DEFEATED"
			intent_lbl.add_theme_color_override("font_color", Color(0.4, 0.4, 0.4))
		
		# Dim dead enemies
		if enemy["hp"] <= 0:
			panel.modulate = Color(0.4, 0.4, 0.4)

func _rebuild_hand_ui() -> void:
	for child in hand_container.get_children():
		child.queue_free()
	card_nodes.clear()
	
	for i in range(hand.size()):
		var card_node = _create_card_node(hand[i], i)
		hand_container.add_child(card_node)
		card_nodes.append(card_node)
		
		# Highlight selected card
		if i == selected_card_idx:
			card_node.position.y -= 20
			var bg = _find_child_recursive(card_node, "CardBG")
			if bg and bg is ColorRect:
				bg.color = bg.color.lightened(0.3)

func _find_child_recursive(node: Node, child_name: String) -> Node:
	if node.name == child_name:
		return node
	for child in node.get_children():
		var result = _find_child_recursive(child, child_name)
		if result:
			return result
	return null

func _log(text: String) -> void:
	log_label.append_text(text + "\n")
