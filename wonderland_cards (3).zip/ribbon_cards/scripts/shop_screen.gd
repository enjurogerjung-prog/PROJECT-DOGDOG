extends Control

var shop_cards: Array = []; var shop_relics: Array = []; var rerolls: int = 0

func _ready() -> void: shop_cards = GM.rand_shop_cards(3); shop_relics = GM.rand_relics(2); _build()

func _build() -> void:
	for c in get_children(): c.queue_free()
	var bg = ColorRect.new(); bg.color = Color(0.07, 0.06, 0.09); bg.set_anchors_preset(PRESET_FULL_RECT); add_child(bg)
	var top = HBoxContainer.new(); top.position = Vector2(15, 8); top.add_theme_constant_override("separation", 20); add_child(top)
	_l(top, "SHOP", 22, Color(0.85, 0.75, 0.5)); _l(top, "Gold: %dg" % GM.gold, 18, Color(0.9, 0.8, 0.3))
	_l(top, "HP: %d/%d" % [GM.hp, GM.max_hp], 16, Color(0.7, 0.4, 0.4))
	_l(top, "Deck: %d SB: %d" % [GM.deck.size(), GM.sideboard.size()], 13, Color(0.5, 0.5, 0.6))
	# Cards row
	_l(self, "─── Cards ───", 14, Color(0.55, 0.5, 0.45), Vector2(15, 42))
	var crow = HBoxContainer.new(); crow.position = Vector2(15, 62); crow.add_theme_constant_override("separation", 10); add_child(crow)
	for cid in shop_cards:
		var cd = GM.CARDS[cid]; var price = maxi(cd["price"] - GM.shop_disc, 1)
		var p = PanelContainer.new(); p.custom_minimum_size = Vector2(175, 130)
		var pbg = ColorRect.new(); pbg.color = GM.get_arch_color(cid).darkened(0.35); pbg.custom_minimum_size = Vector2(175, 130); p.add_child(pbg)
		var vb = VBoxContainer.new(); vb.position = Vector2(6, 4); vb.add_theme_constant_override("separation", 2); p.add_child(vb)
		_l(vb, "[%d] %s" % [cd["cost"], cd["name"]], 14, Color.WHITE)
		_l(vb, "%s • %s • %s" % [cd["type"].to_upper(), GM.ARCH_NAMES.get(cd["arch"], "?"), cd["rarity"].to_upper()], 9, Color(0.6, 0.6, 0.6))
		var dl = Label.new(); dl.text = cd["desc"]; dl.add_theme_font_size_override("font_size", 11); dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; dl.custom_minimum_size = Vector2(163, 35); vb.add_child(dl)
		var br = HBoxContainer.new(); br.add_theme_constant_override("separation", 6); vb.add_child(br)
		_l(br, "%dg" % price, 13, Color(0.9, 0.8, 0.3))
		var btn = Button.new(); btn.text = "Buy"; btn.custom_minimum_size = Vector2(55, 25); btn.add_theme_font_size_override("font_size", 11)
		btn.disabled = GM.gold < price or GM.deck.size() >= GM.max_deck; btn.pressed.connect(_buy_card.bind(cid, price)); br.add_child(btn)
		crow.add_child(p)
	var rc = GM.REROLL_BASE_COST + rerolls
	var rbtn = Button.new(); rbtn.text = "Reroll (%dg)" % rc; rbtn.custom_minimum_size = Vector2(100, 35); rbtn.add_theme_font_size_override("font_size", 12)
	rbtn.disabled = GM.gold < rc; rbtn.pressed.connect(_reroll); crow.add_child(rbtn)
	# Relics
	_l(self, "─── Relics ───", 14, Color(0.55, 0.5, 0.45), Vector2(15, 200))
	var rrow = HBoxContainer.new(); rrow.position = Vector2(15, 222); rrow.add_theme_constant_override("separation", 10); add_child(rrow)
	for rid in shop_relics:
		var r = GM.RELICS[rid]; var price = r["price"] + GM.row2_buys * 5 - GM.relic_disc
		price = maxi(price, 1)
		var rp = PanelContainer.new(); rp.custom_minimum_size = Vector2(210, 85)
		var rpbg = ColorRect.new(); rpbg.color = Color(0.14, 0.11, 0.08); rpbg.custom_minimum_size = Vector2(210, 85); rp.add_child(rpbg)
		var rv = VBoxContainer.new(); rv.position = Vector2(6, 4); rv.add_theme_constant_override("separation", 2); rp.add_child(rv)
		_l(rv, r["name"], 14, Color(0.9, 0.75, 0.4))
		_l(rv, r["desc"], 11, Color(0.7, 0.7, 0.65))
		var rbr = HBoxContainer.new(); rbr.add_theme_constant_override("separation", 6); rv.add_child(rbr)
		_l(rbr, "%dg" % price, 12, Color(0.9, 0.8, 0.3))
		var rbuy = Button.new(); rbuy.text = "Buy"; rbuy.custom_minimum_size = Vector2(50, 22); rbuy.add_theme_font_size_override("font_size", 10)
		rbuy.disabled = GM.gold < price; rbuy.pressed.connect(_buy_relic.bind(rid, price)); rbr.add_child(rbuy)
		rrow.add_child(rp)
	# Boosters
	_l(self, "─── Booster Packs (3 cards) ───", 14, Color(0.55, 0.5, 0.45), Vector2(15, 320))
	var brow = HBoxContainer.new(); brow.position = Vector2(15, 342); brow.add_theme_constant_override("separation", 12); add_child(brow)
	for arch in ["red_queen", "mad_hatter", "march_hare"]:
		var cost = GM.booster_cost(arch); var ac = GM.ARCH_COLORS[arch]
		var bp = PanelContainer.new(); bp.custom_minimum_size = Vector2(150, 65)
		var bpbg = ColorRect.new(); bpbg.color = ac.darkened(0.6); bpbg.custom_minimum_size = Vector2(150, 65); bp.add_child(bpbg)
		var bv = VBoxContainer.new(); bv.position = Vector2(6, 4); bp.add_child(bv)
		_l(bv, "%s Pack" % GM.ARCH_NAMES[arch], 13, ac.lightened(0.3))
		var bbr = HBoxContainer.new(); bbr.add_theme_constant_override("separation", 6); bv.add_child(bbr)
		_l(bbr, "%dg" % cost, 12, Color(0.9, 0.8, 0.3))
		var bbtn = Button.new(); bbtn.text = "Buy"; bbtn.custom_minimum_size = Vector2(45, 22); bbtn.add_theme_font_size_override("font_size", 10)
		bbtn.disabled = GM.gold < cost; bbtn.pressed.connect(_buy_booster.bind(arch, cost)); bbr.add_child(bbtn)
		brow.add_child(bp)
	# Bottom
	var bot = HBoxContainer.new(); bot.position = Vector2(15, 660); bot.add_theme_constant_override("separation", 10); add_child(bot)
	var dk = Button.new(); dk.text = "Manage Deck / Sell / Combine"; dk.custom_minimum_size = Vector2(250, 32); dk.add_theme_font_size_override("font_size", 13)
	dk.pressed.connect(func(): GM.screen_change.emit("deck_manager", {"return_to": "shop"})); bot.add_child(dk)
	var lv = Button.new(); lv.text = "Leave Shop →"; lv.custom_minimum_size = Vector2(120, 32); lv.add_theme_font_size_override("font_size", 13)
	lv.pressed.connect(func(): GM.screen_change.emit("map", {})); bot.add_child(lv)

func _buy_card(cid: String, price: int) -> void:
	if GM.gold < price: return; GM.gold -= price; GM.add_to_deck(cid); shop_cards.erase(cid); _build()
func _buy_relic(rid: String, price: int) -> void:
	if GM.gold < price: return; GM.gold -= price; GM.row2_buys += 1; GM.add_relic(rid); shop_relics.erase(rid); _build()
func _buy_booster(arch: String, cost: int) -> void:
	if GM.gold < cost: return; GM.gold -= cost; GM.booster_buys[arch] = GM.booster_buys.get(arch, 0) + 1
	GM.screen_change.emit("booster_open", {"count": 3, "archetype": arch, "from": "shop"})
func _reroll() -> void:
	var cost = GM.REROLL_BASE_COST + rerolls
	if GM.gold < cost: return; GM.gold -= cost; rerolls += 1; shop_cards = GM.rand_shop_cards(3); _build()

func _l(p: Node, t: String, sz: int, c: Color, pos: Vector2 = Vector2.ZERO) -> void:
	var l = Label.new(); l.text = t; l.add_theme_font_size_override("font_size", sz); l.add_theme_color_override("font_color", c)
	if pos != Vector2.ZERO:
		l.position = pos; add_child(l)
	else:
		p.add_child(l)
