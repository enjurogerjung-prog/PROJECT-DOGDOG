extends Control

func _ready() -> void:
	var bg = ColorRect.new(); bg.color = Color(0.06, 0.05, 0.08); bg.set_anchors_preset(PRESET_FULL_RECT); add_child(bg)
	var v = VBoxContainer.new(); v.set_anchors_preset(PRESET_CENTER); v.custom_minimum_size = Vector2(500, 350)
	v.position = Vector2(-250, -175); v.alignment = BoxContainer.ALIGNMENT_CENTER; v.add_theme_constant_override("separation", 12); add_child(v)
	_l(v, "🎁 TREASURE CHEST 🎁", 26, Color(0.9, 0.8, 0.4))
	_l(v, "You found a curious chest among the toadstools.", 14, Color(0.6, 0.55, 0.5))
	_s(v, 15)
	# Offer: random card OR gold
	var cards = GM.rand_shop_cards(3)
	var card_row = HBoxContainer.new(); card_row.alignment = BoxContainer.ALIGNMENT_CENTER
	card_row.add_theme_constant_override("separation", 10); v.add_child(card_row)
	for cid in cards:
		var cd = GM.CARDS[cid]; var ac = GM.get_arch_color(cid)
		var btn = Button.new()
		btn.text = "[%d] %s\n%s" % [cd["cost"], cd["name"], cd["desc"]]
		btn.custom_minimum_size = Vector2(180, 65); btn.add_theme_font_size_override("font_size", 11)
		btn.pressed.connect(func():
			GM.add_to_deck(cid)
			GM.screen_change.emit("map", {})
		)
		card_row.add_child(btn)
	_s(v, 10)
	_l(v, "— OR —", 14, Color(0.5, 0.5, 0.5))
	_s(v, 5)
	var gold_btn = Button.new(); gold_btn.text = "  Take 15 Gold  "; gold_btn.custom_minimum_size = Vector2(200, 40)
	gold_btn.add_theme_font_size_override("font_size", 15)
	gold_btn.pressed.connect(func(): GM.gold += 15; GM.screen_change.emit("map", {}))
	var gc = CenterContainer.new(); v.add_child(gc); gc.add_child(gold_btn)
	# Check for relic
	var rels = GM.rand_relics(1)
	if rels.size() > 0:
		_s(v, 5)
		_l(v, "— OR —", 14, Color(0.5, 0.5, 0.5))
		var relic = GM.RELICS[rels[0]]
		var rb = Button.new(); rb.text = "  %s: %s  " % [relic["name"], relic["desc"]]
		rb.custom_minimum_size = Vector2(350, 40); rb.add_theme_font_size_override("font_size", 13)
		rb.pressed.connect(func(): GM.add_relic(rels[0]); GM.screen_change.emit("map", {}))
		var rc = CenterContainer.new(); v.add_child(rc); rc.add_child(rb)

func _l(p: Node, t: String, sz: int, c: Color) -> void:
	var l = Label.new(); l.text = t; l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", sz); l.add_theme_color_override("font_color", c); p.add_child(l)
func _s(p: Node, h: float) -> void:
	var s = Control.new(); s.custom_minimum_size = Vector2(0, h); p.add_child(s)
