extends Control

# ============================================================
# Main Menu — Title screen for Ribbon Cards
# ============================================================

func _ready() -> void:
	_build_ui()

func _build_ui() -> void:
	# Background
	var bg = ColorRect.new()
	bg.color = Color(0.06, 0.05, 0.08)
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	
	# Title container
	var vbox = VBoxContainer.new()
	vbox.set_anchors_preset(PRESET_CENTER)
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	vbox.custom_minimum_size = Vector2(600, 400)
	vbox.position = Vector2(-300, -200)
	add_child(vbox)
	
	# Decorative line
	var line_top = Label.new()
	line_top.text = "─── ✦ ───"
	line_top.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	line_top.add_theme_color_override("font_color", Color(0.5, 0.3, 0.4))
	line_top.add_theme_font_size_override("font_size", 24)
	vbox.add_child(line_top)
	
	vbox.add_child(_spacer(20))
	
	# Title
	var title = Label.new()
	title.text = "RIBBON CARDS"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 56)
	title.add_theme_color_override("font_color", Color(0.85, 0.7, 0.75))
	vbox.add_child(title)
	
	# Subtitle
	var subtitle = Label.new()
	subtitle.text = "A Tale from The Ribbons"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 18)
	subtitle.add_theme_color_override("font_color", Color(0.5, 0.4, 0.45))
	vbox.add_child(subtitle)
	
	vbox.add_child(_spacer(15))
	
	# Flavor text
	var flavor = Label.new()
	flavor.text = "The Council suppressed the old magic.\nBut the threads remember."
	flavor.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	flavor.add_theme_font_size_override("font_size", 14)
	flavor.add_theme_color_override("font_color", Color(0.4, 0.35, 0.4))
	vbox.add_child(flavor)
	
	vbox.add_child(_spacer(40))
	
	# Start button
	var btn_container = CenterContainer.new()
	vbox.add_child(btn_container)
	
	var start_btn = Button.new()
	start_btn.text = "  UNRAVEL THE THREADS  "
	start_btn.custom_minimum_size = Vector2(280, 50)
	start_btn.add_theme_font_size_override("font_size", 20)
	start_btn.pressed.connect(_on_start_pressed)
	btn_container.add_child(start_btn)
	
	vbox.add_child(_spacer(20))
	
	# Decorative line bottom
	var line_bot = Label.new()
	line_bot.text = "─── ✦ ───"
	line_bot.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	line_bot.add_theme_color_override("font_color", Color(0.5, 0.3, 0.4))
	line_bot.add_theme_font_size_override("font_size", 24)
	vbox.add_child(line_bot)
	
	vbox.add_child(_spacer(30))
	
	# Info
	var info = Label.new()
	info.text = "3 Acts  •  12 Encounters  •  Survive the Council"
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info.add_theme_font_size_override("font_size", 12)
	info.add_theme_color_override("font_color", Color(0.35, 0.3, 0.35))
	vbox.add_child(info)

func _spacer(height: float) -> Control:
	var s = Control.new()
	s.custom_minimum_size = Vector2(0, height)
	return s

func _on_start_pressed() -> void:
	GameManager.start_new_run()
