extends Control

var cards: Array = []; var from_src := "shop"

func _ready() -> void:
	var count = get_meta("count") if has_meta("count") else 3
	var arch = get_meta("archetype") if has_meta("archetype") else "neutral"
	from_src = get_meta("from") if has_meta("from") else "shop"
	var pool = GM.cards_by_arch(arch); pool.shuffle()
	cards = pool.slice(0, mini(count, pool.size()))
	_build()

func _build() -> void:
	for c in get_children(): c.queue_free()
	var bg = ColorRect.new(); bg.color = Color(0.06, 0.05, 0.08); bg.set_anchors_preset(PRESET_FULL_RECT); add_child(bg)
	_lbl("BOOSTER PACK", 24, Color(0.85, 0.75, 0.5), Vector2(0, 25), 1280)
	_lbl("Deck: %d/%d  SB: %d/%d" % [GM.deck.size(), GM.max_deck, GM.sideboard.size(), GM.max_sb], 13, Color(0.5, 0.5, 0.55), Vector2(0, 55), 1280)
	var row = HBoxContainer.new(); row.position = Vector2(0, 90); row.custom_minimum_size = Vector2(1280, 300)
	row.alignment = BoxContainer.ALIGNMENT_CENTER; row.add_theme_constant_override("separation", 15); add_child(row)
	for i in range(cards.size()):
		var cid = cards[i]; var cd = GM.CARDS[cid]; var ac = GM.get_arch_color(cid)
		var p = PanelContainer.new(); p.custom_minimum_size = Vector2(190, 280)
		var pbg = ColorRect.new(); pbg.color = ac.darkened(0.25); pbg.custom_minimum_size = Vector2(190, 280); p.add_child(pbg)
		var vb = VBoxContainer.new(); vb.position = Vector2(8, 6); vb.custom_minimum_size = Vector2(174, 268); vb.add_theme_constant_override("separation", 3); p.add_child(vb)
		var nl = Label.new(); nl.text = "[%d] %s" % [cd["cost"], cd["name"]]; nl.add_theme_font_size_override("font_size", 15); vb.add_child(nl)
		var tl = Label.new(); tl.text = "%s • %s" % [cd["type"].to_upper(), cd["rarity"].to_upper()]; tl.add_theme_font_size_override("font_size", 10); tl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6)); vb.add_child(tl)
		var art = ColorRect.new(); art.color = ac.darkened(0.45); art.custom_minimum_size = Vector2(174, 60); vb.add_child(art)
		var dl = Label.new(); dl.text = cd["desc"]; dl.add_theme_font_size_override("font_size", 12); dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; dl.custom_minimum_size = Vector2(174, 45); vb.add_child(dl)
		var adb = Button.new(); adb.text = "Add to Deck"; adb.custom_minimum_size = Vector2(174, 28); adb.add_theme_font_size_override("font_size", 12)
		adb.disabled = GM.deck.size() >= GM.max_deck; adb.pressed.connect(_add_deck.bind(cid, i)); vb.add_child(adb)
		var asb = Button.new(); asb.text = "Add to Sideboard"; asb.custom_minimum_size = Vector2(174, 28); asb.add_theme_font_size_override("font_size", 12)
		asb.disabled = GM.sideboard.size() >= GM.max_sb; asb.pressed.connect(_add_sb.bind(cid, i)); vb.add_child(asb)
		row.add_child(p)
	var skip = Button.new(); skip.text = "Skip / Done"; skip.position = Vector2(540, 420); skip.custom_minimum_size = Vector2(200, 38)
	skip.add_theme_font_size_override("font_size", 15); skip.pressed.connect(_done); add_child(skip)

func _add_deck(cid: String, idx: int) -> void: GM.add_to_deck(cid); cards.remove_at(idx); _refresh()
func _add_sb(cid: String, idx: int) -> void: GM.add_to_sb(cid); cards.remove_at(idx); _refresh()
func _refresh() -> void:
	if cards.size() == 0: _done()
	else: _build()
func _done() -> void: GM.screen_change.emit("shop", {})

func _lbl(t: String, sz: int, c: Color, pos: Vector2, w: float = 0) -> void:
	var l = Label.new(); l.text = t; l.position = pos; l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	if w > 0: l.custom_minimum_size = Vector2(w, 0)
	l.add_theme_font_size_override("font_size", sz); l.add_theme_color_override("font_color", c); add_child(l)
