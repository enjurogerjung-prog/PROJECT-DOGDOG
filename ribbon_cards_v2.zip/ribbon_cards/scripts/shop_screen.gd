extends Control

var shop_cards: Array = []  # Card IDs for Row 1
var shop_relics: Array = []  # Relic IDs for Row 2
var reroll_count: int = 0

func _ready() -> void:
	var skip_reward = get_meta("skip_reward") if has_meta("skip_reward") else ""
	reroll_count = 0
	_generate_shop()
	_build_ui(skip_reward)

func _generate_shop() -> void:
	shop_cards = GameManager.get_random_shop_cards(3)
	shop_relics = GameManager.get_random_shop_relics(2)

func _build_ui(skip_reward: String) -> void:
	# Clear
	for c in get_children(): c.queue_free()
	
	var bg = ColorRect.new()
	bg.color = Color(0.07, 0.06, 0.09)
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	
	# Top bar
	var top = HBoxContainer.new()
	top.position = Vector2(20, 10)
	top.add_theme_constant_override("separation", 25)
	add_child(top)
	_info(top, "SHOP", 24, Color(0.85, 0.75, 0.5))
	_info(top, "Gold: %dg" % GameManager.gold, 20, Color(0.9, 0.8, 0.3))
	_info(top, "HP: %d/%d" % [GameManager.player_hp, GameManager.player_max_hp], 18, Color(0.7, 0.4, 0.4))
	_info(top, "Deck: %d/%d  SB: %d/%d" % [GameManager.deck.size(), GameManager.max_deck_size, GameManager.sideboard.size(), GameManager.max_sideboard_size], 14, Color(0.5, 0.5, 0.6))
	
	if skip_reward != "":
		_info(top, "Skip Reward: %s" % skip_reward, 14, Color(0.4, 0.7, 0.4))
	
	# === ROW 1: Cards ===
	var r1_label = Label.new()
	r1_label.text = "─── Cards ───"
	r1_label.position = Vector2(20, 50)
	r1_label.add_theme_font_size_override("font_size", 16)
	r1_label.add_theme_color_override("font_color", Color(0.6, 0.55, 0.5))
	add_child(r1_label)
	
	var card_row = HBoxContainer.new()
	card_row.position = Vector2(20, 75)
	card_row.add_theme_constant_override("separation", 12)
	add_child(card_row)
	
	for card_id in shop_cards:
		var card_data = GameManager.CARDS[card_id]
		var price = maxi(card_data["buy_price"] - GameManager.shop_discount, 1)
		var panel = _make_shop_card(card_id, price)
		card_row.add_child(panel)
	
	# Reroll button
	var reroll_cost = GameManager.REROLL_BASE_COST + reroll_count
	var reroll_btn = Button.new()
	reroll_btn.text = "Reroll (%dg)" % reroll_cost
	reroll_btn.custom_minimum_size = Vector2(110, 40)
	reroll_btn.add_theme_font_size_override("font_size", 13)
	reroll_btn.disabled = GameManager.gold < reroll_cost
	reroll_btn.pressed.connect(_on_reroll)
	card_row.add_child(reroll_btn)
	
	# === ROW 2: Relics ===
	var r2_label = Label.new()
	r2_label.text = "─── Relics ───"
	r2_label.position = Vector2(20, 230)
	r2_label.add_theme_font_size_override("font_size", 16)
	r2_label.add_theme_color_override("font_color", Color(0.6, 0.55, 0.5))
	add_child(r2_label)
	
	var relic_row = HBoxContainer.new()
	relic_row.position = Vector2(20, 255)
	relic_row.add_theme_constant_override("separation", 12)
	add_child(relic_row)
	
	for relic_id in shop_relics:
		var relic = GameManager.RELICS[relic_id]
		var price = GameManager.get_row2_item_cost(relic["buy_price"]) - GameManager.relic_discount
		price = maxi(price, 1)
		var panel = _make_shop_relic(relic_id, price)
		relic_row.add_child(panel)
	
	# === ROW 3: Boosters ===
	var r3_label = Label.new()
	r3_label.text = "─── Booster Packs (3 cards) ───"
	r3_label.position = Vector2(20, 370)
	r3_label.add_theme_font_size_override("font_size", 16)
	r3_label.add_theme_color_override("font_color", Color(0.6, 0.55, 0.5))
	add_child(r3_label)
	
	var booster_row = HBoxContainer.new()
	booster_row.position = Vector2(20, 395)
	booster_row.add_theme_constant_override("separation", 15)
	add_child(booster_row)
	
	for arch in ["rock", "scissors", "paper"]:
		var cost = GameManager.get_booster_cost(arch)
		var arch_color = GameManager.ARCHETYPE_COLORS[arch]
		
		var btn_panel = PanelContainer.new()
		btn_panel.custom_minimum_size = Vector2(160, 70)
		booster_row.add_child(btn_panel)
		
		var btn_bg = ColorRect.new()
		btn_bg.color = arch_color.darkened(0.6)
		btn_bg.custom_minimum_size = Vector2(160, 70)
		btn_panel.add_child(btn_bg)
		
		var btn_vbox = VBoxContainer.new()
		btn_vbox.position = Vector2(8, 5)
		btn_panel.add_child(btn_vbox)
		
		var bn = Label.new()
		bn.text = "%s Pack" % GameManager.ARCHETYPE_NAMES[arch]
		bn.add_theme_font_size_override("font_size", 14)
		bn.add_theme_color_override("font_color", arch_color.lightened(0.3))
		btn_vbox.add_child(bn)
		
		var bp = Label.new()
		bp.text = "%dg" % cost
		bp.add_theme_font_size_override("font_size", 12)
		bp.add_theme_color_override("font_color", Color(0.9, 0.8, 0.3))
		btn_vbox.add_child(bp)
		
		var buy_btn = Button.new()
		buy_btn.text = "Buy"
		buy_btn.custom_minimum_size = Vector2(60, 25)
		buy_btn.add_theme_font_size_override("font_size", 11)
		buy_btn.disabled = GameManager.gold < cost
		buy_btn.pressed.connect(_on_buy_booster.bind(arch, cost))
		btn_vbox.add_child(buy_btn)
	
	# === Bottom buttons ===
	var bot = HBoxContainer.new()
	bot.position = Vector2(20, 660)
	bot.add_theme_constant_override("separation", 12)
	add_child(bot)
	
	var deck_btn = Button.new()
	deck_btn.text = "Manage Deck / Sell / Combine"
	deck_btn.custom_minimum_size = Vector2(260, 35)
	deck_btn.add_theme_font_size_override("font_size", 14)
	deck_btn.pressed.connect(func(): GameManager.screen_change_requested.emit("deck_manager", {"return_to": "shop"}))
	bot.add_child(deck_btn)
	
	var leave_btn = Button.new()
	leave_btn.text = "Leave Shop →"
	leave_btn.custom_minimum_size = Vector2(140, 35)
	leave_btn.add_theme_font_size_override("font_size", 14)
	leave_btn.pressed.connect(_on_leave)
	bot.add_child(leave_btn)
	
	# Owned relics
	if GameManager.owned_relics.size() > 0:
		var relic_lbl = Label.new()
		relic_lbl.position = Vector2(20, 530)
		var names: Array = []
		for rid in GameManager.owned_relics:
			names.append(GameManager.RELICS[rid]["name"])
		relic_lbl.text = "Owned: " + ", ".join(names)
		relic_lbl.add_theme_font_size_override("font_size", 12)
		relic_lbl.add_theme_color_override("font_color", Color(0.5, 0.45, 0.3))
		add_child(relic_lbl)

func _make_shop_card(card_id: String, price: int) -> PanelContainer:
	var card_data = GameManager.CARDS[card_id]
	var arch_color = GameManager.get_card_color(card_id)
	
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(180, 145)
	
	var bg = ColorRect.new()
	bg.color = arch_color.darkened(0.3)
	bg.custom_minimum_size = Vector2(180, 145)
	panel.add_child(bg)
	
	var vbox = VBoxContainer.new()
	vbox.position = Vector2(8, 5)
	vbox.add_theme_constant_override("separation", 3)
	panel.add_child(vbox)
	
	var name_row = HBoxContainer.new()
	vbox.add_child(name_row)
	var cost_lbl = Label.new()
	cost_lbl.text = "[%d] " % card_data["cost"]
	cost_lbl.add_theme_font_size_override("font_size", 14)
	cost_lbl.add_theme_color_override("font_color", Color(0.9, 0.8, 0.3))
	name_row.add_child(cost_lbl)
	var name_lbl = Label.new()
	name_lbl.text = card_data["name"]
	name_lbl.add_theme_font_size_override("font_size", 14)
	name_row.add_child(name_lbl)
	
	var type_lbl = Label.new()
	type_lbl.text = "%s • %s • %s" % [card_data["type"].to_upper(), card_data["archetype"].to_upper(), card_data["rarity"].to_upper()]
	type_lbl.add_theme_font_size_override("font_size", 10)
	type_lbl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	vbox.add_child(type_lbl)
	
	var desc_lbl = Label.new()
	desc_lbl.text = card_data["desc"]
	desc_lbl.add_theme_font_size_override("font_size", 12)
	desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc_lbl.custom_minimum_size = Vector2(164, 40)
	vbox.add_child(desc_lbl)
	
	var price_row = HBoxContainer.new()
	price_row.add_theme_constant_override("separation", 8)
	vbox.add_child(price_row)
	
	var price_lbl = Label.new()
	price_lbl.text = "%dg" % price
	price_lbl.add_theme_font_size_override("font_size", 14)
	price_lbl.add_theme_color_override("font_color", Color(0.9, 0.8, 0.3))
	price_row.add_child(price_lbl)
	
	var buy_btn = Button.new()
	buy_btn.text = "Buy"
	buy_btn.custom_minimum_size = Vector2(60, 28)
	buy_btn.add_theme_font_size_override("font_size", 12)
	buy_btn.disabled = GameManager.gold < price or GameManager.deck.size() >= GameManager.max_deck_size
	buy_btn.pressed.connect(_on_buy_card.bind(card_id, price))
	price_row.add_child(buy_btn)
	
	return panel

func _make_shop_relic(relic_id: String, price: int) -> PanelContainer:
	var relic = GameManager.RELICS[relic_id]
	
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(220, 95)
	
	var bg = ColorRect.new()
	bg.color = Color(0.15, 0.12, 0.08)
	bg.custom_minimum_size = Vector2(220, 95)
	panel.add_child(bg)
	
	var vbox = VBoxContainer.new()
	vbox.position = Vector2(8, 5)
	vbox.add_theme_constant_override("separation", 3)
	panel.add_child(vbox)
	
	var name_lbl = Label.new()
	name_lbl.text = relic["name"]
	name_lbl.add_theme_font_size_override("font_size", 15)
	name_lbl.add_theme_color_override("font_color", Color(0.9, 0.75, 0.4))
	vbox.add_child(name_lbl)
	
	var desc_lbl = Label.new()
	desc_lbl.text = relic["desc"]
	desc_lbl.add_theme_font_size_override("font_size", 12)
	desc_lbl.add_theme_color_override("font_color", Color(0.7, 0.7, 0.65))
	vbox.add_child(desc_lbl)
	
	var price_row = HBoxContainer.new()
	price_row.add_theme_constant_override("separation", 8)
	vbox.add_child(price_row)
	
	var price_lbl = Label.new()
	price_lbl.text = "%dg" % price
	price_lbl.add_theme_font_size_override("font_size", 14)
	price_lbl.add_theme_color_override("font_color", Color(0.9, 0.8, 0.3))
	price_row.add_child(price_lbl)
	
	var buy_btn = Button.new()
	buy_btn.text = "Buy"
	buy_btn.custom_minimum_size = Vector2(60, 28)
	buy_btn.add_theme_font_size_override("font_size", 12)
	buy_btn.disabled = GameManager.gold < price
	buy_btn.pressed.connect(_on_buy_relic.bind(relic_id, price))
	price_row.add_child(buy_btn)
	
	return panel

func _on_buy_card(card_id: String, price: int) -> void:
	if GameManager.gold < price: return
	if not GameManager.add_card_to_deck(card_id): return
	GameManager.gold -= price
	shop_cards.erase(card_id)
	_build_ui("")

func _on_buy_relic(relic_id: String, price: int) -> void:
	if GameManager.gold < price: return
	var relic = GameManager.RELICS[relic_id]
	# Check for confirmation needed
	if relic.get("needs_confirm", false):
		_show_confirm(relic_id, price, relic["name"], relic["desc"])
		return
	GameManager.gold -= price
	GameManager.row2_purchases += 1
	GameManager.add_relic(relic_id)
	shop_relics.erase(relic_id)
	_build_ui("")

func _show_confirm(relic_id: String, price: int, name: String, desc: String) -> void:
	var overlay = ColorRect.new()
	overlay.name = "ConfirmOverlay"
	overlay.color = Color(0, 0, 0, 0.8)
	overlay.set_anchors_preset(PRESET_FULL_RECT)
	add_child(overlay)
	
	var vbox = VBoxContainer.new()
	vbox.set_anchors_preset(PRESET_CENTER)
	vbox.custom_minimum_size = Vector2(400, 200)
	vbox.position = Vector2(-200, -100)
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	overlay.add_child(vbox)
	
	_info(vbox, "⚠ Confirm Purchase", 22, Color(0.9, 0.7, 0.3))
	_info(vbox, name + ": " + desc, 16, Color(0.8, 0.8, 0.7))
	_info(vbox, "This may affect your deck building. Are you sure?", 13, Color(0.6, 0.5, 0.4))
	
	var btn_row = HBoxContainer.new()
	btn_row.alignment = BoxContainer.ALIGNMENT_CENTER
	btn_row.add_theme_constant_override("separation", 20)
	vbox.add_child(btn_row)
	
	var yes_btn = Button.new()
	yes_btn.text = "Yes, Buy"
	yes_btn.custom_minimum_size = Vector2(100, 35)
	yes_btn.pressed.connect(func():
		overlay.queue_free()
		GameManager.gold -= price
		GameManager.row2_purchases += 1
		GameManager.add_relic(relic_id)
		shop_relics.erase(relic_id)
		_build_ui("")
	)
	btn_row.add_child(yes_btn)
	
	var no_btn = Button.new()
	no_btn.text = "Cancel"
	no_btn.custom_minimum_size = Vector2(100, 35)
	no_btn.pressed.connect(func(): overlay.queue_free())
	btn_row.add_child(no_btn)

func _on_buy_booster(arch: String, cost: int) -> void:
	if GameManager.gold < cost: return
	GameManager.gold -= cost
	GameManager.booster_purchases[arch] = GameManager.booster_purchases.get(arch, 0) + 1
	GameManager.screen_change_requested.emit("booster_open", {"count": 3, "archetype": arch, "from": "shop"})

func _on_reroll() -> void:
	var cost = GameManager.REROLL_BASE_COST + reroll_count
	if GameManager.gold < cost: return
	GameManager.gold -= cost
	reroll_count += 1
	shop_cards = GameManager.get_random_shop_cards(3)
	_build_ui("")

func _on_leave() -> void:
	GameManager.screen_change_requested.emit("map", {})

func _info(parent: Node, text: String, size: int, color: Color) -> void:
	var l = Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	parent.add_child(l)
